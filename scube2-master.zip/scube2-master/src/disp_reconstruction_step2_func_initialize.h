/*
 * File: disp_reconstruction_step2_func_initialize.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 22-Feb-2018 15:59:29
 */

#ifndef __DISP_RECONSTRUCTION_STEP2_FUNC_INITIALIZE_H__
#define __DISP_RECONSTRUCTION_STEP2_FUNC_INITIALIZE_H__

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "disp_reconstruction_step2_func_types.h"

/* Function Declarations */
extern void disp_reconstruction_step2_func_initialize(void);

#endif

/*
 * File trailer for disp_reconstruction_step2_func_initialize.h
 *
 * [EOF]
 */
