#include <math.h>

#include "IoTSensor.h"
#include "maintask.h"
#include "ncubetask.h"

#include "processtask.h"

ProcessTask::ProcessTask(QObject *parent) :
    QObject(parent)
{
}

void ProcessTask::Init()
{
    for (int i=0; i<MAX_CH; i++)
    {
        m_isEvent[i] = false;
        m_isMadeData[i] = false;
        m_eventDataCount[i] = 0;
    }

    calcTriggerValue();

#ifdef KT_IOTMAKERS
    m_KtSendCount = 0;
#endif
}

void ProcessTask::runProc(void)
{
    DAQDATA qData;

    while (1)
    {
        QThread::usleep(1000);
        qData.iYear = 1970;

        m_pMain->m_SMutex.lock();   ////

        if (m_pMain->m_SensorDatas.size() > 0)
        {
            qData = m_pMain->m_SensorDatas.first();
            ////printf("[[P]Packets -> %d(%d)\n", qData.size(), m_pMain->m_SensorDatas.size());
        }

        m_pMain->m_SMutex.unlock(); ////

        if (qData.iYear > 1970)
        {
#ifdef DBGPRINT
        printf("\n");
        printf("> Ch:%01d> %04d-%02d-%02d %02d:%02d:%02d.%03d <%.4f><%.4f><%.4f>\n",
               qData.iCh, qData.iYear, qData.iMonth, qData.iDay, qData.iHour, qData.iMinute, qData.iSec, qData.iMilSec,
               qData.fsensorData[0], qData.fsensorData[1], qData.fsensorData[2]);
#endif
            ProcData(qData);

            m_pMain->m_SMutex.lock();   ////
            m_pMain->m_SensorDatas.removeFirst();
            m_pMain->m_SMutex.unlock(); ////
        }
    }
}

void ProcessTask::ProcData(DAQDATA qData)
{
    for (int ch=0; ch<qData.iCh; ch++)
    {
        //// Storing for event data
        if (m_isEvent[ch] && !m_isMadeData[ch])
        {
            m_eventVect[ch].append(qData.fsensorData[ch]);

            if (m_eventDataCount[ch] >= m_pMain->m_samplingRate)
            {
                // 전송용 으로 샘플링레이트 만큼 문자열로 저장
                QString text = QString::number(qData.fsensorData[ch], 'f', 5);
                m_rawString[ch] += text;

                m_eventDataCount[ch] = 0;
                m_isMadeData[ch] = true;
            }
            else
            {
                // 전송용 으로 샘플링레이트 만큼 문자열로 저장
                QString text = QString::number(qData.fsensorData[ch], 'f', 5) + ",";
                m_rawString[ch] += text;

                m_eventDataCount[ch]++;
            }
        }

        //// Storing Event Queue for event data processing...
        m_eventQueue[ch].enQueue(qData.fsensorData[ch]);

        //// Storing data for analysis...
        m_rawVect[ch].append(qData.fsensorData[ch]);
#ifdef KT_IOTMAKERS
        m_KtrawVect[ch].append(qData.fsensorData[ch]);
        m_Kt10MinrawVect[ch].append(qData.fsensorData[ch]);
#endif

        // 시리얼 통신속도와 위에서 센서타입별로 데이터를 변환하는 시간 딜레이 때문에
        // 1초단위로 분석하지 않고, 샘플링레이트(개수) 단위로 분석한다.
        int count = m_rawVect[ch].size();
        if (count == m_pMain->m_samplingRate)
        {
            CALCVECT calVector;
            calVector.iYear = qData.iYear;
            calVector.iMonth = qData.iMonth;
            calVector.iDay = qData.iDay;
            calVector.iHour = qData.iHour;
            calVector.iMinute = qData.iMinute;
            calVector.iSec = qData.iSec;
            calVector.iMilSec = qData.iMilSec;
            calVector.iCh = ch;
            calVector.bEvent = m_isEvent[ch];
            calVector.iType = 1;    // Normal stat. for smartc&s
            calVector.rawVect = m_rawVect[ch];

            CopyData(calVector.daqGPS, m_pMain->m_daqGPS);
            CopyData(calVector.daqStatus, m_pMain->m_daqStatus);

            m_pMain->m_CalcMutex.lock();    ////
            m_pMain->m_CalcDatas.append(calVector);
            //printf(">>> CalcDatas = (%d: %d) %d\n", calVector.iCh, calVector.rawVect.size(), m_pMain->m_CalcDatas.size());
            m_pMain->m_CalcMutex.unlock();  ////

            m_rawVect[ch].clear();
        }

        CheckEvent(ch, qData);
        PublishEvent(ch);

#ifdef KT_IOTMAKERS
        //// using sampling during one second for making one sec data
        if (m_KtrawVect[ch].size() == m_pMain->m_SensorConfig.m_setSample * m_pMain->m_IoTM.m_Stat_Sec)
        {
            CALCVECT calVector;
            calVector.iYear = qData.iYear;
            calVector.iMonth = qData.iMonth;
            calVector.iDay = qData.iDay;
            calVector.iHour = qData.iHour;
            calVector.iMinute = qData.iMinute;
            calVector.iSec = qData.iSec;
            calVector.iMilSec = qData.iMilSec;
            calVector.iCh = ch;
            calVector.bEvent = m_isEvent[ch];
            calVector.iType = 2;    // Normal stat. for KT IotMakers
            calVector.rawVect = m_KtrawVect[ch];

            CopyData(calVector.daqGPS, m_pMain->m_daqGPS);
            CopyData(calVector.daqStatus, m_pMain->m_daqStatus);

            m_pMain->m_KtCalcMutex.lock();
            m_pMain->m_KtCalcDatas.append(calVector);
            m_pMain->m_KtCalcMutex.unlock();

            m_KtrawVect[ch].clear();
        }

        if (m_Kt10MinrawVect[ch].size() == m_pMain->m_SensorConfig.m_setSample * SECS10MINS)
        {
            CALCVECT calVector;
            calVector.iYear = qData.iYear;
            calVector.iMonth = qData.iMonth;
            calVector.iDay = qData.iDay;
            calVector.iHour = qData.iHour;
            calVector.iMinute = qData.iMinute;
            calVector.iSec = qData.iSec;
            calVector.iMilSec = qData.iMilSec;
            calVector.iCh = ch;
            calVector.bEvent = m_isEvent[ch];
            calVector.iType = 3;    // 10Mins stat. for KT IotMakers
            calVector.rawVect = m_Kt10MinrawVect[ch];

            CopyData(calVector.daqGPS, m_pMain->m_daqGPS);
            CopyData(calVector.daqStatus, m_pMain->m_daqStatus);

            m_pMain->m_Kt10MinCalcMutex.lock();
            m_pMain->m_Kt10MinCalcDatas.append(calVector);
            m_pMain->m_Kt10MinCalcMutex.unlock();

            m_Kt10MinrawVect[ch].clear();
        }
#endif  // KT_IOTMAKERS
    }
}

// 이벤트 조건을 체크하고,
void ProcessTask::CheckEvent(int ch, DAQDATA qData)
{
    if (m_pMain->m_AnalysisConfig.m_tv > 0 && !m_isEvent[ch])
    {
        //if (qFabs(rawdata) > m_triggerValue)
        if (fabs(qData.fsensorData[ch]) > m_pMain->m_triggerValue[ch])
        {
            m_isEvent[ch] = true;
            m_isMadeData[ch] = false;
            m_eventDataCount[ch] = 0;

            m_eventVect[ch].clear();

            // Date/Time
            QString text;
            text.sprintf("%4d%02d%02d %02d%02d%02d.%03d,", qData.iYear, qData.iMonth, qData.iDay,
                         qData.iHour, qData.iMinute, qData.iSec, qData.iMilSec);
            m_rawString[ch] = text;
            m_rawString[ch] += m_eventQueue[ch].getQueue(m_eventVect[ch]);

            //// Take a Picture

            if (m_pMain->m_MainConfig.m_iUseCamera == 1)
            {
//#ifdef XX
                QTime tick;
                tick.start();
//#endif //XX
                m_pMain->Take_aPicture(1, qData);   // taking picture for Event
//#ifdef XX
                int nElapsed = tick.elapsed();
                qDebug() << "Took picture = " << nElapsed;
//#endif //XX
            }

            printf("Value Triggered !!! (%d) - %.5f:%.5f\r\n", ch, qData.fsensorData[ch], m_pMain->m_triggerValue[ch]);
        }
    }
}

// 이벤트 조건을 체크하고, 이벤트가 발생했을 경우 MQTT로 데이터를 전송한다.
void ProcessTask::PublishEvent(int ch)
{
    if (m_isEvent[ch] && m_isMadeData[ch])
    {
        m_isEvent[ch] = false;
        m_isMadeData[ch] = false;

        nCUBEDATA qData;
        qData.iType = 2;    // Event Data
        qData.strContents = m_rawString[ch];

#ifdef XX
        m_pMain->m_nCubeMutex.lock();    ////
        m_pMain->m_nCubeDatas.append(qData);
        //printf(">>> nCubeDatas = (%d: %d) %d\n", qData.iType, qData.strContents.size(), m_pMain->m_nCubeDatas.size());
        m_pMain->m_nCubeMutex.unlock();  ////
#endif
        if (m_pMain->m_ProtocolConfig.m_dam == 1 || m_pMain->m_ProtocolConfig.m_dam == 4 || m_pMain->m_ProtocolConfig.m_dam == 5 || m_pMain->m_ProtocolConfig.m_dam == 7)
        {
            m_rawString[ch].clear();
            return;
        }

        QString strContainerName;
        QString strContents;

        strContainerName = m_pMain->m_CubeConfig.m_tcpCtnRawe;

#ifdef NCUBE_172
        strContents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}<EOF>",
#else
        strContents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}",
#endif
            strContainerName.toStdString().c_str(),
            qData.strContents.toStdString().c_str());

        // send to nCube
        //m_pMain->m_socket->write(strContents.toStdString().c_str());
        emit send2nCubeEvent(strContents);

        printf("Tcp-Send:%s\r\n", strContents.toStdString().c_str());
        fflush(stdout);

        m_rawString[ch].clear();

        SendEventAnalData(ch);
    }
}

#ifdef XX
void NCubeTask::PublishEvent(nCUBEDATA qData)
{
    if (m_pMain->m_ProtocolConfig.m_dam == 1 || m_pMain->m_ProtocolConfig.m_dam == 4 || m_pMain->m_ProtocolConfig.m_dam == 5 || m_pMain->m_ProtocolConfig.m_dam == 7)
        return;

    QString strContainerName;
    QString strContents;

    if (qData.iType == 2)   //// Event Data
        strContainerName = m_pMain->m_CubeConfig.m_tcpCtnRawe;
    else
        return;

#ifdef NCUBE_172
    strContents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}<EOF>",
#else
    strContents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}",
#endif
                     strContainerName.toStdString().c_str(),
                     qData.strContents.toStdString().c_str());

    // 앤큐브에 전송한다. 결과적으로 서버플랫폼의 DB에 데이터가 저장됨
    m_pMain->m_socket->write(strContents.toStdString().c_str());

    printf("Tcp-Send:%s\r\n", strContents.toStdString().c_str());
    fflush(stdout);
}
#endif

void ProcessTask::SendEventAnalData(int ch)
{
    QString packet;
    QString text;

    /*****
    float analdata0 = (this->*m_AnalFn0)(m_eventVect[ch]);
    float analdata1 = (this->*m_AnalFn1)(m_eventVect[ch]);

    // Date/Time
    packet.sprintf("%4d%02d%02d %02d%02d%02d.%03d,", m_DAQYear, m_DAQMonth, m_DAQDay,
                   m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);

    // Analysis function - main
    text.sprintf("%.5f,", analdata0); // Warning : There is a "," at the end of the value
    packet += text;

    // Analysis function - sub
    text.sprintf("%.5f,", analdata1); // Warning : There is a "," at the end of the value
    packet += text;

    // Event
    text = "1,";
    packet += text;

    // Location
    text.sprintf("%04d.%04d,%c,%04d.%04d,%c,", m_Lat1, m_Lat2, m_isNorth ? 'N' : 'S',
                 m_Lon1, m_Lon2, m_isEest ? 'E' : 'W');
    packet += text;

    // 온도
    text.sprintf("%.2f,", m_Temp);
    packet += text;

    // 습도
    text.sprintf("%.2f,", m_Humi);
    packet += text;

    // D-inf
    text = "000";
    packet += text;

    QString contents;
#ifdef  NCUBE_172
    contents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}<EOF>",
#else
    contents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}",
#endif
                     m_CubeConfig.m_tcpCtnAnal.toStdString().c_str(),
                     packet.toStdString().c_str());

    // 앤큐브에 전송한다. 결과적으로 서버플랫폼의 DB에 데이터가 저장됨
    m_socket->write(contents.toStdString().c_str());

    printf("Tcp-Send(Event): %d sec: %s\r\n", m_sendTimeValue, contents.toStdString().c_str());
    fflush(stdout);
    *****/
}

void ProcessTask::calcTriggerValue()
{
    m_triggerValue[0] = m_pMain->m_SensorConfig.m_range[0] * m_pMain->m_AnalysisConfig.m_tv / 100;
    printf("TriggerValue0 = %.2f\r\n", m_triggerValue[0]);
    m_triggerValue[1] = m_pMain->m_SensorConfig.m_range[1] * m_pMain->m_AnalysisConfig.m_tv / 100;
    printf("TriggerValue1 = %.2f\r\n", m_triggerValue[1]);
    m_triggerValue[2] = m_pMain->m_SensorConfig.m_range[2] * m_pMain->m_AnalysisConfig.m_tv / 100;
    printf("TriggerValue2 = %.2f\r\n", m_triggerValue[2]);
}
