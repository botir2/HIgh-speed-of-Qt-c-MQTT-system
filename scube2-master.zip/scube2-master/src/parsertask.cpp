#include "IoTSensor.h"
#include "maintask.h"

#include "parsertask.h"

ParserTask::ParserTask(QObject *parent) :
    QObject(parent)
{
}

void ParserTask::runProc(void)
{
    QByteArray qData;

    while (1)
    {
        QThread::usleep(300);
        qData.clear();

        m_pMain->m_PMutex.lock();   ////

        if (m_pMain->m_Packets.size() > 0)
        {
            qData = m_pMain->m_Packets.first();
            //printf("[[P]Packets -> %d(%d)\n", qData.size(), m_pMain->m_Packets.size());
            ////m_pMain->m_Packets.removeFirst();
        }

        m_pMain->m_PMutex.unlock(); ////

        if (qData.size() > 0)
        {
#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("[%x]", *d);
                ++d;
            }
            printf("\r\n");
#endif
            ParsePacket(qData);

            m_pMain->m_PMutex.lock();   ////
            m_pMain->m_Packets.removeFirst();
            m_pMain->m_PMutex.unlock(); ////
        }
    }
}

void ParserTask::ParsePacket(QByteArray data)
{
    static bool bSensorDataFirst = true;
    static bool bGPSDataFirst = true;
    static bool bTempDataFirst = true;
    static bool bVoltDataFirst = true;

    DAQDATA daqData;

    QByteArray qData = data;

    char cmd = qData.at(0);
    int nCmd = (int)cmd;
    //printf("Cmd = %d\r\n", nCmd);

    if (nCmd == m_pMain->m_SensorConfig.m_setType)    // for Sensor Data
    {

        int dCnt = (int)qData.at(1);
        daqData.iCh = dCnt;
#ifdef DBGPRINT
        printf("Sensor Data - %d\r\n", dCnt);
#endif

        int cnt = qData.size();
        if (cnt < 15)
        {
            printf("Packet_Error-S:%d ", cnt);
//#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("{%x}", *d);
                ++d;
            }
            printf("\r\n");
//#endif
        }
        else
        {
            char adcData = qData.at(1);
            int dataLen = (int)adcData;
            int val, sVal[3];

            adcData = qData.at(2);
            daqData.iGPSLock = (int)adcData;

            adcData = qData.at(3);
            val = (int)adcData;
            adcData = qData.at(4);
            val <<= 8;
            daqData.iYear = val | adcData;

            adcData = qData.at(5);
            daqData.iMonth = (int)adcData;
            adcData = qData.at(6);
            daqData.iDay = (int)adcData;
            adcData = qData.at(7);
            daqData.iHour = (int)adcData;
            adcData = qData.at(8);
            daqData.iMinute = (int)adcData;
            adcData = qData.at(9);
            daqData.iSec = (int)adcData;

            adcData = qData.at(10);
            val = (int)adcData;
            adcData = qData.at(11);
            val <<= 8;
            daqData.iMilSec = val | adcData;

            daqData.fsensorData[0] = 0.0;
            daqData.fsensorData[1] = 0.0;
            daqData.fsensorData[2] = 0.0;

            for (int ch=0; ch<dCnt; ch++)
            {
                adcData = qData.at(12+(ch*2));
                sVal[ch] = (int)adcData;
                adcData = qData.at(13+(ch*2));
                sVal[ch] <<= 8;
                sVal[ch] = sVal[ch] | adcData;

                daqData.fsensorData[ch] = m_pMain->m_converter.SensorData(ch, sVal[ch]);
            }

            if (bSensorDataFirst && !bTempDataFirst && !bVoltDataFirst)
            {
                if (isTimeValid(daqData))
                {
                    m_pMain->startTimer();

                    CopyData(m_oldData, daqData);
                    bSensorDataFirst = false;
                }
            }

            if (!bTempDataFirst && !bVoltDataFirst && !bSensorDataFirst)
            {
                ////printf("DAQ Data = %01d, %01d, %01d\n", bGPSDataFirst ? 0 : 1, bTempDataFirst ? 0 : 1, bVoltDataFirst ? 0 : 1);
                if (isTimeValid(daqData))
                {
                    ///// 1. Checking time gap & filling data
                    TimeCheckAndFill(daqData);
                    CopyData(m_oldData, daqData);

                    ///// 2. appedding to SensorDatas vector
                    m_pMain->m_SMutex.lock();   /////
                    m_pMain->m_SensorDatas.append(daqData);
                    //printf("<<<SDatas -> (%d)\n", m_pMain->m_SensorDatas.size());
                    m_pMain->m_SMutex.unlock(); /////

                    ///// 3. appedding to MQTTDatas vector
                    m_pMain->m_MQTTMutex.lock();   /////
                    m_pMain->m_MQTTDatas.append(daqData);
                    m_pMain->m_MQTTMutex.unlock(); /////

                    ///// 4. appedding to FileSaveDatas vector
                    MakeFileData(daqData);
                }
                else
                {
                    printf("<<<Data Invalid --> %04d-%02d-%02d %02d:%02d:%02d.%03d >>>\n",
                           daqData.iYear, daqData.iMonth, daqData.iDay, daqData.iHour, daqData.iMinute, daqData.iSec, daqData.iMilSec);
                }
            }
        }
    }
    else if (cmd == 0xa0)   // GPS Data
    {
#ifdef DBGPRINT
        printf("GPS Data\r\n");
#endif
        int cnt = qData.size();
        if (cnt < 12)
        {
            printf("Packet_Error-G:%d ", cnt);
//#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("{%x}", *d);
                ++d;
            }
            printf("\r\n");
//#endif
        }
        else
        {
            char ch = qData.at(2);
            int val = (int)ch;
            ch = qData.at(3);
            val <<= 8;
            m_daqGPS.iLat1 = val | ch;

            ch = qData.at(4);
            val = (int)ch;
            ch = qData.at(5);
            val <<= 8;
            m_daqGPS.iLat2 = val | ch;

            ch = qData.at(7);
            val = (int)ch;
            ch = qData.at(8);
            val <<= 8;
            m_daqGPS.iLon1 = val | ch;

            ch = qData.at(9);
            val = (int)ch;
            ch = qData.at(10);
            val <<= 8;
            m_daqGPS.iLon2 = val | ch;

            ch = qData.at(6);
            if (ch == 0x4E)
                m_daqGPS.bisNorth = true;
            else
                m_daqGPS.bisNorth = false;

            ch = qData.at(11);
            if (ch == 0x45)
                m_daqGPS.bisEest = true;
            else
                m_daqGPS.bisEest = false;

#ifdef DBGPRINT
            printf("<<<%0x-%04d.%04d : %0x-%04d.%04d>>>\n", m_isNorth, m_Lat1, m_Lat2, m_isEest, m_Lon1, m_Lon2);
#endif
            if (bGPSDataFirst)
                bGPSDataFirst = false;

            m_pMain->m_DAQSMutex.lock();
            CopyData(m_pMain->m_daqGPS, m_daqGPS);
            m_pMain->m_DAQSMutex.unlock();
        }
    }
    else if (cmd == 0xb0)   // Temperature & Humidity Data
    {
#ifdef DBGPRINT
        printf("Temp.Humi Data\r\n");
#endif
        int cnt = qData.size();
        if (cnt < 6)
        {
            printf("Packet_Error-T:%d ", cnt);
//#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("{%x}", *d);
                ++d;
            }
            printf("\r\n");
//#endif
        }
        else
        {
            int val, temp, humi;

            char ch = qData.at(2);
            val = (int)ch;
            ch = qData.at(3);
            val <<= 8;
            temp = val | ch;

            ch = qData.at(4);
            val = (int)ch;
            ch = qData.at(5);
            val <<= 8;
            humi = val | ch;

            m_daqStatus.fTemp = ((float)temp / 65536) * 165 - 40;
            m_daqStatus.fHumi = ((float)humi / 65536) * 100;

#ifdef DBGPRINT
            printf("<%d:%d<<%.2f : %.2f>>>\n", temp, humi, m_Temp, m_Humi);
#endif
            if (bTempDataFirst)
                bTempDataFirst = false;

            m_pMain->m_DAQSMutex.lock();
            CopyData(m_pMain->m_daqStatus, m_daqStatus);
            m_pMain->m_DAQSMutex.unlock();
        }
    }
    else if (cmd == 0xc0)   // Voltage
    {
#ifdef DBGPRINT
        printf("Voltage Data\r\n");
#endif
        int cnt = qData.size();
        if (cnt < 4)
        {
            printf("Packet_Error-T:%d ", cnt);
//#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("{%x}", *d);
                ++d;
            }
            printf("\r\n");
//#endif
        }
        else
        {
            int val, volt;

            char ch = qData.at(2);
            val = (int)ch;
            ch = qData.at(3);
            val <<= 8;
            volt = val | ch;

            m_daqStatus.fVolt = (float)volt / 10;

#ifdef DBGPRINT
            printf("<%d<<%.2f>>\n", volt, m_Volt);
#endif
            if (bVoltDataFirst)
                bVoltDataFirst = false;

            m_pMain->m_DAQSMutex.lock();
            CopyData(m_pMain->m_daqStatus, m_daqStatus);
            m_pMain->m_DAQSMutex.unlock();
        }
    }
}

void ParserTask::MakeFileData(DAQDATA daqData)
{
    for (int ch=0; ch<daqData.iCh; ch++)
    {
#ifdef DBGPRINT
        printf(">>> FileData : (%d) %04d-%02d-%02d %02d:%02d:%02d.%03d,%.5f\n", ch,
               daqData.iYear, daqData.iMonth, daqData.iDay, daqData.iHour, daqData.iMinute, daqData.iSec, daqData.iMilSec, daqData.fsensorData[ch]);
#endif

        QString writeData, dt, dd;
        dt.sprintf("%04d-%02d-%02d %02d:%02d:%02d.%03d",
                          daqData.iYear, daqData.iMonth, daqData.iDay, daqData.iHour, daqData.iMinute, daqData.iSec, daqData.iMilSec);
        dd.sprintf(",%f", daqData.fsensorData[ch]);
        writeData = dt + dd;
        QString format = "yyyy-MM-dd HH:mm:ss.zzz";
        QDateTime stsensorDateTime = QDateTime::fromString(dt, format);

        FILESAVEDATA fileData;
        if (m_pMain->m_MainConfig.m_iFiletype == 1)      // save by ASCII
        {
            //Write_MqttData(ch, writeData, stsensorDateTime);
            fileData.iType = 1;
        }
        else if (m_pMain->m_MainConfig.m_iFiletype == 2) // save by Binary
        {
            //Write_BinData(ch, sensorData[ch], stsensorDateTime);
            fileData.iType = 2;
        }
        else
            fileData.iType = 0;

        fileData.iCh = ch;
        fileData.stCurrentDateTime = stsensorDateTime;
        fileData.strData = writeData;
        fileData.fValue = daqData.fsensorData[ch];

        m_pMain->m_FileMutex.lock();    ////
        m_pMain->m_FileDatas.append(fileData);
        m_pMain->m_FileMutex.unlock();  ////
    }
}

bool ParserTask::isTimeValid(DAQDATA daqData)
{
    if (daqData.iSec > 59)
        return false;
    if (daqData.iMinute > 59)
        return false;

    if (daqData.iYear < 2017)
        return false;
    if (daqData.iMonth > 12)
        return false;
    if (daqData.iDay > 31)
        return false;
    if (daqData.iHour > 23)
        return false;

    if (daqData.iMilSec > 999)
        return false;

    return true;
}

void ParserTask::TimeCheckAndFill(DAQDATA daqData)
{
    int oldTime, newTime;
    int iGap;
    int iTimeGap = 1000/m_pMain->m_SensorConfig.m_setSample;

    oldTime = m_oldData.iMinute*60000 + m_oldData.iSec*1000 + m_oldData.iMilSec;
    newTime = daqData.iMinute*60000 + daqData.iSec*1000 + daqData.iMilSec;

    iGap = newTime - oldTime;

    if (iGap >= iTimeGap*2)    // data lose
    {
        printf("<<<Data lost --> %d(%d) : %04d-%02d-%02d %02d:%02d:%02d.%03d - %04d-%02d-%02d %02d:%02d:%02d.%03d >>>\n",
               iGap, iTimeGap*2,
               m_oldData.iYear, m_oldData.iMonth, m_oldData.iDay, m_oldData.iHour, m_oldData.iMinute, m_oldData.iSec, m_oldData.iMilSec,
               daqData.iYear, daqData.iMonth, daqData.iDay, daqData.iHour, daqData.iMinute, daqData.iSec, daqData.iMilSec);

        int iter = iGap / iTimeGap - 1;
        FillTime(m_oldData, iter, iTimeGap);
    }
}

void ParserTask::FillTime(DAQDATA oldData, int iter, int iTimeGap)
{
    QString dt;
    QString format = "yyyy-MM-dd HH:mm:ss.zzz";
    dt.sprintf("%04d-%02d-%02d %02d:%02d:%02d.%03d",
                      oldData.iYear, oldData.iMonth, oldData.iDay, oldData.iHour, oldData.iMinute, oldData.iSec, oldData.iMilSec);
    QDateTime oldTime = QDateTime::fromString(dt, format);

    for (int i=0; i<iter; i++)
    {
        DAQDATA fillData;
        CopyData(fillData, oldData);

        QDateTime fillTime;

        fillTime = oldTime.addMSecs(iTimeGap);
        oldTime = fillTime;

        QDate date = fillTime.date();
        QTime time = fillTime.time();

        fillData.iYear = date.year();
        fillData.iMonth = date.month();
        fillData.iDay = date.day();
        fillData.iHour = time.hour();
        fillData.iMinute = time.minute();
        fillData.iSec = time.second();
        fillData.iMilSec = time.msec();

        ///// 1. appedding to SensorDatas vector
        m_pMain->m_SMutex.lock();   /////
        m_pMain->m_SensorDatas.append(fillData);
        //printf("<<<SDatas -> fill : %d(%d)\n", i+1, m_pMain->m_SensorDatas.size());
        m_pMain->m_SMutex.unlock(); /////

        ///// 2. appedding to MQTTDatas vector
        m_pMain->m_MQTTMutex.lock();   /////
        m_pMain->m_MQTTDatas.append(fillData);
        m_pMain->m_MQTTMutex.unlock(); /////

        ///// 3. appedding to FileSaveDatas vector
        MakeFileData(fillData);
    }
}
