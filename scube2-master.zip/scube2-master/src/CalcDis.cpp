﻿#include <QCoreApplication>
#include <QFile>

#include "CalcDis.h"
#include "maintask.h"

CCalcDis::CCalcDis(QObject *parent) :
    QThread(parent)
{
    m_pMainTask = NULL;
    m_bThreadRun = false;
}

void CCalcDis::run()
{
    //QVector<double> disVec = filter(m_vFFir, )
}

////QVector<double> CCalcDis::ReadFIRData()
void CCalcDis::ReadFIRData()
{
    ////QVector<double> FFir;
    m_vFir.clear();
    m_vFFir.clear();

    QString firFile = QCoreApplication::applicationDirPath();
    firFile += "/";
    firFile += CONFIG_DIR;
    firFile += "/";
    firFile += FIR_DATA_FILE;

    QFile file(firFile);
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        printf("# Read Error: %s \n", MAIN_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);
    QString line, text;
    int idx = 0, num = 0;

    while (!stream.atEnd())
    {
        line = stream.readLine();

        /*****
        idx = line.indexOf("=");
        //text = line.mid(idx+1).trimmed(); // 앞뒤 공백 제거
        text = line.mid(idx+1).simplified(); // 앞뒤 공백 제거 + 문자열 사이 여러개 공백을 하나로 대체
        *****/
        text = line.simplified();
        double dd = text.toDouble();
        m_vFir.append(dd);
    }

    file.close();
    printf("Read %s - (%d)\n", FIR_DATA_FILE, m_vFir.length());

    m_vFFir = m_vFir;
    fliplr(m_vFFir, m_vFir);
    /////fliplr();
    /*////
    printf("Fir : %d, FFir : %d\r\n", m_vFir.length(), m_vFFir.length());
    int len = m_vFir.length();
    for (int i; i<len; i++)
        printf("Fir[%d] : %f, FFir[%d] : %f\n\r", i, m_vFir.at(i), i, m_vFFir.at(i));
    ////*/
    return;
}

void CCalcDis::fliplr(QVector<double> &fflip, QVector<double> &fir)
{
    int len = fir.length();
    for (int i; i<len; i++)
    {
        fflip[i] = fir.at(fir.length()-1-i);
        printf("Fir[%d] : %f, FFir[%d] : %f\n\r", i, fir.at(i), len-1-i, fflip.at(len-1-i));
    }
}

void CCalcDis::fliplr()
{
    int len = m_vFir.length();
    for (int i; i<len; i++)
    {
        m_vFFir[i] = m_vFir.at(len-1-i);
        printf("Fir[%d] : %f, FFir[%d] : %f\n\r", i, m_vFir.at(i), len-1-i, m_vFFir.at(len-1-i));
    }
}

/*****
int CCalcDis::getRealArrayScalrDiv(QVector<double> &dQuotient, QVector<double> &dDividend, double dDivisor)
{

    if (dDividend.length() == 0)
        return -1;

    dQuotient = dDividend;

    int len = dDividend.length();
    for (int i; i<len; i++)
    {
        if (!(dDivisor == 0.0))
            dQuotient[i] = dDividend.at(i)/dDivisor;
        else
        {
            if (dDividend.at(i) > 0.0)
                dQuotient[i] = double.Positive_Infinity;
            if (dDividend.at(i) == 0.0)
                dQuotient[i] = double.NaN;
            if (dDividend.at(i) < 0.0)
                dQuotient[i] = double.Negative_Infinity;
        }
    }

    return 0;
}
*****/

/*****
/////void CCalcDis::filter(QVector<double> &b, QVector<double> &a, QVector<double> &x)
void CCalcDis::filter(QVector<double> &b, double a, QVector<double> &x)
{
    int WinSize = 100;
    int Tap = 10;

    QVector<double> filter;
    filter.clear();

    QVector<double> Tx;
    int blen = b.length();
    for (int i=0; i<blen+WinSize; i++)
        Tx.append(x.at(i));

    for (int ii=1; ii<Tap; ii++)
    {
        if (ii > 1)
        {
            for (int i=0; i<blen+WinSize; i++)
                Tx[i] = x.at((WinSize*(ii-1)-(blen/2))+i);
        }

        QVector<double> FWinX;
        QVector<double> FDisX;
        FWinX.resize(WinSize+blen);
        FDisX.resize(WinSize+blen);

        for (int i=0; i<blen+WinSize; i++)
        {
            for (int j=0; j<i+1; j++)
            {
                int k = i-j;

                if (j > 0)
                {
                    if (k < blen && j < WinSize)
                        FWinX[i] =Tx.at(j)*b.at(k);
                }
                else
                {
                    ////if (k < blen && j < WinSize)
                    ////    FWinX[i] =Tx.at(j)*b.at(k);
                }
            }
        }

        if (ii == 1)
        {
            for (int i=blen/2; i<WinSize-1;i++)
                FDisX[i] = FWinX.at()
        }
    }
}
*****/

QVector<double> CCalcDis::filter(QVector<double> &b, QVector<double> &x)
{
    QVector<double> filter;
    filter.clear();

    ////QVector<double> Tx;
    int blen = b.length();
    ////Tx = b;

    filter.resize(x.length());
    ////filter[0] = Tx.at(0) * x.at(0);
    filter[0] = b.at(0) * x.at(0);

    for (int i=1; i<blen; i++)
    {
        filter[i] = 0.0;

        for (int j=0; j<=i; j++)
        {
            int k = i-j;

            ////if (j > 0)
            {
                if (k < blen && j < x.length())
                    ////filter[i] += Tx.at(k) * x.at(j);
                    filter[i] += b.at(k) * x.at(j);
            }
            ////else
            {
                ////if (k < blen && j < WinSize)
                ////    FWinX[i] =Tx.at(j)*b.at(k);
            }
        }
    }

    return filter;
}
