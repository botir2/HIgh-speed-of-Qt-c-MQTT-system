﻿#include <QString>
#include <QFile>

#include "EventQueue.h"

CEventQueue::CEventQueue()
{
    m_queueSize = 0;
}

void CEventQueue::setSize(int size)
{
    m_queueSize = size;
}

int CEventQueue::getSize()
{
    return m_flist.size();
}

void CEventQueue::enQueue(const float &value)
{
    if (m_flist.size() >= m_queueSize)
        m_flist.pop_front();
    m_flist.push_back(value);
    //printf("Queue Size : %d\r\n", m_flist.count());
}

float CEventQueue::deQueue()
{
    float fval = m_flist.first();
    m_flist.pop_front();

    return fval;
}

QString CEventQueue::getQueue()
{
    QString val;
    QString ret;
    float fval;

    ret.clear();

    while (!m_flist.isEmpty())
    {
        fval = m_flist.first();
        m_flist.pop_front();

        //val = QString::number(m_flist.pop_front(), 'f', 5) + ",";
        val.sprintf("%.5f,", fval);
        ret += val;
    }

    return ret;
}

QString CEventQueue::getQueue(QVector<float> eventVect)
{
    QString val;
    QString ret;
    float fval;

    ret.clear();

    while (!m_flist.isEmpty())
    {
        fval = m_flist.first();
        m_flist.pop_front();

        eventVect.append(fval);
        //val = QString::number(m_flist.pop_front(), 'f', 5) + ",";
        val.sprintf("%.5f,", fval);
        ret += val;
    }

    return ret;
}
