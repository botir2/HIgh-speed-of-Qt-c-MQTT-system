﻿#include "cminiseed.h"
#include <QFile>
#include <sys/time.h>
#include <unistd.h>

/***************************************************************************
 * m_record_handler:
 * Saves passed records to the output file.
 ***************************************************************************/
void m_record_handler(char *record, int reclen, void *handlerdata)
{
    if (m_ofp)
    {
        if (fwrite(record, reclen, 1, m_ofp) != 1)
        {
            printf("m_record_handler Error writing to output file\n");
        }
    }
}  /* End of m_record_handler() */

CMiniSeed::CMiniSeed()
{

}

void CMiniSeed::MSeedSave(void *data100, void *data20)
{
    timeval tv1, tv2;
    gettimeofday(&tv1, NULL);

    CMiniSeedData * pMSeedArr100 = (CMiniSeedData *)data100;

    CMiniSeedData ctemp100 = pMSeedArr100[i];

    SaveMiniSeedRing100(ctemp100, i, 100);

    CMiniSeedData ctemp100 = pMSeedArr100[i];
    SaveMninSeedDay(ctemp100, i);

    gettimeofday(&tv2, NULL);

    double nElapsed = difftime(tv2.tv_sec, tv1.tv_sec);
    double milisec = tv2.tv_usec - tv1.tv_usec;
    milisec /= (double)1000000;
    nElapsed += milisec;
}

/***************************************************************************
 * packtraces:
 *
 * Pack all traces in a group using per-MSTrace templates.
 *
 * Returns 0 on success, and -1 on failure
 ***************************************************************************/
void CMiniSeed::packtraces(MSTraceGroup *mstg, flag flush, int packreclen, int encoding, int byteorder, int verbose)
{
    MSTrace *mst;
    int64_t trpackedsamples = 0;
    int64_t trpackedrecords = 0;
    int64_t packedsamples = 0;
    int64_t packedrecords = 0;

    mst = mstg->traces;
    while ( mst )
    {
        if ( mst->numsamples <= 0 )
        {
            mst = mst->next;
            continue;
        }
        trpackedrecords = mst_pack (mst, &m_record_handler, 0, packreclen, encoding, byteorder, &trpackedsamples, flush, verbose-2, (MSRecord *) mst->prvtptr);



        if ( trpackedrecords < 0 )
        {
            printf("Error packing data\n");
        }
        else
        {
            packedrecords += trpackedrecords;
            packedsamples += trpackedsamples;
        }

        mst = mst->next;
    }
}  /* End of packtraces() */

/***************************************************************************
  * freetraces:
  *
  * Free all traces in a group including per-MSTrace templates.
  *
  * Returns 0 on success, and -1 on failure
  ***************************************************************************/
void CMiniSeed::freetraces(MSTraceGroup *mstg)
{
    MSTrace *mst;
    MSRecord *msr;

    /* Free MSRecord structures at mst->prvtptr */
    mst = mstg->traces;
    while ( mst )
    {
        if ( mst->prvtptr )
        {
            msr = (MSRecord *)mst->prvtptr;
            msr_free (&msr);
            mst->prvtptr = 0;
        }

        mst = mst->next;
    }

    mst_freegroup (&mstg);
}  /* End of freetraces() */


int CMiniSeed::SaveMiniSeedRing100(CMiniSeedData cMseed, int nIdx, int nSampleRate)
{
    m_ofp         = 0;
    MSRecord *msr = 0;
    MSTrace *mst = 0;
    MSTraceGroup *mstg = 0;
    struct blkt_1000_s Blkt1000;
    //struct blkt_1001_s Blkt1001;
    int64_t packedtraces  = 0;
    int   packreclen  = 512;
    int   encoding    = 10;
    int   byteorder   = 1;
    int   verbose     = 0;
    char timestr[50];

    double samplerate;
    int samplecnt;
    hptime_t hpdelta;

    //struct tm  user_stime;
    //time_t     tm_st;

    char startTimebuff[200];
    char fileName[200];
    memset(startTimebuff, '\0', sizeof(startTimebuff));
    memset(fileName, '\0', sizeof(fileName));

    // network_station_channel_yyyymmddhhmmss
    if (nSampleRate == 100)
    {
        sprintf(fileName, "%s%s_%s%s_%s_%04d%02d%02d%02d%02d%02d.mseed", RING_PATH,
                 pPara->m_strIinstitution.toStdString().c_str(),
                 pPara->m_strMeasurement.toStdString().c_str(),
                 pPara->m_ParaMSeed[nIdx].m_strPosition.toStdString().c_str(),
                 pPara->m_ParaMSeed[nIdx].m_strChannelH.toStdString().c_str(),
                 cMseed.m_year, cMseed.m_mon, cMseed.m_mday, cMseed.m_hour, cMseed.m_min, cMseed.m_sec);
    }

    if ((m_ofp = fopen(fileName, "wb")) == NULL)
    {
        printf("Error: Cannot open output file: %s (%s)\n",
                 fileName, strerror(errno));
        return -1;
    }

    /* Init MSTraceGroup */
    mstg = mst_initgroup(mstg);
    /* Initialize new MSTrace holer */
    if (!(mst = mst_init(NULL)))
    {
        printf("Error: Cannot initialize MSTrace strcture\n");
        return -1;
    }

    QString strStation;
    strStation =  pPara->m_strIinstitution;
    strStation += pPara->m_strMeasurement;
    strStation += pPara->m_ParaMSeed[nIdx].m_strPosition;

    memcpy(mst->network, pPara->m_ParaMSeed[nIdx].m_strNetwork.toStdString().c_str(), pPara->m_ParaMSeed[nIdx].m_strNetwork.size());
    memcpy(mst->station, strStation.toStdString().c_str(),strStation.size());
    memcpy(mst->channel, pPara->m_ParaMSeed[nIdx].m_strChannelH.toStdString().c_str(), pPara->m_ParaMSeed[nIdx].m_strChannelH.size());
    memcpy(mst->location, pPara->m_ParaMSeed[nIdx].m_strLocation.toStdString().c_str(), pPara->m_ParaMSeed[nIdx].m_strLocation.size());

    samplecnt = nSampleRate;
    samplerate = nSampleRate;
    mst->samplecnt = samplecnt;
    mst->numsamples = samplecnt;
    mst->samprate = samplerate;
    //mst->starttime = ms_timestr2hptime ("2016-09-16T00:00:00.025000");
    sprintf( startTimebuff,  "%04d-%02d-%02dT%02d:%02d:%02d.%06d\n", cMseed.m_year,cMseed.m_mon,cMseed.m_mday,cMseed.m_hour,cMseed.m_min,cMseed.m_sec,cMseed.m_mSec *100);
    /* Convert time string to a high-precision time value */
    mst->starttime = ms_timestr2hptime(startTimebuff);
    if (mst->starttime == HPTERROR)
    {
        printf("Error: Error converting start time: %s\n", timestr);
        return -1;
    }
    hpdelta = (mst->samprate) ? (hptime_t)(HPTMODULUS / mst->samprate) : 0;
    mst->endtime = mst->starttime + (samplecnt - 1) * hpdelta;
    mst->sampletype = 'i';

    /* Allocate memory for the ata samples */
    if (!(mst->datasamples = calloc(mst->numsamples, ms_samplesize(mst->sampletype))))
    {
        printf("Error: Cannot allocate memory for data samples\n");
        return -1;
    }

    if (nSampleRate == 100)
    {
        for (int i=0; i<cMseed.m_vRawData.count(); i++)
        {
            *((int32_t*)mst->datasamples+i)= cMseed.m_vRawData[i];//rand()%200;
        }
    }

    if (!mst_addtracetogroup(mstg, mst))
    {
        printf("Error: Error adding trace to MSTraceGroup\n");
        return -1;
    }

    /* Create an MSRecor template for the MSTrace */
    if (!(msr = msr_init(NULL)))
    {
        printf("Error: Cannot initialize MSRecor strcture\n");
        return -1;
    }

    mst->prvtptr = msr;
    msr->sequence_number = cMseed.m_nSequenceNumber; // jkj


    memcpy(msr->network, pPara->m_ParaMSeed[nIdx].m_strNetwork.toStdString().c_str(),pPara->m_ParaMSeed[nIdx].m_strNetwork.size());
    memcpy(msr->station,strStation.toStdString().c_str(),strStation.size());
    if (nSampleRate == 100)
    {
        memcpy(msr->channel,pPara->m_ParaMSeed[nIdx].m_strChannelH.toStdString().c_str(),pPara->m_ParaMSeed[nIdx].m_strChannelH.size());
    }
    memcpy(msr->location,pPara->m_ParaMSeed[nIdx].m_strLocation.toStdString().c_str(),pPara->m_ParaMSeed[nIdx].m_strLocation.size());
    msr->dataquality ='D';

    /* A blockettes 1000 & 1001 to template */
    memset(&Blkt1000, 0, sizeof(struct blkt_1000_s));
    msr_addblockette(msr, (char *)&Blkt1000, sizeof(struct blkt_1001_s), 1000, 0);

//    memset (&Blkt1001, 0, sizeof(struct blkt_1001_s));
//    msr_addblockette (msr, (char *) &Blkt1001,
//                      sizeof(struct blkt_1001_s), 1001, 0);


    /* Sort MSTraceGroup before packing */
    if (mst_groupsort(mstg, 1))
    {
        printf("Error: mst_groupsort\n");
        return -1;
    }

    /* Pack MSTraceGroup into miniSEE */
    packtraces(mstg, 1, packreclen, encoding, byteorder, verbose);
    packedtraces += mstg->numtraces;
    if (mstg)
        freetraces(mstg);
    if (m_ofp)
        fclose(m_ofp);
}


int CMiniSeed::SaveMninSeedDay(CMiniSeedData cMseed, int nIdx)
{
    QString strYear;
    QString strMon;
    //QString Day;

    strYear.sprintf("%04d", cMseed.m_year);
    strMon.sprintf("%02d", cMseed.m_mon);

    QString strSrcBfileName;
    QString strSrcHfileName;
    QString strDstHfileName;
    QString strDstBfileName;

    QString strSrcPath;
    QString strDstPath;

    strSrcBfileName.sprintf("%s_%s%s_%s_%04d%02d%02d%02d%02d%02d.mseed",
                            pPara->m_strIinstitution.toStdString().c_str(),
                            pPara->m_strMeasurement.toStdString().c_str(),
                            pPara->m_ParaMSeed[nIdx].m_strPosition.toStdString().c_str(),
                            pPara->m_ParaMSeed[nIdx].m_strChannelB.toStdString().c_str(),
                            cMseed.m_year, cMseed.m_mon, cMseed.m_mday, cMseed.m_hour, cMseed.m_min, cMseed.m_sec);

    strSrcHfileName.sprintf("%s_%s%s_%s_%04d%02d%02d%02d%02d%02d.mseed",
                            pPara->m_strIinstitution.toStdString().c_str(),
                            pPara->m_strMeasurement.toStdString().c_str(),
                            pPara->m_ParaMSeed[nIdx].m_strPosition.toStdString().c_str(),
                            pPara->m_ParaMSeed[nIdx].m_strChannelH.toStdString().c_str(),
                            cMseed.m_year, cMseed.m_mon, cMseed.m_mday, cMseed.m_hour, cMseed.m_min, cMseed.m_sec);


    strDstBfileName.sprintf("%s_%s%s_%s_%04d%02d%02d.mseed",
                            pPara->m_strIinstitution.toStdString().c_str(),
                            pPara->m_strMeasurement.toStdString().c_str(),
                            pPara->m_ParaMSeed[nIdx].m_strPosition.toStdString().c_str(),
                            pPara->m_ParaMSeed[nIdx].m_strChannelB.toStdString().c_str(),
                            cMseed.m_year, cMseed.m_mon, cMseed.m_mday);

    strDstHfileName.sprintf("%s_%s%s_%s_%04d%02d%02d.mseed",
                            pPara->m_strIinstitution.toStdString().c_str(),
                            pPara->m_strMeasurement.toStdString().c_str(),
                            pPara->m_ParaMSeed[nIdx].m_strPosition.toStdString().c_str(),
                            pPara->m_ParaMSeed[nIdx].m_strChannelH.toStdString().c_str(),
                            cMseed.m_year, cMseed.m_mon, cMseed.m_mday);

    strSrcPath.sprintf("%s", RING_PATH);
    strDstPath.sprintf("%s", MDAY_PATH);

    QString strSrcBFilePathName = strSrcPath + strSrcBfileName;
    QString strSrcHFilePathName = strSrcPath + strSrcHfileName;

    QString strDstBFilePathName= strDstPath + strDstBfileName;
    QString strDstHFilePathName= strDstPath + strDstHfileName;

    QFile BfileIn(strSrcBFilePathName);
    QFile BfileOut(strDstBFilePathName);

    if (!BfileIn.open(QIODevice::ReadOnly))
    {
        printlog("Error: MiniSeed BfileIn.open %s\n", strSrcBFilePathName.toStdString().c_str());
        return -1;
    }
    if (!BfileOut.open(QIODevice::WriteOnly | QIODevice::Append))
    {
        printlog("Error: MiniSeed BfileOut.open %s\n", strDstBFilePathName.toStdString().c_str());
        return -1;
    }

    QByteArray BbaContents = BfileIn.readAll();
    BfileOut.seek(BfileOut.size());
    BfileOut.write(BbaContents);
    BfileIn.close();
    BfileOut.close();
    BbaContents.clear();

    QFile HfileIn(strSrcHFilePathName);
    QFile HfileOut(strDstHFilePathName);

    if (!HfileIn.open(QIODevice::ReadOnly))
    {
        printf("Error: MiniSeed HfileIn.open %s\n", strSrcHFilePathName.toStdString().c_str());
        return -1;
    }
    if (!HfileOut.open(QIODevice::WriteOnly| QIODevice::Append))
    {
        printf("Error: MiniSeed HfileOut.open %s\n", strDstHFilePathName.toStdString().c_str());
        return -1;
    }

    QByteArray HbaContents = HfileIn.readAll();
    HfileOut.seek(HfileOut.size());
    HfileOut.write(HbaContents);
    HfileIn.close();
    HfileOut.close();
    HbaContents.clear();

    return 0;
}
