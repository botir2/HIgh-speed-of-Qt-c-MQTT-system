﻿#include <QCoreApplication>

#include <QFile>
#include <QTextStream>

#include "IoTSensor.h"
#include "serialtask2.h"
#include "sensorconfig.h"

CSensorConfig::CSensorConfig()
{
    m_command = "SETSAMPLE+200\r\nSETTYPE+1\r\n";
    m_filteron = 0;
    m_sensitivity[0] = m_sensitivity[1] = m_sensitivity[2] = 174.000f;
    m_capacity[0] = m_capacity[1] = m_capacity[2] = 1.000f;
    m_extfactor[0] = m_extfactor[1] = m_extfactor[2] = 2.000f;
    m_offset[0] = m_offset[1] = m_offset[2] = 0.000f;
    m_range[0] = m_range[1] = m_range[2] = 2.000f;
    m_setSample = 200;
    m_setType = 1;
    m_voltage = 3300.000f;
    m_ctemp1 = 0.0f;
    m_ctemp2 = 0.0f;
}

// sensor_config.txt 파일을 읽어 해당 변수에 저장
void CSensorConfig::ReadFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += SENSOR_CONFIG_FILE;

    QFile file(confFile);
    if( !file.open(QFile::ReadOnly | QFile::Text) )
    {
        printf("# Read Error: %s\n", SENSOR_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);
    QString line, text, value1, value2;
    int idx = 0, num = 0;

    while( !stream.atEnd() )
    {
        line = stream.readLine();
        idx = line.indexOf("=");
        //text = line.mid(idx+1).trimmed(); // 앞뒤 공백 제거
        text = line.mid(idx+1).simplified(); // 앞뒤 공백 제거 + 문자열 사이 여러개 공백을 하나로 대체

        switch(num)
        {
        case 0:
        {
            m_command = text;
            QStringList strlist;
            strlist = m_command.split(",");
            value1 = strlist.at(0).trimmed();
            value2 = strlist.at(1).trimmed();
            strlist.clear();
            m_setSample = value1.toInt();
            m_setType = value2.toInt();
        }
            break;
        case 1:
            m_filteron = text.toInt();
            break;
        case 2:
        {
            QString str = text;
            QStringList strlist;
            strlist = str.split(",");
            value1 = strlist.at(0).trimmed();
            m_sensitivity[0] = value1.toFloat();
            value1 = strlist.at(1).trimmed();
            m_sensitivity[1] = value1.toFloat();
            value1 = strlist.at(2).trimmed();
            m_sensitivity[2] = value1.toFloat();
            strlist.clear();
        }
            break;
        case 3:
        {
            QString str = text;
            QStringList strlist;
            strlist = str.split(",");
            value1 = strlist.at(0).trimmed();
            m_capacity[0] = value1.toFloat();
            value1 = strlist.at(1).trimmed();
            m_capacity[1] = value1.toFloat();
            value1 = strlist.at(2).trimmed();
            m_capacity[2] = value1.toFloat();
            strlist.clear();
        }
            break;
        case 4:
        {
            QString str = text;
            QStringList strlist;
            strlist = str.split(",");
            value1 = strlist.at(0).trimmed();
            m_extfactor[0] = value1.toFloat();
            value1 = strlist.at(1).trimmed();
            m_extfactor[1] = value1.toFloat();
            value1 = strlist.at(2).trimmed();
            m_extfactor[2] = value1.toFloat();
            strlist.clear();
        }
            break;
        case 5:
        {
            QString str = text;
            QStringList strlist;
            strlist = str.split(",");
            value1 = strlist.at(0).trimmed();
            m_offset[0] = value1.toFloat();
            value1 = strlist.at(1).trimmed();
            m_offset[1] = value1.toFloat();
            value1 = strlist.at(2).trimmed();
            m_offset[2] = value1.toFloat();
            strlist.clear();
        }
            break;
        case 6:
        {
            QString str = text;
            QStringList strlist;
            strlist = str.split(",");
            value1 = strlist.at(0).trimmed();
            m_range[0] = value1.toFloat();
            value1 = strlist.at(1).trimmed();
            m_range[1] = value1.toFloat();
            value1 = strlist.at(2).trimmed();
            m_range[2] = value1.toFloat();
            strlist.clear();
        }
            break;
        case 7:
            m_exVolt = text.toFloat();
            break;
        case 8:
            m_gFactor = text.toFloat();
            break;
        case 9:
            m_voltage = text.toFloat();
            break;
        case 10:
            m_ctemp1 = text.toFloat();
            break;
        case 11:
            m_ctemp2 = text.toFloat();
            break;
        }
        num++;
    }

    file.close();
    printf("Read %s\n", SENSOR_CONFIG_FILE);
}

// sensor_config.txt 파일에 설정값들 쓰기
void CSensorConfig::WriteFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += SENSOR_CONFIG_FILE;

    QFile file(confFile);
    if( !file.open(QFile::WriteOnly) )
    {
        printf("# Write Error: Cannot open %s \n", SENSOR_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);

    stream << "command = " << m_command << endl;
    stream << "filter = " << m_filteron << endl;
    stream << "sensitivity = " << m_sensitivity[0] << "," << m_sensitivity[1] << "," << m_sensitivity[2] << endl;
    stream << "capacity = " << m_capacity[0] << "," << m_capacity[1] << "," << m_capacity[2] << endl;
    stream << "ext_factor = " << m_extfactor[0] << "," << m_extfactor[1] << "," << m_extfactor[2] << endl;
    stream << "offset = " << m_offset[0] << "," << m_offset[1] << "," << m_offset[2] << endl;
    stream << "range = " << m_range[0] << "," << m_range[1] << "," << m_range[2] << endl;
    stream << "exVolt = " << m_exVolt << endl;
    stream << "g_factor = " << m_gFactor << endl;
    stream << "voltage = " << m_voltage << endl;
    stream << "ctemp1 = " << m_ctemp1 << endl;
    stream << "ctemp2 = " << m_ctemp2 << endl;

    file.close();
    printf("Write %s \n", SENSOR_CONFIG_FILE);
}

CProtocolConfig::CProtocolConfig()
{
    m_dam = 2;
    m_ft = 10;
    m_tcpPeriod = 1;
}

// protocol_config.txt 파일을 읽어 해당 변수에 저장
void CProtocolConfig::ReadFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += PROTOCOL_CONFIG_FILE;

    QFile file(confFile);
    if( !file.open(QFile::ReadOnly | QFile::Text) )
    {
        printf("# Read Error: Cannot open %s \n", PROTOCOL_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);
    QString line, text;
    int idx = 0, num = 0;

    while( !stream.atEnd() )
    {
        line = stream.readLine();
        idx = line.indexOf("=");
        //text = line.mid(idx+1).trimmed(); // 앞뒤 공백 제거
        text = line.mid(idx+1).simplified(); // 앞뒤 공백 제거 + 문자열 사이 여러개 공백을 하나로 대체

        switch(num)
        {
        case 0:
            m_dam = text.toInt();
            break;
        case 1:
            m_ft = text.toInt();
            break;
        case 2:
            m_tcpPeriod = text.toInt();
            break;
        }
        num++;
    }

    file.close();
    printf("Read %s \n", PROTOCOL_CONFIG_FILE);
}

// protocol_config.txt 파일에 설정값들 쓰기
void CProtocolConfig::WriteFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += PROTOCOL_CONFIG_FILE;

    QFile file(confFile);
    if( !file.open(QFile::WriteOnly) )
    {
        printf("# Write Error: Cannot open %s \n", PROTOCOL_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);

    stream << "D-A-M = " << m_dam << endl;
    stream << "F-T = " << m_ft << endl;
    stream << "TcpPeriod = " << m_tcpPeriod << endl;

    file.close();
    printf("Write %s \n", PROTOCOL_CONFIG_FILE);
}

//stAnalysisInfo CAnalysisConfig::m_analysisInfo[ANALYSIS_NUM] = {{0, 0.0f}, {0, 0.0f}};
CAnalysisConfig::CAnalysisConfig()
{
    m_tp = 2;
    m_tv = 20;
    m_AnalDis = 1;
    m_UseDis = true;
    m_AnalFn0 = "P2P";
    m_AnalFn1 = "RMS";
    m_AnalFn2 = "AVG";
    m_AnalFn3 = "STD";
}

// analysis_config.txt 파일을 읽어 해당 변수에 저장
void CAnalysisConfig::ReadFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += ANALYSIS_CONFIG_FILE;

    QFile file(confFile);
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        printf("# Read Error: %s\n", ANALYSIS_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);
    QString line, text;
    int idx = 0, num = 0;

    while (!stream.atEnd())
    {
        line = stream.readLine();
        idx = line.indexOf("=");
        //text = line.mid(idx+1).trimmed(); // 앞뒤 공백 제거
        text = line.mid(idx+1).simplified(); // 앞뒤 공백 제거 + 문자열 사이 여러개 공백을 하나로 대체

        switch(num)
        {
        case 0:
            m_tv = text.toInt();
            break;
        case 1:
            m_tp = text.toInt();
            break;
        case 2:
            m_AnalDis = text.toInt();
            if (m_AnalDis == 1)
                m_UseDis = true;
            else
                m_UseDis = false;
            break;
        case 3:
            m_AnalFn0 = text.toUpper();
            break;
        case 4:
            m_AnalFn1 = text.toUpper();
            break;
        case 5:
            m_AnalFn2 = text.toUpper();
            break;
        case 6:
            m_AnalFn3 = text.toUpper();
            break;
        }
        num++;
    }

    file.close();
    printf("Read %s\n", ANALYSIS_CONFIG_FILE);
}

// analysis_config.txt 파일에 설정값들 쓰기
void CAnalysisConfig::WriteFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += ANALYSIS_CONFIG_FILE;

    QFile file(confFile);
    if( !file.open(QFile::WriteOnly) )
    {
        printf("# Write Error: Cannot open %s \n", ANALYSIS_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);

    stream << "T-V = " << m_tv << endl;
    stream << "T-P = " << m_tp << endl;
    stream << "AnalDis = " << m_AnalDis << endl;
    stream << "AnalFn0 = " << m_AnalFn0.toUpper() << endl;
    stream << "AnalFn1 = " << m_AnalFn1.toUpper() << endl;
    stream << "AnalFn2 = " << m_AnalFn2.toUpper() << endl;
    stream << "AnalFn3 = " << m_AnalFn3.toUpper() << endl;

    file.close();
    printf("Write %s \n", ANALYSIS_CONFIG_FILE);
}
