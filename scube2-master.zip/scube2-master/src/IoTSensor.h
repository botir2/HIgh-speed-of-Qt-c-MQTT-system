﻿#ifndef IOTSENSOR_H
#define IOTSENSOR_H

#include <QObject>
#include <QDateTime>
#include <QVector>

#define MAX_CH  3

//#define DAQBUG      1
//#define DBGPRINT    1
#define DBGFILESAVE 1

#define KT_IOTMAKERS    1
#define ARIA_USE 1
#define KT_DEBUG   1
#define NCUBE_172   1

#define CONFIG_DIR              "conf"
#define MAIN_CONFIG_FILE        "main_config.txt"
#define NCUBE_CONFIG_FILE       "ncube_config.txt"
#define SENSOR_CONFIG_FILE      "sensor_config.txt"

#define PROTOCOL_CONFIG_FILE    "protocol_config.txt"
#define ANALYSIS_CONFIG_FILE    "analysis_config.txt"

#define FIR_DATA_FILE           "FFIR_coefficients.csv"

#define DATA_FILEPATH           "data"
#define SMARTCS_DATA_FILEPATH   "smartcs"
#define KTIOT_DATA_FILEPATH     "ktiot"

#define IMG_FILEPATH            "img"
#define RAW_FILEPATH            "raw"
#define ASCII_FILEPATH          "ASCII"
#define BINARY_FILEPATH         "BIN"
#define DIS_FILEPATH            "ACCTODIS"

#ifdef KT_IOTMAKERS
#define KTIOTM_CONFIG_FILE      "KtIoTM_config.txt"
#define KTIOTM_SUBCONFIG_FILE   "KtIoTM_Subconfig.txt"

#define KEY "70776400000000000000000000000000"
//#define KEY "70776400000000000000000000000000"
//#define KEY "7077640000000000"

#define SECS10MINS  600
#endif  // KT_IOTMAKERS

typedef struct {
    int iGPSLock;
    int iYear, iMonth, iDay, iHour, iMinute, iSec, iMilSec;
    int iCh;
    float   fsensorData[MAX_CH];
} DAQDATA;

typedef struct {
    int iLat1, iLat2; // GPS Latitude
    int iLon1, iLon2; // GPS Longitude
    bool bisNorth, bisEest;   // N/S indicator, E/W indicator
} DAQGPSDATA;

typedef struct {
    float fTemp;   // Temperature
    float fHumi;   // Humidity
    float fVolt;   // Voltage
} DAQSTATUS;

typedef struct {
    int iType;
    int iCh;
    float fValue;
    QString strData;
    QDateTime stCurrentDateTime;
} FILESAVEDATA;

typedef struct {
    int iYear, iMonth, iDay, iHour, iMinute, iSec, iMilSec;
    int iType;      // Normal stat(1). or Kt stat(2).
    int iCh;
    bool bEvent;
    QVector<float> rawVect;
    DAQGPSDATA daqGPS;
    DAQSTATUS daqStatus;
} CALCVECT;

typedef struct {
    int iType;
    QString strContents;
} nCUBEDATA;

#ifdef KT_IOTMAKERS
// channel structure
typedef struct
{
    QString SlaveDevID;
    QString Passwd;
    QString SensorValueTag;
    QString TempValueTag;
    QString BatValueTag;
} KTIOTMSLAVE;

typedef struct {
    QString dt;
    float   data;
} RAWDATA;
#endif  // KT_IOTMAKERS

extern void CopyData(DAQDATA &dst, DAQDATA &src);
extern void CopyData(DAQGPSDATA &dst, DAQGPSDATA &src);
extern void CopyData(DAQSTATUS &dst, DAQSTATUS &src);

#endif // IOTSENSOR_H
