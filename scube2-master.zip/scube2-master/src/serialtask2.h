﻿#ifndef SERIALTASK2_H
#define SERIALTASK2_H

#include <QThread>
#include <QMutex>
#include <QObject>
#include <QDebug>

#include <QVector>
#include <QTimer>

#include "maintask.h"

// Qt5.x 이상부터 지원하는 QtSerialPort를 사용해도 됨.

class QSocketNotifier;

class CSerialTask2 : public QObject
{
    Q_OBJECT
public:
    explicit CSerialTask2(QObject *parent = 0);

signals:
    void CompletePacket(QByteArray data);
    void finished();

public slots:
    void runProc();

    void OnParserTimer();
    void ReadSerial();
    void WriteData(const char *data, int datasize, bool isRespone);

public:
    CMainTask *m_pMain;
    QMutex  m_RMutex;
    QVector<QByteArray> m_RPackets;
    QString m_sPort;
    QTimer m_ParserTimer;

    void OpenPort()
    {
        qDebug() << __func__ << QThread::currentThread();
        OpenSerial(m_sPort);
        //Parser();
    }

    int OpenSerial(QString sPort);
    void Parser();

    bool CheckSum(QByteArray data);
    void StorePacket(QByteArray data);

private:
    int m_fd;
    QSocketNotifier *m_notifier;
    QString m_strbuff;
    bool m_isRespone;

    int buffIdx;
    char buff[256];

    char ch1;
    char ch2;
    bool bStartDLE;
    bool bSTX;
    bool bStuffing;
    bool bEndDLE;
    //bool bETX;
};

#endif // SERIALTASK2_H
