﻿#include "serialtask.h"

#include <stdio.h>

#include <QSerialPort>
#include <QTime>

//QString m_strbuff2;





CSerialTask::CSerialTask(QObject *parent) : QObject(parent)
{
    m_serial = new QSerialPort(this);
    m_serial->setPortName("/dev/ttyAMA0");
    m_serial->setBaudRate(QSerialPort::Baud115200);
    m_serial->setDataBits(QSerialPort::Data8);
    m_serial->setParity(QSerialPort::NoParity);
    m_serial->setStopBits(QSerialPort::OneStop);
    m_serial->setFlowControl(QSerialPort::NoFlowControl);

    if(m_serial->open(QIODevice::ReadWrite))
    {
        connect(m_serial, SIGNAL(readyRead()), this, SLOT(ReadSerial()));
        printf("Open SerialPort: /dev/ttyAMA0, Baud115200\n");
    }
    else
    {
        printf("### Error: Open SerialPort: /dev/ttyAMA0\n");

        delete m_serial;
        m_serial = NULL;
    }

    //m_strbuff2.clear();
}



CSerialTask::~CSerialTask()
{
    printf("Destroy CSerialTask");

    if(m_serial == NULL)
        return;

    m_serial->write("END\r\n", 5);

    if( m_serial->isOpen() )
    {
        m_serial->close();
    }
}

// 시리얼 데이터 읽기 - serial read slot 함수
void CSerialTask::ReadSerial()
{
    static int buffIdx = 0;
    static char buff[24] = {0,};

    QByteArray readData = m_serial->readAll();
    for(int i = 0; i < readData.size(); i++)
    {
        char ch = readData.at(i);
        if(buffIdx == 0 && ch == '@') // 첫 데이터 검사
        {
            buff[buffIdx++] = ch;
        }
        else if(buffIdx == 1 && ch == '0') // 두번째 데이터 검사
        {
            buff[buffIdx++] = ch;
        }
        else if(buffIdx >= 2) // 이후 유효데이터로 인정하고 받음.
        {
            buff[buffIdx++] = ch;
            if(ch == '~')
            {
                QString data = buff;
                //printf("uart data=%s\n", data.toStdString().c_str());
                data = data.mid(2, 5);
                //printf("data=%s\n", data.toStdString().c_str());

                emit CompletePacket(data);

                buffIdx = 0;
                memset(buff, 0, 24);
            }
        }

    }

    // 패킷수신 에러 또는 깨진 패킷
    if(buffIdx >= 24)
    {
        printf("Error: Read Serial\n");
        memset(buff, 0, 24);
        buffIdx = 0;
    }
}


//void CSerialTask::ReadSerial()
//{
//    static int buffIdx = 0;
//    static char buff[24] = {0,};

//    static QTime time;
//    static int samplCount = 0;


//    QByteArray readData = m_serial->readAll();

//    m_strbuff2 += QString(readData);

//    while( (m_strbuff2.indexOf("~")) > 0 )
//    {
//       QString data = m_strbuff2.left(8); // left 는 카운트
//       m_strbuff2 = m_strbuff2.mid(8); // mid 는 인덱스(0부터 시작)

//     // printf("data=%s\n", data.toStdString().c_str());
//     // printf("data=%s\n", data.toLatin1().data());

//       samplCount++;
//       if(samplCount == 1)
//       {
//           time.start();
//       }
//       else if(samplCount == 300)
//       {
//           int elapsedTime = time.elapsed();
//           printf("########### time = %d ms\n", elapsedTime);
//           samplCount = 0;
//       }
//    }
//}

void CSerialTask::WriteData(const char *data, int datasize)
{
    if(m_serial == NULL)
        return;

    m_serial->write(data, datasize);
    m_serial->flush();

    //printf("UART-Write: %s\n", data);
}




