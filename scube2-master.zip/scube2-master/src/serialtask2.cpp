﻿#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <termios.h>
#include <fcntl.h>

#include <QSocketNotifier>
#include <QTime>  // 처리속도 체크

#include "IoTSensor.h"
#include "serialtask2.h"

#include "maintask.h"

CSerialTask2::CSerialTask2(QObject *parent) : QObject(parent)
{
    m_fd = -1;
    m_strbuff.clear();
    m_isRespone = false;

    buffIdx = 0;
    //buff[128] = {0,};
    memset(buff, 0x00, 128);

    ch1 = '0';
    ch2 = '0';
    bStartDLE = false;
    bSTX = false;
    bStuffing = false;
    bEndDLE = false;
    //bETX = false;

    m_RPackets.clear();
}

void CSerialTask2::runProc()
{
    /*****
    while (1)
    {
        QThread::usleep(100);
        Parser();
    }
    *****/
    OpenPort();
}

int CSerialTask2::OpenSerial(QString sPort)
{
    // O_RDWR|O_NOCTTY|O_NDELAY
    m_fd = open(sPort.toStdString().c_str(), O_RDWR|O_NOCTTY|O_NONBLOCK);
    if (m_fd < 0)
    {
        printf("# Error: Cannot open SerialPort: %s\n", sPort.toStdString().c_str());
        return 0;
    }

    termios tio;
    memset(&tio, 0, sizeof(tio));
    tio.c_cflag = B115200;
    tio.c_cflag |= CS8;
    tio.c_cflag |= CLOCAL | CREAD;
    tio.c_iflag = IGNPAR;
    tio.c_oflag = 0;
    tio.c_lflag = 0;
    tio.c_cc[VTIME] = 0;
    tio.c_cc[VMIN] = 1;

    tcflush(m_fd, TCIFLUSH);
    tcsetattr(m_fd, TCSANOW, &tio);

    m_notifier = new QSocketNotifier(m_fd, QSocketNotifier::Read, this);
    connect(m_notifier, SIGNAL(activated(int)), this, SLOT(ReadSerial()), Qt::QueuedConnection);

    connect(&m_ParserTimer, SIGNAL(timeout()), this, SLOT(OnParserTimer()));

    printf("Open SerialPort: %s, Baud115200\n", sPort.toStdString().c_str());

    ////m_ParserTimer.start(2);

    return 1;
}

void CSerialTask2::ReadSerial()
{
    char tempBuff[256] = {0,};
    QByteArray rData;

    if (m_pMain->m_isTimeSet == false)
        return;

    int readSize = read(m_fd, &tempBuff, 256);
    if (readSize <= 0)
    {
#ifdef DBGPRINT
        printf("# Error read size = %d\n", readSize);
#endif
        return;
    }
#ifdef DBGPRINT
    else
        printf("\nRead <-- %d\r\n", readSize);
#endif

#ifdef DBGPRINT
    for (int i=0; i<readSize; i++)
         printf("(%x)", tempBuff[i]);
    printf("\r\n");
#endif

    rData.append(tempBuff, readSize);

    ////m_RMutex.lock();    ////
    m_RPackets.append(rData);
    //printf("<R> -> %d(%d)\n", rData.size(), m_RPackets.size());
    ////m_RMutex.unlock();  ////
    ////QThread::usleep(1000);
    ///

    Parser();
}

void CSerialTask2::OnParserTimer()
{
    //m_ParserTimer.stop();
    ////Parser();

    //m_ParserTimer.start(2);
}

void CSerialTask2::Parser()
{
    ////printf("[[[[[[[[[PARSER-START]]]]]]]]]\n");
    ////QThread::sleep(1);

    QByteArray rData;
    char tempBuff[256] = {0,};

    //while (1)
    {
        //printf("*");
        //QThread::usleep(100);
        rData.clear();

        ////m_RMutex.lock();    ////

        if (m_RPackets.size() > 0)
        {
            rData = m_RPackets.first();
            ////printf("[R] ----> %d(%d)\n", rData.size(), m_RPackets.size());
        }

        ////m_RMutex.unlock();  ////

        //printf("+");
        int readSize = rData.size();
        if (readSize > 0)
        {
            memset(tempBuff, 0x00, 256);
            memcpy(tempBuff, rData.data(), rData.size());

            //m_RMutex.lock();    ////
            m_RPackets.removeFirst();
            //m_RMutex.unlock();  ////

            for (int i=0; i<readSize; i++)
            {
                ch1 = tempBuff[i];

////#ifdef DAQBUG
                if (bStartDLE == true && ch1 == 0x10 && i == 0 && readSize > 1 && bStuffing == false)
                {
                    if (tempBuff[1] == 0x02)
                        bStartDLE = false;
                }
////#endif

                if (bStuffing == true && bStartDLE == true && bSTX == true)
                {
                    if (ch1 == 0x10)    // Stuff
                    {
                        bStuffing = false;
                        buff[buffIdx++] = ch1;
#ifdef DBGPRINT
                        printf("[%x]", ch1);
#endif
                        int j = i+1;
                        if (j >= readSize)
                            break;

                        ch2 = tempBuff[j];
                        i++;
                        if ((ch2 == 0x03) && ((buff[0] == 0x01 && buffIdx > 13) || (buff[0] == 0xa0 && buffIdx > 12) || (buff[0] == 0xb0 && buffIdx > 6)))
                        {
                            bSTX = true;
//#ifdef DBGPRINT
                            printf("Error - ETX][%x:%x]\r\n", ch1, ch2);
//#endif
                            // then, End of Serial packet -- so, processing analysis
                            bStartDLE = false;
                            bSTX = false;
                            bEndDLE = false;
                            bStuffing = false;
#ifdef DBGPRINT
                            printf("<DLE:ETX>-%d\n\r", buffIdx);
#endif
                            //QByteArray data = QByteArray::fromRawData(buff, buffIdx);
                            QByteArray data;
                            data.append(buff, buffIdx);
#ifdef DBGPRINT
                            //
                            char *d = data.data();
                            for (int i=0; i<data.size(); i++)
                            {
                                printf("{%x}", *d);
                                ++d;
                            }
                            printf("Process Analysis\r\n");
#endif                //
                            ////emit CompletePacket(data);
                            StorePacket(data);

                            buffIdx = 0;
                            memset(buff, 0, 256);
                        }
                        else if (ch2 == 0x10)
                        {
                            i--;
                        }
                        else
                        {
                            buff[buffIdx++] = ch2;
                        }
                    }
                    else if (ch1 == 0x03)   // ETX
                    {
                        // then, End of Serial packet -- so, processing analysis
                        bStartDLE = false;
                        bSTX = false;
                        bEndDLE = false;
                        bStuffing = false;
#ifdef DBGPRINT
                        printf("<DLE:ETX>-%d\n\r", buffIdx);
#endif
                        //QByteArray data = QByteArray::fromRawData(buff, buffIdx);
                        QByteArray data;
                        data.append(buff, buffIdx);
#ifdef DBGPRINT
                        //
                        char *d = data.data();
                        for (int i=0; i<data.size(); i++)
                        {
                            printf("{%x}", *d);
                            ++d;
                        }
                        printf("Process Analysis\r\n");
#endif                  //
                        ////emit CompletePacket(data);
                        StorePacket(data);

                        buffIdx = 0;
                        memset(buff, 0, 256);
                    }
                    else
                    {
                        bStartDLE = false;
                        bSTX = false;
                        bEndDLE = false;
                        bStuffing = false;

                        printf("Error Packet !!! -[%x]\n\r", ch1);
                    }
                }
                else if (ch1 == 0x10 && bStartDLE == false)   // Check Start DLE:STX
                {
                    bStartDLE = true;
#ifdef DBGPRINT
                    printf("[DLE:");
#endif
                    int j = i+1;
                    if (j >= readSize)
                        break;

                    ch2 = tempBuff[j];
                    i++;
                    if (ch2 == 0x02)
                    {
                        bSTX = true;
#ifdef DBGPRINT
                        printf("STX]");
#endif
                    }
                }
                else if (ch1 == 0x10 && bStartDLE == true && bSTX == true)   // Check stuffing
                {
                    int j = i+1;
                    if (j >= readSize)
                    {
                        bStuffing = true;
                        break;
                    }

                    ch2 = tempBuff[j];
                    i++;
                    if (ch2 == 0x10)
                    {
                        buff[buffIdx++] = ch1;
                    }
                    else if (ch2 == 0x03)
                    {
                        // then, End of Serial packet -- so, processing analysis
                        bStartDLE = false;
                        bSTX = false;
                        bEndDLE = false;
                        bStuffing = false;
#ifdef DBGPRINT
                        printf("<DLE:ETX>-%d\n\r", buffIdx);
#endif
                        //QByteArray data = QByteArray::fromRawData(buff, buffIdx);
                        QByteArray data;
                        data.append(buff, buffIdx);
#ifdef DBGPRINT
                        //
                        char *d = data.data();
                        for (int i=0; i<data.size(); i++)
                        {
                            printf("{%x}", *d);
                            ++d;
                        }
#endif                //
                        ////emit CompletePacket(data);
                        StorePacket(data);

                        buffIdx = 0;
                        memset(buff, 0, 256);

                        // processing analysis
                        // Sensor data : len - 17bytes ~~
                        // Loc. data : len - 16bytes
                        // Temp./Humi. data : len - 10bytes
                    }
                    else
                    {
                        bStartDLE = false;
                        bSTX = false;
                        bEndDLE = false;
                        bStuffing = false;

                        printf("Error Packet !!! -[%x:%x]\r\n", ch1, ch2);
                    }
                }
                else if (bStartDLE == true && bSTX == true)
                {
                    buff[buffIdx++] = ch1;
#ifdef DBGPRINT
                    printf("[%x]", ch1);
#endif
                }
            } // for
        }
    }
}

void CSerialTask2::WriteData(const char *data, int datasize, bool isRespone)
{
    if (m_fd < 0)
        return;

    // true 이면, 명령에 대한 응답 메시지가 있음.
    m_isRespone = isRespone;

    write(m_fd, data, datasize);
    ////printf("UART-Write: %s\n", data);
}

bool CSerialTask2::CheckSum(QByteArray data)
{
    char checkSum = 0x00;
    char *d = data.data();
    int dSize = data.size() - 1;

    for (int i=0; i<dSize; i++)
    {
        ////printf("{%x}", *d);
        checkSum = checkSum ^ *d;
        ++d;
    }

    ////printf("\n----CheckSum : %x\n", checkSum);
    if (checkSum == data.at(dSize))
        return true;
    else
        return false;
}

void CSerialTask2::StorePacket(QByteArray data)
{
    QByteArray qData = data;

#ifdef DBGPRINT
    char *d = qData.data();
    for (int i=0; i<qData.size(); i++)
    {
        printf("{%x}", *d);
        ++d;
    }
    printf("\r\n");
#endif

    if (!CheckSum(data))
    {
        printf("\n----------------CheckSum Error\n");
        char *d = qData.data();
        for (int i=0; i<qData.size(); i++)
        {
            printf("{%x}", *d);
            ++d;
        }
        printf("\r\n");
        return;
    }

    m_pMain->m_PMutex.lock();    /////

    m_pMain->m_Packets.append(qData);
    //printf("[>R]Pakcets -> %d(%d)\n", qData.size(), m_pMain->m_Packets.size());

    ////QByteArray pData;
    ////pData = m_Packets.first();

    ////emit ProcessPacket(pData);
    ////m_Packets.removeFirst();

    m_pMain->m_PMutex.unlock();  /////
}
