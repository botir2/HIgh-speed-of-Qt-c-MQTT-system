#include <QFile>
#include <QDateTime>
#include <QDir>

#include "maintask.h"

#include "filesavetask.h"

FileSaveTask::FileSaveTask(QObject *parent) :
    QObject(parent)
{
}

void FileSaveTask::runProc(void)
{
    FILESAVEDATA fileData;

    while (1)
    {
        m_pMain->m_FileMutex.lock();    /////

        if (m_pMain->m_FileDatas.size() > 0)
        {
            fileData = m_pMain->m_FileDatas.first();
            //printf(">>>File Data : (%d:%d) %s\n", fileData.iCh, fileData.iType)
            if (fileData.iType == 2)        // Bin Data
                Write_BinData(fileData);
            else if (fileData.iType == 1)   // Mqtt Data
                Write_MqttData(fileData);
            //else
                //Write_SendData(fileData);

#ifdef KT_IOTMAKERS
            if (m_pMain->m_ProtocolConfig.m_dam == 4 || m_pMain->m_ProtocolConfig.m_dam == 5 ||
                    m_pMain->m_ProtocolConfig.m_dam == 6 || m_pMain->m_ProtocolConfig.m_dam == 8)
                Write_KtIoTData(fileData);
#endif
            m_pMain->m_FileDatas.removeFirst();
        }

        m_pMain->m_FileMutex.unlock();  /////

        QThread::usleep(1000);
    }
}

void FileSaveTask::Write_BinData(FILESAVEDATA fileData)
{
    qint64 nEpoch = fileData.stCurrentDateTime.toMSecsSinceEpoch();
    QByteArray binEpoch, binData;
    QByteArray BbinEpoch, BbinData;

    //printf("Epoch : %d, Value : %f\n", nEpoch, value);

    binEpoch = QByteArray::fromRawData(reinterpret_cast<char *>(&nEpoch), sizeof(qint64));
    binData = QByteArray::fromRawData(reinterpret_cast<char *>(&fileData.fValue), sizeof(float));
    //binEpoch.append(binData);
    int len = binEpoch.size();
    for (int i=0; i<len; i++)
        BbinEpoch[i] = binEpoch[len-1-i];
    len = binData.size();
    for (int i=0; i<len; i++)
        BbinData[i] = binData[len-1-i];

    binEpoch.append(binData);
    BbinEpoch.append(BbinData);
    len = BbinEpoch.size();

#ifdef DBGPRINT
    printf("Epoch : %d, qint64 = %d Value : %f, float = %d\n", nEpoch, sizeof(qint64), value, sizeof(float));
    printf("size = %d ", len);
    for (int i=0; i<len; i++)
        printf("[%x]", binEpoch.at(i));
    printf("\n");
    for (int i=0; i<len; i++)
        printf("[%x]", BbinEpoch.at(i));
    printf("\n");
#endif

    //CheckDirectory();
    QString strFile = GetDataFileName(fileData.iCh, fileData.stCurrentDateTime);
    QFile file(strFile);
    if (!file.open(QFile::WriteOnly | QFile::Append))
    {
        printf("# Data file Open Error: %s\n", strFile.toStdString().data());
        return;
    }

    QDataStream stream(&file);
    stream.writeRawData(BbinEpoch.data(), len);
    file.flush();
    file.close();
}

void FileSaveTask::Write_MqttData(FILESAVEDATA fileData)
{
    QString strFile = GetDataFileName(fileData.iCh, fileData.stCurrentDateTime);
    QFile file(strFile);
    if (!file.open(QFile::WriteOnly | QFile::Append | QFile::Text))
    {
        printf("# Data file Open Error: %s\n", strFile.toStdString().data());
        return;
    }

    //printf(">>>File Data : (%d:%d) %s\n", fileData.iCh, fileData.iType, strFile.toStdString().c_str());

    QTextStream stream(&file);
    stream << fileData.strData + "\n";
    file.flush();
    file.close();
}

void FileSaveTask::Write_SendData(FILESAVEDATA fileData)
{
    QString strFile = GetDataFileName(fileData.iCh, fileData.stCurrentDateTime);
    QFile file(strFile);
    if (!file.open(QFile::WriteOnly | QFile::Append | QFile::Text))
    {
        printf("# Data file Open Error: %s\n", strFile.toStdString().data());
        return;
    }

    QTextStream stream(&file);
    stream << fileData.strData + "\n";
    file.flush();
    file.close();
}

void FileSaveTask::CheckDirectory(void)
{
    QString dirPath = m_pMain->m_MainConfig.m_FileSaveDir;
    dirPath += "/";
    dirPath += DATA_FILEPATH;
    dirPath += "/";

    QDir dir(dirPath);
    if (!dir.exists())
    {
        dir.mkpath(dirPath);
    }
}

void FileSaveTask::CheckDirectory(QString dirPath)
{
    QDir dir(dirPath);
    if (!dir.exists())
    {
        dir.mkpath(dirPath);
    }
}

QString FileSaveTask::GetDataFileName(int ch, QDateTime curDT)
{
    QString dirPath = m_pMain->m_MainConfig.m_FileSaveDir;
    dirPath += "/";
    dirPath += DATA_FILEPATH;
    dirPath += "/";
    dirPath += SMARTCS_DATA_FILEPATH;
    dirPath += "/";
    dirPath += RAW_FILEPATH;
    dirPath += "/";
    if (m_pMain->m_MainConfig.m_iFiletype == 1)
        dirPath += ASCII_FILEPATH;
    else if (m_pMain->m_MainConfig.m_iFiletype == 2)
        dirPath += BINARY_FILEPATH;

    CheckDirectory(dirPath);

    dirPath += "/";
    dirPath += m_pMain->m_MainConfig.m_UID;
    dirPath += "_";
    dirPath += m_pMain->m_MainConfig.m_DN;
    dirPath += "_";
    dirPath += m_pMain->m_MainConfig.m_DID;
    dirPath += "_";
    if (m_pMain->m_CHnum > 1)
    {
        QString asc;
        asc.sprintf("%1d", ch);

        dirPath += asc;
        dirPath += "_";
    }
    dirPath += curDT.toString("yyyyMMddhh");
    //printf("file : %s\n", dirPath.toStdString().c_str());
    if (m_pMain->m_MainConfig.m_iFiletype == 1)
        dirPath += ".csv";
    else if (m_pMain->m_MainConfig.m_iFiletype == 2)
        dirPath += ".bin";

    return dirPath;
}

#ifdef KT_IOTMAKERS
QString FileSaveTask::GetDataFileName5Min(int ch, QDateTime curDT)
{
    QString dirPath = m_pMain->m_MainConfig.m_FileSaveDir;
    dirPath += "/";
    dirPath += DATA_FILEPATH;
    dirPath += "/";
    dirPath += KTIOT_DATA_FILEPATH;
    dirPath += "/";
    dirPath += m_pMain->m_IoTM.m_ServiceID;
    dirPath += "/";

    //// making 5min interval
    qint64 eTime = curDT.toMSecsSinceEpoch();
    qint64 min5 = eTime % (300*1000);  // 300 : 5mins
    eTime = eTime - min5;
    QDateTime min5DT;
    min5DT.setMSecsSinceEpoch(eTime);
    min5DT = min5DT.toLocalTime();

    dirPath += min5DT.toString("yyyyMMdd");
    dirPath += "/";
    dirPath += min5DT.toString("hh");
    dirPath += "/";

    CheckDirectory(dirPath);

#if XX
    dirPath += m_pMain->m_IoTM.m_DevID;
    dirPath += "_";
    if (m_pMain->m_CHnum > 1)
    {
        dirPath += m_pMain->m_IoTM.m_SensingDataTag[ch];
        dirPath += "_";
    }
#else
    if (m_pMain->m_CHnum > 1)
    {
        dirPath += m_pMain->m_IoTM.m_SubDevID[ch];
    }
    else
    {
        dirPath += m_pMain->m_IoTM.m_DevID;
    }
#endif //XX
    dirPath += "_";
    dirPath += min5DT.toString("yyyyMMddhhmm");
    //printf("file : %s\n", dirPath.toStdString().c_str());
    dirPath += ".bin";

    return dirPath;
}

void FileSaveTask::Write_KtIoTData(FILESAVEDATA fileData)
{
    qint64 nEpoch = fileData.stCurrentDateTime.toMSecsSinceEpoch();
    QByteArray binEpoch, binData;
    QByteArray BbinEpoch, BbinData;

    //printf("Epoch : %d, Value : %f\n", nEpoch, value);

    binEpoch = QByteArray::fromRawData(reinterpret_cast<char *>(&nEpoch), sizeof(qint64));
    binData = QByteArray::fromRawData(reinterpret_cast<char *>(&fileData.fValue), sizeof(float));
    //binEpoch.append(binData);
    int len = binEpoch.size();
    for (int i=0; i<len; i++)
        BbinEpoch[i] = binEpoch[len-1-i];
    len = binData.size();
    for (int i=0; i<len; i++)
        BbinData[i] = binData[len-1-i];

    binEpoch.append(binData);
    BbinEpoch.append(BbinData);
    len = BbinEpoch.size();

#ifdef DBGPRINT
    printf("Epoch : %d, qint64 = %d Value : %f, float = %d\n", nEpoch, sizeof(qint64), fileData.fValue, sizeof(float));
    printf("size = %d ", len);
    for (int i=0; i<len; i++)
        printf("[%x]", binEpoch.at(i));
    printf("\n");
    for (int i=0; i<len; i++)
        printf("[%x]", BbinEpoch.at(i));
    printf("\n");
#endif

    //CheckDirectory();
    QString strFile = GetDataFileName5Min(fileData.iCh, fileData.stCurrentDateTime);
    QFile file(strFile);
    if (!file.open(QFile::WriteOnly | QFile::Append))
    {
        printf("# Data file Open Error: %s\n", strFile.toStdString().data());
        return;
    }

    QDataStream stream(&file);
    stream.writeRawData(BbinEpoch.data(), len);
    file.flush();
    file.close();
}
#endif
