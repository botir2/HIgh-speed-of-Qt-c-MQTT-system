﻿#ifndef MAINTASK_H
#define MAINTASK_H

#include <QObject>
#include <QMutex>
#include <QTimer>

#include <QTcpSocket>
#include <QProcess>

#include "IoTSensor.h"

#include "qmqtt.h"
#include "converter.h"

#ifdef KT_IOTMAKERS
#include "ktiotmakers.h"
#endif
#include "mainconfig.h"
#include "cubeconfig.h"
#include "sensorconfig.h"
#include "EventQueue.h"
////#include "camerathread.h"
#include "CalcDis.h"

class CMainTask : public QObject
{
    Q_OBJECT

public:
    explicit CMainTask(QObject *parent = 0);
    virtual ~CMainTask();

signals:
    void SendSensorPacket(const char *data, int datasize, bool isRespone);
    void ProcessPacket(QByteArray qData);
    void stopTimer(void);
    void beginTimer(void);
    void quitProgram(void);

public slots:
    void OnReadSocket();
    void nCubeConnected();
    void nCubeDisConnected();

    void OnSendTimer();
    void On10MinsTimer();
#ifdef KT_IOTMAKERS
   // void OnOneSecTimer();
#endif

    void ConnectedMqtt();
    void DisconnectedMqtt();

    void done(int exitCode, QProcess::ExitStatus exitStatus);
    void publishMsg(QString msg);
    void send2nCube(QString msg);
    void send2nCubeEvent(QString msg);

public:
    void setTimefrom(bool bDAQ) { m_setTimefromDAQ = bDAQ; }
    void setDAQTime();
    void setDAQFilter();
    void setDAQVoltage();

    void SendCommand(bool isEnd);
    void setConverter();
    void startTimer();
    void setSensorSampling();

    QString getSerialPort() { return m_MainConfig.m_SerialPort; }

    QMutex m_PMutex;
    QVector<QByteArray> m_Packets; // Serial Packets

    QMutex m_FileMutex;
    QVector<FILESAVEDATA> m_FileDatas;  // File save datas

    QMutex m_MQTTMutex;
    QVector<DAQDATA> m_MQTTDatas;  // MQTT datas for realtime transfer

    QMutex m_SMutex;
    QVector<DAQDATA> m_SensorDatas;

    QMutex m_CalcMutex;
    QVector<CALCVECT> m_CalcDatas;

    QMutex m_nCubeMutex;
    QVector<nCUBEDATA> m_nCubeDatas;

    QMutex m_DAQSMutex;
    DAQGPSDATA m_daqGPS;
    DAQSTATUS m_daqStatus;

    QProcess *m_extProc;

public:
#ifdef KT_IOTMAKERS
    void InitKTIoT();
#endif

    void Init2nCube();
    void Stop2nCube();

    void InitMqtt();

    void ClearSensorData();
    void calcTriggerValue();

    void AttachCmdFuncPtr();

    void Publish(float rawdata);
    void CheckEvent(int ch, float rawdata);
    void PublishEvent(int ch);
    void SendData(int ch);
    void SendEventAnalData(int ch);

    // 자료구조 맵(m_funcMap)의 함수포인터와 연결될 함수들
    void SetReboot(QString val);
    void SetSensorConfig(QString val);
    void SetCommunicationConfig(QString val);
    void SetMainConfig(QString val);
    void SetAnalysisConfig(QString val);
    void SetPacketConfig(QString val);
    // 센서상태 요청메시지 처리. 함수포인터에 연결해서 같이 처리
    void ReqSensorState(QString val);

    unsigned int GetSendTimeValue();
    void GetSamplingRate();

    void CheckDirectory(QString dirPath);
    void Take_aPicture(int mode, DAQDATA qData);

    QTcpSocket *m_socket;   // for connect to nCube
    bool m_bnCubeConn;

    QMQTT::Client *m_mqttClient;    // Realtime data
    QMutex mqttBMutex;
    bool m_bMQTTConnected;

    //QProcess m_extProc;

    int m_CHnum;            // Number of Channals

#ifdef KT_IOTMAKERS
    KtIoTMakers m_IoTM;     // KtIoT Makers I/F
    QVector<RAWDATA> m_KtRawData[MAX_CH]; // for KtIoT Makers
    bool m_isConnectedKTIoTM;
    int m_KtSendCount;
    QTimer m_OneSecTimer;
    int m_10minCount;

    QMutex m_KtCalcMutex;
    QVector<CALCVECT> m_KtCalcDatas;
    QMutex m_Kt10MinCalcMutex;
    QVector<CALCVECT> m_Kt10MinCalcDatas;

    int m_statSecs;
    int m_stat10m;
    int m_statIdx;
#endif

    QTimer m_sendTimer;
    QTimer m_10MinsTimer;

    QString m_rawString[MAX_CH];        // 센서데이터를 샘플링레이트 만큼 문자열로 저장.구분자는 ","

    QVector<QByteArray> m_rawData[MAX_CH];
    QVector<float> m_rawVect[MAX_CH];   // 센서데이터를 저장하는 벡터
    QVector<float> m_eventVect[MAX_CH];
    CEventQueue m_eventQueue[MAX_CH];

    bool m_isEvent[MAX_CH];
    bool m_isMadeData[MAX_CH];
    int m_eventDataCount[MAX_CH];

    float m_triggerValue[MAX_CH];
    float m_rawavg[MAX_CH]; // 센서데이터 평균값(tcp 전송용)
    float m_p2p[MAX_CH];    // p2p(tcp 전송용)
    float m_rms[MAX_CH];    // rms(tcp 전송용)

    bool m_isFirstStart;
    bool m_setTimefromDAQ;
    bool m_isTimeSet;
    int m_DAQFilterOn;

    int m_samplingRate;
    unsigned int m_sendTimeValue;
    unsigned int m_sendTimeCount;   // tcp 전송 주기(시간)제어

    char m_SensorCmd;

    int m_DAQYear, m_DAQMonth, m_DAQDay, m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec;

    int m_Lat1, m_Lat2; // GPS Latitude
    int m_Lon1, m_Lon2; // GPS Longitude
    bool m_isNorth, m_isEest;   // N/S indicator, E/W indicator

    float m_Temp;   // Temperature
    float m_Humi;   // Humidity
    float m_Volt;   // Voltage

    char m_commandBuff[128]; // 센서설정(SET) 명령어(패킷)

    CConverter m_converter;

    // 디바이스 제어/설정 명령처리 함수포인터와 맵
    typedef void (CMainTask::*pfn_setting)(QString val);
    QMap<QString, pfn_setting>  m_funcMap;

    // Analysis Functions
    typedef float (CMainTask::*pfn_analysis)(QVector<float> rawVect);
    pfn_analysis m_AnalFn0;
    pfn_analysis m_AnalFn1;
    pfn_analysis m_AnalFn2;
    pfn_analysis m_AnalFn3;
    QMap<QString, pfn_analysis> m_AnalMap;

    MainConfig m_MainConfig;
    CCubeConfig m_CubeConfig;
    CSensorConfig m_SensorConfig;
    CProtocolConfig m_ProtocolConfig;
    CAnalysisConfig m_AnalysisConfig;

    ////CCameraThread m_CameraTh;
    CCalcDis *m_pCalcDisTh;
};


#endif // MAINTASK_H
