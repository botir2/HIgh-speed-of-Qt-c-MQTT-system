#ifndef PROCESSTASK_H
#define PROCESSTASK_H

#include <QObject>
#include <QThread>
#include <QDebug>

#include "IoTSensor.h"
#include "maintask.h"

class ProcessTask : public QObject
{
    Q_OBJECT
public:
    explicit ProcessTask(QObject *parent = 0);

signals:
    void send2nCubeEvent(QString msg);

public slots:
    void runProc(void);

public:
    CMainTask *m_pMain;

    QString m_rawString[MAX_CH];        // String data for sensor, during sampling rate...delimeter = ","

    //QVector<QByteArray> m_rawData[MAX_CH];
    QVector<float> m_rawVect[MAX_CH];   // Vector for Sensor Datas
    QVector<float> m_eventVect[MAX_CH];
    CEventQueue m_eventQueue[MAX_CH];

    bool m_isEvent[MAX_CH];
    bool m_isMadeData[MAX_CH];
    int m_eventDataCount[MAX_CH];
    float m_triggerValue[MAX_CH];

#ifdef KT_IOTMAKERS
    QVector<float> m_KtrawVect[MAX_CH];         // Vector for Sensor Datas ... Normal Period
    QVector<float> m_Kt10MinrawVect[MAX_CH];    // Vector for Sensor Datas ... 10Mins Period
    int m_KtSendCount;
#endif

    void Init();

    void ProcData(DAQDATA qData);
    void CheckEvent(int ch, DAQDATA qData);
    void PublishEvent(int ch);
    void SendEventAnalData(int ch);

    void calcTriggerValue();
};

#endif // PROCESSTASK_H
