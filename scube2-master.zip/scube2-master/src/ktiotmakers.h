﻿#ifndef KTIOTMAKERS_H
#define KTIOTMAKERS_H

#include <QObject>
#include <QString>

#include "IoTSensor.h"
//#include "sensorconfig.h"

class KtIoTMakers : public QObject
{
    Q_OBJECT
public:
    explicit KtIoTMakers(QObject *parent = 0);

signals:

public slots:

public:
    int m_nSubDevNum;      // Dev Num (for multi channel)
    int m_nSensorNum;    // Sensor Num = Sub Num

    bool m_bServiceID;

    // [0] : X, [1] : Y, [2] : Z

    bool m_bSubDevID[MAX_CH];
    bool m_bSubDevPW[MAX_CH];

    bool m_bSensingDataTag[MAX_CH];

    bool m_bStat_MinTag[MAX_CH];
    bool m_bStat_MaxTag[MAX_CH];
    bool m_bStat_SecTag[MAX_CH];

    bool m_bStat10m_MinTag[MAX_CH];
    bool m_bStat10m_MaxTag[MAX_CH];
    bool m_bStat10m_AvgTag[MAX_CH];
    bool m_bStat10m_StdTag[MAX_CH];

    bool m_bVoltTag;
    bool m_bBattTag;
    bool m_bTempTag;

    QString m_ServiceID;

    QString m_SubDevID[MAX_CH];
    QString m_SubDevPW[MAX_CH];

    QString m_SensingDataTag[MAX_CH];

    QString m_Stat_MinTag[MAX_CH];
    QString m_Stat_MaxTag[MAX_CH];
    QString m_Stat_SecTag[MAX_CH];

    QString m_Stat10m_MinTag[MAX_CH];
    QString m_Stat10m_MaxTag[MAX_CH];
    QString m_Stat10m_AvgTag[MAX_CH];
    QString m_Stat10m_StdTag[MAX_CH];

    QString m_VoltTag;
    QString m_BattTag;
    QString m_TempTag;

    int m_Stat_Sec;
    int m_GatherDataN;

    int KtIoTInit();
    void iotM_Term(void);
    void LoadSubConfig();

    QString getDevID();
    QString getDevIDfromConfig();
    QString m_DevID;

    int SendData(int ch, QVector<RAWDATA> RawVect);
    int SendMinMax(int ch, float minVal, float maxVal, QString dt);
    int Send10minStat(int ch, float minVal, float maxVal, float avgVal, float stdVal, QString dt);

public:
//    QList<KTIOTMSLAVE> m_SlaveDevList;
};

#endif // KTIOTMAKERS_H
