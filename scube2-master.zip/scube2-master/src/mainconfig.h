﻿#ifndef MAINCONFIG_H
#define MAINCONFIG_H

#include <QString>

class MainConfig
{
public:
    MainConfig();

public:
    void ReadFile();
    void WriteFile();

    QString  m_PFIP;     // Server ip
    QString  m_UID;      // User ID - User define
    QString  m_DN;       // Device name - 1:S_Cube, 2:BGateway, 3:OMS - fixed
    QString  m_DID;      // Device ID - User define

    QString m_SerialPort;
    QString m_FileSaveDir;

    int     m_iFiletype;     // File save type for NodeZip - 0: no save, 1: ASCII, 2: Binary (default = 1)
    int     m_iAutotrans;    // File transfer to NodeZip - 0: no trans, 1: trans (default = 1)
    int     m_iUseCamera;    // Use Camera - 0: not use, 1: use
    int     m_iSetTimePeriod;   // period of time set : * 10mins
};

#endif // MAINCONFIG_H
