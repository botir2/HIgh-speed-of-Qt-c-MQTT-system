#ifndef SERIALTASK_H
#define SERIALTASK_H

#include <QObject>


class QSerialPort;


class CSerialTask : public QObject
{
    Q_OBJECT
public:
    explicit CSerialTask(QObject *parent = 0);
    virtual ~CSerialTask();

signals:
    void CompletePacket(QString data);

public slots:
    void ReadSerial();
    void WriteData(const char *data, int datasize);

public:
    void WriteData();

private:
    QSerialPort *m_serial;
};


#endif // SERIALTASK_H
