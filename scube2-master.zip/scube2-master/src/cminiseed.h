﻿#ifndef CMINISEED_H
#define CMINISEED_H

#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>

#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <string>
#include <sys/stat.h>

#include <QString>
#include <QVector>
#include <QStringList>

#include <libmseed.h>

#include "cminiseeddata.h"

static FILE * m_ofp = 0;
static void m_record_handler(char *record, int reclen, void *handlerdata);

class CMiniSeed
{
public:
    CMiniSeed();

    void packtraces(MSTraceGroup *mstg, flag flush, int packreclen, int encoding, int byteorder, int verbose);
    void freetraces(MSTraceGroup *mstg);
    int SaveMiniSeedRing100(CMiniSeedData cMseed, int nIdx, int nSampleRate);
    int SaveMiniSeedRing20(CMiniSeedData cMseed, int nIdx, int nSampleRate);
    int SaveMninSeedDay(CMiniSeedData cMseed, int nIdx);
    void MSeedSave(void *data100, void *data20);
};

#endif // CMINISEED_H
