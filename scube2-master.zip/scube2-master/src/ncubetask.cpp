#include "IoTSensor.h"
#include "maintask.h"

#include "ncubetask.h"

NCubeTask::NCubeTask(QObject *parent) :
    QObject(parent)
{
    m_sendTimeCount = 0;
}

void NCubeTask::Init()
{
    connect(&m_sendTimer, SIGNAL(timeout()), this, SLOT(OnSendTimer()));
    startTimer();
}

void NCubeTask::startTimer()
{
    m_sendTimer.start(m_pMain->m_ProtocolConfig.m_ft*1000);
    printf("Tcp-Send enable : %d secs\r\n", m_pMain->m_ProtocolConfig.m_ft);
}

void NCubeTask::stopTimer(void)
{
    m_sendTimer.stop();
    m_sendTimeCount = 0;
}

void NCubeTask::beginTimer(void)
{
    startTimer();
}

void NCubeTask::runProc(void)
{
    nCUBEDATA qData;

    while (1)
    {
        QThread::usleep(100);

        m_pMain->m_nCubeMutex.lock();   ////

        if (m_pMain->m_nCubeDatas.size() > 0)
        {
            qData = m_pMain->m_nCubeDatas.first();
        }

        m_pMain->m_nCubeMutex.unlock(); ////

        if (qData.strContents.size() > 0)
        {
            Publish(qData);
            //PublishEvent(qData);

            m_pMain->m_nCubeMutex.lock();   ////
            m_pMain->m_nCubeDatas.removeFirst();
#ifdef DBGPRINT
            printf("<<< nCubeDatas = (%d: %d) %d\n", qData.iType, qData.strContents.size(), m_pMain->m_nCubeDatas.size());
#endif
            m_pMain->m_nCubeMutex.unlock(); ////
            qData.strContents.clear();
        }
    }
}

void NCubeTask::Publish(nCUBEDATA qData)
{
#ifdef XX
    if (m_pMain->m_ProtocolConfig.m_dam == 1 || m_pMain->m_ProtocolConfig.m_dam == 4 || m_pMain->m_ProtocolConfig.m_dam == 5 || m_pMain->m_ProtocolConfig.m_dam == 7)
        return;

//#ifdef DBGPRINT
    printf("Count=%d\r\n", m_pMain->m_sendTimeCount);
//#endif

    if (m_pMain->m_sendTimeCount >= m_pMain->m_ProtocolConfig.m_tcpPeriod)
    {
        m_pMain->m_sendTimeCount = 0;
#endif
        QString strContainerName;
        QString strContents;

        if (qData.iType == 1)   //// Anal Data
            strContainerName = m_pMain->m_CubeConfig.m_tcpCtnAnal;
        else
            return;

#ifdef NCUBE_172
        strContents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}<EOF>",
#else
        strContents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}",
#endif
                         strContainerName.toStdString().c_str(),
                         qData.strContents.toStdString().c_str());

        // send to nCube
        //m_pMain->m_socket->write(strContents.toStdString().c_str());
        emit send2nCube(strContents);

        printf("Tcp-Send:%s\r\n", strContents.toStdString().c_str());
        fflush(stdout);
#ifdef XX
    }
#endif
}


void NCubeTask::PublishEvent(nCUBEDATA qData)
{
    if (m_pMain->m_ProtocolConfig.m_dam == 1 || m_pMain->m_ProtocolConfig.m_dam == 4 || m_pMain->m_ProtocolConfig.m_dam == 5 || m_pMain->m_ProtocolConfig.m_dam == 7)
        return;

    QString strContainerName;
    QString strContents;

    if (qData.iType == 2)   //// Event Data
        strContainerName = m_pMain->m_CubeConfig.m_tcpCtnRawe;
    else
        return;

#ifdef NCUBE_172
    strContents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}<EOF>",
#else
    strContents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}",
#endif
                     strContainerName.toStdString().c_str(),
                     qData.strContents.toStdString().c_str());

    // 앤큐브에 전송한다. 결과적으로 서버플랫폼의 DB에 데이터가 저장됨
    m_pMain->m_socket->write(strContents.toStdString().c_str());

    printf("Tcp-Send:%s\r\n", strContents.toStdString().c_str());
    fflush(stdout);
}

//
void NCubeTask::OnSendTimer()
{
    m_sendTimeCount++;

    Publish();
}

void NCubeTask::Publish()
{
    if (m_pMain->m_ProtocolConfig.m_dam == 1 || m_pMain->m_ProtocolConfig.m_dam == 4 || m_pMain->m_ProtocolConfig.m_dam == 5 || m_pMain->m_ProtocolConfig.m_dam == 7)
        return;

//#ifdef DBGPRINT
    printf("Count=%d\r\n", m_sendTimeCount);
//#endif

    if (m_sendTimeCount >= m_pMain->m_ProtocolConfig.m_tcpPeriod)
    {
        m_sendTimeCount = 0;

        for (int ch=0; ch<m_pMain->m_CHnum; ch++)
        {
            m_pMain->m_nCubeMutex.lock();   ////

            nCUBEDATA qData;

            if (m_pMain->m_nCubeDatas.size() > 0)
            {
                qData = m_pMain->m_nCubeDatas.first();
            }

            m_pMain->m_nCubeMutex.unlock(); ////

            if (qData.strContents.size() > 0)
            {
                Publish(qData);
                //PublishEvent(qData);

                m_pMain->m_nCubeMutex.lock();   ////
                m_pMain->m_nCubeDatas.removeFirst();
//#ifdef DBGPRINT
                printf("<<< nCubeDatas = (%d: %d) %d\n", qData.iType, qData.strContents.size(), m_pMain->m_nCubeDatas.size());
//#endif
                m_pMain->m_nCubeMutex.unlock(); ////
                qData.strContents.clear();
            }
        }
    }
}
