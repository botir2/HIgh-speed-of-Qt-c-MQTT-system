/*
 * File: disp_reconstruction_step2_func_initialize.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 22-Feb-2018 15:59:29
 */

/* Include files */
#include "rt_nonfinite.h"
#include "disp_reconstruction_step2_func.h"
#include "disp_reconstruction_step2_func_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void disp_reconstruction_step2_func_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * File trailer for disp_reconstruction_step2_func_initialize.c
 *
 * [EOF]
 */
