#ifndef CALCTASK_H
#define CALCTASK_H

#include <QObject>
#include <QThread>
#include <QDebug>

#include "IoTSensor.h"
#include "maintask.h"


class CalcTask : public QObject
{
    Q_OBJECT
public:
    explicit CalcTask(QObject *parent = 0);

signals:

public slots:
    void runProc(void);

public:
    CMainTask *m_pMain;

    float Analysis_P2P(QVector<float> rawVect);
    float Analysis_Rms(QVector<float> rawVect);
    float Analysis_Avg(QVector<float> rawVect);
    float Analysis_Min(QVector<float> rawVect);
    float Analysis_Max(QVector<float> rawVect);
    float Analysis_Std(QVector<float> rawVect);

    // Analysis Functions
    typedef float (CalcTask::*pfn_analysis)(QVector<float> rawVect);
    pfn_analysis m_AnalFn0;
    pfn_analysis m_AnalFn1;
    pfn_analysis m_AnalFn2;
    pfn_analysis m_AnalFn3;
    QMap<QString, pfn_analysis> m_AnalMap;

    float m_AnalValue0[3];    //
    float m_AnalValue1[3];    //
    float m_AnalValue2[3];    //
    float m_AnalValue3[3];    //

    void AttachAnalysisFuncPtr();
    void MakeStatistics(CALCVECT qData);
};

#endif // CALCTASK_H
