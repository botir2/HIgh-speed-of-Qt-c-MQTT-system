﻿#ifndef CONVERTER_H
#define CONVERTER_H

#include <QObject>

// 센서에서 받은 adc 데이터를 옵션에 맞게 변환시키는 클래스

class CConverter
{
public:
    CConverter();

    /****
    void SetSensitivity(float value)    { m_sensitivity = value; }
    void SetCapacity(float value)       { m_capacity = value; }
    void SetExtFactor(float value)      { m_extFactor = value; }
    ****/

    void SetSensorType(char sensorType);
    float SensorData(int ch, int adcData);

//private:
public:
    //void AttachFunctionPtr();

    // 함수포인터 배열에 연결 ----------------------
    float ToAccel(int ch, int adcData);
    float ToStrain(int ch, int adcData);
    float ToDisplacement(int ch, int adcData);
    float ToWind(int ch, int adcData);
    // ----------------------------------------

    // 함수포인터
    typedef float (CConverter::*pfn_AdcToSensor)(int ch, int adcData);
    // 함수포인터의 배열 - AttachFunctionPtr() 에서 함수들을 연결(등록)한다.
    pfn_AdcToSensor m_funcArray[4];
    pfn_AdcToSensor m_func;

    int m_funcIdx;

    float m_sensitivity[3];
    float m_capacity[3];
    float m_extFactor[3];
    float m_offset[3];
    float m_range[3];
    float m_exVolt;
    float m_gFactor;
    float m_voltage;
};

#endif // CONVERTER_H
