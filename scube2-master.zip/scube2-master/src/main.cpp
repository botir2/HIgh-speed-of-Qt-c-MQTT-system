﻿#include <QCoreApplication>
#include <QSharedMemory>
#include <QCommandLineParser>
#include <QThread>

#include "IoTSensor.h"

#include "maintask.h"
#include "parsertask.h"
#include "serialtask2.h"
#include "filesavetask.h"
#include "processtask.h"
#include "mqtttask.h"
#include "ncubetask.h"
#include "calctask.h"

#include "camerathread.h"

void CopyData(DAQDATA &dst, DAQDATA &src)
{
    dst.iYear = src.iYear;
    dst.iMonth = src.iMonth;
    dst.iDay = src.iDay;
    dst.iHour = src.iHour;
    dst.iMinute = src.iMinute;
    dst.iSec = src.iSec;
    dst.iMilSec = src.iMilSec;

    dst.iCh = src.iCh;

    dst.fsensorData[0] = src.fsensorData[0];
    dst.fsensorData[1] = src.fsensorData[1];
    dst.fsensorData[2] = src.fsensorData[2];
}

void CopyData(DAQGPSDATA &dst, DAQGPSDATA &src)
{
    dst.iLat1 = src.iLat1;
    dst.iLat2 = src.iLat2;
    dst.iLon1 = src.iLon1;
    dst.iLon2 = src.iLon2;
    dst.bisEest = src.bisEest;
    dst.bisNorth = src.bisNorth;
}

void CopyData(DAQSTATUS &dst, DAQSTATUS &src)
{
    dst.fHumi = src.fHumi;
    dst.fTemp = src.fTemp;
    dst.fVolt = src.fVolt;
}


int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);

    QCoreApplication::setApplicationName("ITSSCube2");
    QCoreApplication::setApplicationVersion("2.0.3");

    QCommandLineParser parser;
    parser.setApplicationDescription("S_Cube-v2 - Smart C&S");
    parser.addHelpOption();
    parser.addVersionOption();

    // A boolean option with a single name (-t)
    QCommandLineOption setDAQTimeOption("t", QCoreApplication::translate("main", "Set time from DAQ"));
    parser.addOption(setDAQTimeOption);

    QCommandLineOption viewVersionOption("v", QCoreApplication::translate("main", "View Version Info."));
    parser.addOption(viewVersionOption);

    // Process the actual command line arguments given by the user
    parser.process(app);

    //const QStringList args = parser.positionalArguments();
    // source is args.at(0), destination is args.at(1)

    printf("[[%s]]\n", app.arguments().at(0).toStdString().c_str());
    printf("[[%s : %s]]\n", app.applicationName().toStdString().c_str(), app.applicationVersion().toStdString().c_str());

    bool viewVersion = parser.isSet(viewVersionOption);
    if (viewVersion)
    {
        printf("[[%s : %s]]\n", app.applicationName().toStdString().c_str(), app.applicationVersion().toStdString().c_str());
        //printf("Version : %s\n", app.applicationVersion().toStdString().c_str());
        //return app.exec();
        exit(0);
    }

#ifdef XX
    QSharedMemory shared();
    shared.setNativeKey("TrueCatSCube2");
    if (!shared.create(512, QSharedMemory::ReadWrite))
    {
        printf("SCube2 already running !!!\n");
        exit(0);
    }
    else
    {
        printf("%s, %s\n", shared.key().toStdString().c_str(), shared.nativeKey().toStdString().c_str());
    }
#endif

    bool setDAQTime = parser.isSet(setDAQTimeOption);
//#ifdef DBGPRINT
    printf("DAQ time to Systime : %d\r\n", setDAQTime ? 1 : 0);
//#endif

    CMainTask mainTask;

    QThread serialThread;
    CSerialTask2 serialTask2;
    serialTask2.m_pMain = &mainTask;
    serialTask2.m_sPort = mainTask.getSerialPort();
    ////serialTask2.OpenPort();

    QThread parserThread;
    ParserTask parserTask;
    parserTask.m_pMain = &mainTask;

    QThread filesaveThread;
    FileSaveTask filesaveTask;
    filesaveTask.m_pMain = &mainTask;

    QThread processThread;
    ProcessTask procTask;
    procTask.m_pMain = &mainTask;
    procTask.Init();

    QThread calcThread;
    CalcTask calcTask;
    calcTask.m_pMain = &mainTask;

    QThread mqttThread;
    MQTTTask mqttTask;
    mqttTask.m_pMain = &mainTask;

    QThread nCubeThread;
    NCubeTask nCubeTask;
    nCubeTask.m_pMain = &mainTask;

    ////QObject::connect(&serialTask2, SIGNAL(CompletePacket(QByteArray)), &mainTask, SLOT(CompletePacket(QByteArray)), Qt::DirectConnection);
    QObject::connect(&mainTask, SIGNAL(SendSensorPacket(const char*, int, bool)), &serialTask2, SLOT(WriteData(const char*, int, bool)), Qt::DirectConnection);
    QObject::connect(&mainTask, SIGNAL(stopTimer(void)), &nCubeTask, SLOT(stopTimer(void)));
    QObject::connect(&mainTask, SIGNAL(beginTimer(void)), &nCubeTask, SLOT(beginTimer(void)));
    QObject::connect(&mainTask, SIGNAL(quitProgram(void)), &app, SLOT(quit()), Qt::QueuedConnection);

    serialTask2.moveToThread(&serialThread);
    parserTask.moveToThread(&parserThread);
    filesaveTask.moveToThread(&filesaveThread);
    procTask.moveToThread(&processThread);
    calcTask.moveToThread(&calcThread);
    mqttTask.moveToThread(&mqttThread);
    nCubeTask.moveToThread(&nCubeThread);

    serialThread.setObjectName("SerialTH");
    parserThread.setObjectName("ParserTH");
    filesaveThread.setObjectName("FileSaveTH");
    processThread.setObjectName("ProcessTH");
    calcThread.setObjectName("CalcTH");
    mqttThread.setObjectName("MQTTTH");
    nCubeThread.setObjectName("NCubeTH");

    QObject::connect(&serialThread, SIGNAL(started()), &serialTask2, SLOT(runProc()));
    QObject::connect(&serialTask2, SIGNAL(finished()), &serialThread, SLOT(quit()));
    QObject::connect(&serialThread, SIGNAL(finished()), &app, SLOT(quit()));

    QObject::connect(&parserThread, SIGNAL(started()), &parserTask, SLOT(runProc()));
    //QObject::connect(&parserTask, SIGNAL(finished()), &parserThread, SLOT(quit()));

    QObject::connect(&filesaveThread, SIGNAL(started()), &filesaveTask, SLOT(runProc()));
    //QObject::connect(&filesaveTask, SIGNAL(finished()), &filesaveThread, SLOT(quit()));

    QObject::connect(&processThread, SIGNAL(started()), &procTask, SLOT(runProc()));
    //QObject::connect(&procTask, SIGNAL(finished()), &processThread, SLOT(quit()));
    QObject::connect(&procTask, SIGNAL(send2nCubeEvent(QString)), &mainTask, SLOT(send2nCubeEvent(QString)));

    QObject::connect(&calcThread, SIGNAL(started()), &calcTask, SLOT(runProc()));
    //QObject::connect(&calcTask, SIGNAL(finished()), &calcThread, SLOT(quit()));

    QObject::connect(&mqttThread, SIGNAL(started()), &mqttTask, SLOT(runProc()));
    //QObject::connect(&mqttTask, SIGNAL(finished()), &mqttThread, SLOT(quit()));
    QObject::connect(&mqttTask, SIGNAL(publishMsg(QString)), &mainTask, SLOT(publishMsg(QString)));

    QObject::connect(&nCubeThread, SIGNAL(started()), &nCubeTask, SLOT(Init()));
    //QObject::connect(&nCubeTask, SIGNAL(finished()), &nCubeThread, SLOT(quit()));
    QObject::connect(&nCubeTask, SIGNAL(send2nCube(QString)), &mainTask, SLOT(send2nCube(QString)));

    ////mqttTask.InitMqtt();
    ////QThread::sleep(1);

    setbuf(stdout, NULL);

    parserThread.start();
    filesaveThread.start();
    processThread.start();
    calcThread.start();
    mqttThread.start();
    nCubeThread.start();
    serialThread.start();

    QThread::sleep(1);

    mainTask.setSensorSampling();
    mainTask.SendCommand(true);

    procTask.m_eventQueue[0].setSize(mainTask.m_samplingRate*0.3);   // 1/3 of Sampling
    procTask.m_eventQueue[1].setSize(mainTask.m_samplingRate*0.3);   // 1/3 of Sampling
    procTask.m_eventQueue[2].setSize(mainTask.m_samplingRate*0.3);   // 1/3 of Sampling

    mainTask.setTimefrom(setDAQTime);

    mainTask.setDAQTime();
    mainTask.setDAQFilter();
    mainTask.setDAQVoltage();

    QThread::sleep(1);

    return app.exec();
}


