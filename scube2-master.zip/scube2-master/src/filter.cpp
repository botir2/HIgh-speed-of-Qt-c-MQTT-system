/*
 * File: filter.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 22-Feb-2018 15:59:29
 */

/* Include files */
#include "rt_nonfinite.h"
#include "disp_reconstruction_step2_func.h"
#include "filter.h"

/* Function Definitions */

/*
 * Arguments    : const double b[169]
 *                const double x[32000]
 *                double y[32000]
 * Return Type  : void
 */
void filter(const double b[169], const double x[32000], double y[32000])
{
  int k;
  int j;
  memset(&y[0], 0, 32000U * sizeof(double));
  for (k = 0; k < 169; k++) {
    for (j = k; j + 1 < 32001; j++) {
      y[j] += b[k] * x[j - k];
    }
  }
}

/*
 * File trailer for filter.c
 *
 * [EOF]
 */
