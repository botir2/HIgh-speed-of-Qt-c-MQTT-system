﻿#include <QCoreApplication>

#include <QFile>
#include <QTextStream>

#include "IoTSensor.h"
#include "cubeconfig.h"

CCubeConfig::CCubeConfig()
{
    m_tasIP = "localhost";
    m_tcpCtnAnal = "anal";
    m_tcpCtnRawe = "rawe";
    m_tcpCtnCtrl = "ctrl";
    m_tcpCtnCnfg = "config";
    m_mqttServer = "210.105.85.7";
    m_mqttId = "smartcs:1:cs001";
    m_mqttTopic = "/mobius-yt/smartcs:1:cs001/realtime";
    m_respTopic = "/mobius-yt/smartcs001/ch1_state";
    m_eventTopic = "/mobius-yt/smartcs:1:cs001/rawe";
    m_disTopic = "/mobius-yt/smartcs:1:cs001/disValue";
}

// ncube_config.txt 파일을 읽어 해당 변수에 저장
void CCubeConfig::ReadFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += NCUBE_CONFIG_FILE;

    QFile file(confFile);
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        printf("# Read Error: %s \n", NCUBE_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);
    QString line, text;
    int idx=0, num = 0;

    while (!stream.atEnd())
    {
        line = stream.readLine();
        idx = line.indexOf("=");
        //text = line.mid(idx+1).trimmed(); // 앞뒤 공백 제거
        text = line.mid(idx+1).simplified(); // 앞뒤 공백 제거 + 문자열 사이 여러개 공백을 하나로 대체

        switch(num)
        {
        case 0:
            m_tasIP = text;
            break;
        case 1:
            m_tcpCtnAnal = text;
            break;
        case 2:
            m_tcpCtnRawe = text;
            break;
        case 3:
            m_tcpCtnCtrl = text;
            break;
        case 4:
            m_tcpCtnCnfg = text;
            break;
        case 5:
            m_mqttServer = text;
            break;
        case 6:
            m_mqttId = text;
            break;
        case 7:
            m_mqttTopic = text;
            break;
        case 8:
            m_respTopic = text;
            break;
        case 9:
            m_eventTopic = text;
            break;
        case 10:
            m_disTopic = text;
            break;
        }
        num++;
    }

    file.close();
    printf("Read %s \n", NCUBE_CONFIG_FILE);
}
