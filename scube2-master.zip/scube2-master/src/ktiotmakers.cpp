﻿#include <stdio.h>

#include <QCoreApplication>
#include <QSettings>
//#include <QTextStream>
#include <QFile>
#include <QDebug>

#include "IoTSensor.h"

#ifdef KT_IOTMAKERS
#include "base.h"
#include "packet.h"
#include "iotmakers.h"

#include "ktiotmakers.h"

KtIoTMakers::KtIoTMakers(QObject *parent) :
    QObject(parent)
{
    m_nSubDevNum = 0;
    m_nSensorNum = 0;    // Sensor Num = Sub Num

    m_bServiceID = false;

    for (int ch=0; ch<MAX_CH; ch++)
    {
        m_bSubDevID[ch] = false;
        m_bSubDevPW[ch] = false;

        m_bSensingDataTag[ch] = false;

        m_bStat_MinTag[ch] = false;
        m_bStat_MaxTag[ch] = false;
        m_bStat_SecTag[ch] = false;

        m_bStat10m_MinTag[ch] = false;
        m_bStat10m_MaxTag[ch] = false;
        m_bStat10m_AvgTag[ch] = false;
        m_bStat10m_StdTag[ch] = false;
    }

    m_bVoltTag = false;
    m_bBattTag = false;
    m_bTempTag = false;
}

static void __if411_res_body_handler(void* pbody)
{
#ifdef KT_DEBUG
    im_pktBody_print_serialized_string((IMPacketBodyPtr)pbody);
#endif
    printf("respCd=[%s]\n", (char*)im_body411_req_get_respCd(pbody));
}

int KtIoTMakers::Send10minStat(int ch, float minVal, float maxVal, float avgVal, float stdVal, QString dt)
{
    int rc = 0;

    if (m_nSubDevNum > 1)
        im_411_init_with_devid((char *)m_SubDevID[ch].toStdString().c_str());
    else
        im_411_init();

    // Time
    im_411_append_new_colecRow_with_occDt((char *)dt.toStdString().c_str());

    im_411_put_numdata((char *)m_Stat10m_MinTag[ch].toStdString().c_str(), (double)minVal);
    im_411_put_numdata((char *)m_Stat10m_MaxTag[ch].toStdString().c_str(), (double)maxVal);
    im_411_put_numdata((char *)m_Stat10m_AvgTag[ch].toStdString().c_str(), (double)avgVal);
    im_411_put_numdata((char *)m_Stat10m_StdTag[ch].toStdString().c_str(), (double)stdVal);

#ifdef KT_DEBUG
    // Debug...
    im_411_print_body();
#endif

    rc = im_411_send();
    im_411_release();

    if (rc < 0)
    {
        printf("fail im_411_send() - Send10minStat\n");
        return -1;
    }

    printf("OK, im_411_send()...Send10minStat - ch:%d, %s\n", ch, dt.toStdString().c_str());
    return 0;
}

int KtIoTMakers::SendMinMax(int ch, float minVal, float maxVal, QString dt)
{
    int rc = 0;

    if (m_nSubDevNum > 1)
        im_411_init_with_devid((char *)m_SubDevID[ch].toStdString().c_str());
    else
        im_411_init();

    // Time
    im_411_append_new_colecRow_with_occDt((char *)dt.toStdString().c_str());

    im_411_put_numdata((char *)m_Stat_MinTag[ch].toStdString().c_str(), (double)minVal);
    im_411_put_numdata((char *)m_Stat_MaxTag[ch].toStdString().c_str(), (double)maxVal);
    im_411_put_numdata((char *)m_Stat_SecTag[ch].toStdString().c_str(), (double)m_Stat_Sec);

#ifdef KT_DEBUG
    // Debug...
    im_411_print_body();
#endif

    rc = im_411_send();
    im_411_release();

    if (rc < 0)
    {
        printf("fail im_411_send() - SendMinMax\n");
        return -1;
    }

    printf("OK, im_411_send()...SendMinMax - ch:%d, %s\n", ch, dt.toStdString().c_str());
    return 0;
}

int KtIoTMakers::SendData(int ch, QVector<RAWDATA> RawVect)
{
    int rc = 0;

    RAWDATA rd = RawVect.at(0);

    if (m_nSubDevNum > 1)
        im_411_init_with_devid((char *)m_SubDevID[ch].toStdString().c_str());
    else
        im_411_init();

    // Time
    im_411_append_new_colecRow_with_occDt((char *)rd.dt.toStdString().c_str());
    //im_411_append_new_colecRow_with_occDt_on_group((char *)as.toStdString().c_str(), NULL);

    for (int i=0; i<RawVect.length(); i++)
    {
        RAWDATA rData = RawVect.at(i);

        im_411_put_numdata((char *)m_SensingDataTag[ch].toStdString().c_str(), (double)rd.data);
        //im_411_put_numdata(slave.SensorValueTag.toStdString().c_str(), value1);

        // Battery Value
        double bat = 50;
        im_411_put_numdata((char *)m_VoltTag.toStdString().c_str(), bat);
    }

#ifdef KT_DEBUG
    // Debug...
    im_411_print_body();
#endif

    rc = im_411_send();
    im_411_release();

    if (rc < 0)
    {
        printf("fail im_411_send()\n");
        return -1;
    }

    printf("OK, im_411_send()...\n");
    return 0;
}

int KtIoTMakers::KtIoTInit()
{
    int result;

    printf("im_version_string = [%s]\n", im_version_string());
    printf("im_init() ... \n");

    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += KTIOTM_CONFIG_FILE;

    result = im_init_with_config_file((char *)confFile.toStdString().c_str());
    if(result < 0)
    {
        printf("Fail. im_init()\n");
        return 201;
    }

    m_DevID = getDevID();
    LoadSubConfig();

#ifdef KT_DEBUG
    im_set_loglevel(LOG_LEVEL_DEBUG);
#else
    im_set_loglevel(LOG_LEVEL_INFO);
#endif

    im_411_set_res_body_handler(__if411_res_body_handler);

#ifdef ARIA_USE
    printf("Setting ARIA key...\n");
    result = im_base_set_aria_key((unsigned char *)KEY);
    if (result < 0)
    {
        printf("fail im_base_set_aes_key()\n");
        //goto _EXTI_;
    }
    //}
#endif

    printf("Connecting to ...\n");
    result = im_connect();
    if (result < 0)
    {
        printf("fail im_connect()\n");
        return 202;
    }

    printf("Authenticating this device ...\n");
    result = im_auth_device();
    if (result < 0)
    {
        printf("fail im_auth_device()\n");
        iotM_Term();
        return 203;
    }

    //Data_Send_Standby |= 0x02;

    return 0;
}

void KtIoTMakers::iotM_Term(void)
{
    //PF_Send_Start = 0;
    printf("Disconnect.\n");
    im_disconnect();

    printf("Release resource.\n");
    im_release();
}

void KtIoTMakers::LoadSubConfig()
{
    QString attrSubDevID[MAX_CH] = {"M_DEV_ID0", "M_DEV_ID1", "M_DEV_ID2"};
    QString attrSubDevPW[MAX_CH] = {"M_DEV_ID0_PW", "M_DEV_ID1_PW", "M_DEV_ID2_PW"};
    QString attrSensingData[MAX_CH] = {"M_SensingDataX", "M_SensingDataY", "M_SensingDataZ"};
    QString attrMinStr[MAX_CH] = {"M_Stat_MIN_X", "M_Stat_MIN_Y", "M_Stat_MIN_Z"};
    QString attrMaxStr[MAX_CH] = {"M_Stat_MAX_X", "M_Stat_MAX_Y", "M_Stat_MAX_Z"};
    QString attrStSStr[MAX_CH] = {"M_Stat_Sec_X", "M_Stat_Sec_Y", "M_Stat_Sec_Z"};
    QString attr10MinStr[MAX_CH] = {"M_Stat10M_MIN_X", "M_Stat10M_MIN_Y", "M_Stat10M_MIN_Z"};
    QString attr10MaxStr[MAX_CH] = {"M_Stat10M_MAX_X", "M_Stat10M_MAX_Y", "M_Stat10M_MAX_Z"};
    QString attr10AvgStr[MAX_CH] = {"M_Stat10M_AVG_X", "M_Stat10M_AVG_Y", "M_Stat10M_AVG_Z"};
    QString attr10StdStr[MAX_CH] = {"M_Stat10M_STD_X", "M_Stat10M_STD_Y", "M_Stat10M_STD_Z"};

    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += KTIOTM_SUBCONFIG_FILE;

    QFile cfgFile(confFile);
    if(!cfgFile.exists())
    {
        qDebug() << confFile + " : cfg file does not exist";
        exit(3);
    }
    QSettings config(confFile, QSettings::IniFormat);
    config.setIniCodec("UTF-8");

    QString attr;
    m_nSensorNum = 0;

    attr = "SERVICE_ID";
    m_ServiceID = config.value(attr, "NONE").toString();
    if (m_ServiceID != "")
    {
        m_bServiceID = true;
    }

    for (int i=0; i<MAX_CH; i++)
    {
        attr = attrSubDevID[i];
        m_SubDevID[i] = config.value(attr, "NONE").toString();
        if (m_SubDevID[i] != "")
        {
            m_nSubDevNum++;
            m_bSubDevID[i] = true;
        }
        attr = attrSubDevPW[i];
        m_SubDevPW[i] = config.value(attr, "NONE").toString();
        if (m_SubDevPW[i] != "")
        {
            m_bSubDevPW[i] = true;
        }
        attr = attrSensingData[i];
        m_SensingDataTag[i] = config.value(attr, "NONE").toString();
        if (m_SensingDataTag[i] != "")
        {
            m_nSensorNum++;
            m_bSensingDataTag[i] = true;
        }
        attr = attrMinStr[i];
        m_Stat_MinTag[i] = config.value(attr, "NONE").toString();
        if (m_Stat_MinTag[i] != "")
        {
            m_bStat_MinTag[i] = true;
        }
        attr = attrMaxStr[i];
        m_Stat_MaxTag[i] = config.value(attr, "NONE").toString();
        if (m_Stat_MaxTag[i] != "")
        {
            m_bStat_MaxTag[i] = true;
        }
        attr = attrStSStr[i];
        m_Stat_SecTag[i] = config.value(attr, "NONE").toString();
        if (m_Stat_SecTag[i] != "")
        {
            m_bStat_SecTag[i] = true;
        }
        attr = attr10MinStr[i];
        m_Stat10m_MinTag[i] = config.value(attr, "NONE").toString();
        if (m_Stat10m_MinTag[i] != "")
        {
            m_bStat10m_MinTag[i] = true;
        }
        attr = attr10MaxStr[i];
        m_Stat10m_MaxTag[i] = config.value(attr, "NONE").toString();
        if (m_Stat10m_MaxTag[i] != "")
        {
            m_bStat10m_MaxTag[i] = true;
        }
        attr = attr10AvgStr[i];
        m_Stat10m_AvgTag[i] = config.value(attr, "NONE").toString();
        if (m_Stat10m_AvgTag[i] != "")
        {
            m_bStat10m_AvgTag[i] = true;
        }
        attr = attr10StdStr[i];
        m_Stat10m_StdTag[i] = config.value(attr, "NONE").toString();
        if (m_Stat10m_StdTag[i] != "")
        {
            m_bStat10m_StdTag[i] = true;
        }
    }

    attr = "M_Stat_SecN";
    m_Stat_Sec = config.value(attr, 0).toInt();

    attr = "ST_VOLT";
    m_VoltTag = config.value(attr, "NONE").toString();
    if (m_VoltTag != "")
    {
        m_bVoltTag = true;
    }
    attr = "ST_BATT";
    m_BattTag = config.value(attr, "NONE").toString();
    if (m_BattTag != "")
    {
        m_bBattTag = true;
    }
    attr = "ST_TEMP";
    m_TempTag = config.value(attr, "NONE").toString();
    if (m_TempTag != "")
    {
        m_bTempTag = true;
    }

    attr = "GatherDataN";
    m_GatherDataN = config.value(attr, 30).toInt();

    qDebug() << "==========================";
    qDebug() << "Dev Count" << m_nSubDevNum;
    qDebug() << "m_DevID0" << m_SubDevID[0] << "-->" << m_bSubDevID[0];
    qDebug() << "m_DevID1" << m_SubDevID[1] << "-->" << m_bSubDevID[1];
    qDebug() << "m_DevID2" << m_SubDevID[2] << "-->" << m_bSubDevID[2];
    qDebug() << "SensorCount:" << m_nSensorNum;
    qDebug() << "m_SensingDataTagX:" << m_SensingDataTag[0] << "-->" << m_bSensingDataTag[0];
    qDebug() << "m_SensingDataTagY:" << m_SensingDataTag[1] << "-->" << m_bSensingDataTag[1];
    qDebug() << "m_SensingDataTagZ:" << m_SensingDataTag[2] << "-->" << m_bSensingDataTag[2];
    qDebug() << "m_Stat_MinTagX:" << m_Stat_MinTag[0] << "-->" << m_bStat_MinTag[0];
    qDebug() << "m_Stat_MaxTagX:" << m_Stat_MaxTag[0] << "-->" << m_bStat_MaxTag[0];
    qDebug() << "m_Stat_SecTagX:" << m_Stat_SecTag[0] << "-->" << m_bStat_SecTag[0];
    qDebug() << "m_Stat_MinTagY:" << m_Stat_MinTag[1] << "-->" << m_bStat_MinTag[1];
    qDebug() << "m_Stat_MaxTagY:" << m_Stat_MaxTag[1] << "-->" << m_bStat_MaxTag[1];
    qDebug() << "m_Stat_SecTagY:" << m_Stat_SecTag[1] << "-->" << m_bStat_SecTag[1];
    qDebug() << "m_Stat_MinTagZ:" << m_Stat_MinTag[2] << "-->" << m_bStat_MinTag[2];
    qDebug() << "m_Stat_MaxTagZ:" << m_Stat_MaxTag[2] << "-->" << m_bStat_MaxTag[2];
    qDebug() << "m_Stat_SecTagZ:" << m_Stat_SecTag[2] << "-->" << m_bStat_SecTag[2];
    qDebug() << "m_Stat_Sec:" << m_Stat_Sec;
    qDebug() << "m_Stat10m_MinTagX:" << m_Stat10m_MinTag[0] << "-->" << m_bStat10m_MinTag[0];
    qDebug() << "m_Stat10m_MaxTagX:" << m_Stat10m_MaxTag[0] << "-->" << m_bStat10m_MaxTag[0];
    qDebug() << "m_Stat10m_AvgTagX:" << m_Stat10m_AvgTag[0] << "-->" << m_bStat10m_AvgTag[0];
    qDebug() << "m_Stat10m_StdTagX:" << m_Stat10m_StdTag[0] << "-->" << m_bStat10m_StdTag[0];
    qDebug() << "m_Stat10m_MinTagY:" << m_Stat10m_MinTag[1] << "-->" << m_bStat10m_MinTag[1];
    qDebug() << "m_Stat10m_MaxTagY:" << m_Stat10m_MaxTag[1] << "-->" << m_bStat10m_MaxTag[1];
    qDebug() << "m_Stat10m_AvgTagY:" << m_Stat10m_AvgTag[1] << "-->" << m_bStat10m_AvgTag[1];
    qDebug() << "m_Stat10m_StdTagY:" << m_Stat10m_StdTag[1] << "-->" << m_bStat10m_StdTag[1];
    qDebug() << "m_Stat10m_MinTagZ:" << m_Stat10m_MinTag[2] << "-->" << m_bStat10m_MinTag[2];
    qDebug() << "m_Stat10m_MaxTagZ:" << m_Stat10m_MaxTag[2] << "-->" << m_bStat10m_MaxTag[2];
    qDebug() << "m_Stat10m_AvgTagZ:" << m_Stat10m_AvgTag[2] << "-->" << m_bStat10m_AvgTag[2];
    qDebug() << "m_Stat10m_StdTagZ:" << m_Stat10m_StdTag[2] << "-->" << m_bStat10m_StdTag[2];
    qDebug() << "m_VoltTag:" << m_VoltTag << "-->" << m_bVoltTag;
    qDebug() << "m_BattTag:" << m_BattTag << "-->" << m_bBattTag;
    qDebug() << "m_TempTag:" << m_TempTag << "-->" << m_bTempTag;
    qDebug() << "GatherDataN:"<< m_GatherDataN;
    qDebug() << "==========================";
    config.deleteLater();

    qDebug() << "Config Loading is done...";
}

QString KtIoTMakers::getDevID()
{
    char *devID = im_base_get_deviceId();
    printf("DevID = %s\n", devID);

    QString sDevID;

    if (devID == NULL)
        sDevID = getDevIDfromConfig();
    else
        sDevID = QString::fromUtf8(devID);

    return sDevID;
}

QString KtIoTMakers::getDevIDfromConfig()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += KTIOTM_CONFIG_FILE;

    QFile cfgFile(confFile);
    if(!cfgFile.exists())
    {
        qDebug() << confFile + " : cfg file does not exist";
        exit(3);
    }
    QSettings config(confFile, QSettings::IniFormat);
    config.setIniCodec("UTF-8");

    QString attr;
    QString sDevID;

    attr = "DEV_ID";
    sDevID = config.value(attr, "NONE").toString();

    qDebug() << "==========================";
    qDebug() << "DevID :" << sDevID;
    config.deleteLater();

    return sDevID;
}

#endif //KT_IOTMAKERS
