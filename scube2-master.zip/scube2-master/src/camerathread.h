﻿#ifndef CCAMERATHREAD_H
#define CCAMERATHREAD_H

#include <QThread>
#include <QString>

class CMainTask;

class CCameraThread : public QObject
{
    Q_OBJECT
public:
    explicit CCameraThread(QObject *parent = 0);

signals:

public slots:
    void done();

protected:
    void run();

public:
    CMainTask *m_pMainTask;
    bool m_bThreadRun;

    QString m_FileDT;
};

#endif // CCAMERATHREAD_H
