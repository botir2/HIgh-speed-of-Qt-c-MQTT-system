﻿#ifndef CMINISEEDDATA_H
#define CMINISEEDDATA_H

#include <stdio.h>
#include <stdlib.h>

#include <QString>
#include <QVector>

#include <libmseed.h>

class CMiniSeedData
{
public:
    CMiniSeedData();

    //int m_nCh;
    static int  m_ntest;
    QVector<int> m_vRawData;
    int m_nSequenceNumber;

    void * m_pPara;

    unsigned short m_year;
    unsigned char m_mon;
    unsigned char m_mday;
    unsigned char m_hour;
    unsigned char m_min;
    unsigned char m_sec;
    unsigned short m_mSec;

    QString GetPositionCode();
    void clearData();
};

#endif // CMINISEEDDATA_H
