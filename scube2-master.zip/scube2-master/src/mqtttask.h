#ifndef MQTTTASK_H
#define MQTTTASK_H

#include <QObject>
#include <QThread>
#include <QDebug>

#include "qmqtt.h"

#include "IoTSensor.h"
#include "maintask.h"

class MQTTTask : public QObject
{
    Q_OBJECT
public:
    explicit MQTTTask(QObject *parent = 0);

signals:
    void publishMsg(QString msg);

public slots:
    void runProc(void);

    ////void ConnectedMqtt();
    ////void DisconnectedMqtt();

public:
    CMainTask *m_pMain;

    ////QMQTT::Client *m_mqttClient;    // Realtime data

    ////void InitMqtt();
    void Publish(DAQDATA qData);
};

#endif // MQTTTASK_H
