#ifndef FILESAVETASK_H
#define FILESAVETASK_H

#include <QObject>
#include <QThread>
#include <QDebug>

#include "IoTSensor.h"
#include "maintask.h"

class FileSaveTask : public QObject
{
    Q_OBJECT
public:
    explicit FileSaveTask(QObject *parent = 0);

signals:

public slots:
    void runProc(void);

public:
    CMainTask *m_pMain;

    void Write_BinData(FILESAVEDATA fileData);
    void Write_MqttData(FILESAVEDATA fileData);
    void Write_SendData(FILESAVEDATA fileData);
    void CheckDirectory(void);
    void CheckDirectory(QString dirPath);
    QString GetDataFileName(int ch, QDateTime curDT);
#ifdef KT_IOTMAKERS
    QString GetDataFileName5Min(int ch, QDateTime curDT);
    void Write_KtIoTData(FILESAVEDATA fileData);
#endif
};

#endif // FILESAVETASK_H
