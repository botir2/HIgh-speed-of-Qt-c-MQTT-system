#ifndef NCUBETASK_H
#define NCUBETASK_H

#include <QObject>
#include <QThread>
#include <QDebug>

#include <QTcpSocket>
#include <QAbstractSocket>

#include "IoTSensor.h"
#include "maintask.h"

class QTcpSocket;
class QAbstractSocket;

class NCubeTask : public QObject
{
    Q_OBJECT
public:
    explicit NCubeTask(QObject *parent = 0);

signals:
    void send2nCube(QString Msg);

public slots:
    void Init();
    void runProc(void);

    void OnSendTimer();
    void stopTimer(void);
    void beginTimer(void);

public:
    CMainTask *m_pMain;

    QTcpSocket *m_socket;           // connect to nCube
    unsigned int m_sendTimeCount;   // control for period of TCP transfer

    QTimer m_sendTimer;

    void startTimer();

    void Publish();
    void Publish(nCUBEDATA qData);
    void PublishEvent(nCUBEDATA qData);
};

#endif // NCUBETASK_H
