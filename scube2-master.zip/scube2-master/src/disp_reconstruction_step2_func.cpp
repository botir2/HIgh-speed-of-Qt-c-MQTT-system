/*
 * File: disp_reconstruction_step2_func.c
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 22-Feb-2018 15:59:29
 */

/* Include files */
#include "rt_nonfinite.h"
#include "disp_reconstruction_step2_func.h"
#include "filter.h"

/* Function Definitions */

/*
 * acceleration_data : 1000���̳�, 1���� �迭
 * filters_data : 1000���̳�, 2���� �迭
 * Arguments    : const double acceleration_temp[32000]
 *                const double FIR_filter_dis[169]
 *                const double FIR_filter_vel[169]
 *                double displacement[32000]
 *                double velocity[32000]
 * Return Type  : void
 */
void disp_reconstruction_step2_func(const double acceleration_temp[32000], const
  double FIR_filter_dis[169], const double FIR_filter_vel[169], double
  displacement[32000], double velocity[32000])
{
  static double output_temp[32000];
  filter(FIR_filter_dis, acceleration_temp, output_temp);
  memset(&displacement[0], 0, 32000U * sizeof(double));
  memcpy(&displacement[84], &output_temp[168], 31832U * sizeof(double));
  filter(FIR_filter_vel, acceleration_temp, output_temp);
  memset(&velocity[0], 0, 32000U * sizeof(double));
  memcpy(&velocity[84], &output_temp[168], 31832U * sizeof(double));
}

/*
 * File trailer for disp_reconstruction_step2_func.c
 *
 * [EOF]
 */
