﻿#ifndef CCALCDIS_H
#define CCALCDIS_H

#include <QThread>
#include <QString>
#include <QVector>

class CMainTask;

class CCalcDis : public QThread
{
    Q_OBJECT
public:
    explicit CCalcDis(QObject *parent = 0);

signals:

public slots:

protected:
    QVector<double> m_vFir;
    QVector<double> m_vFFir;

    void run();

    void fliplr(QVector<double> &fflip, QVector<double> &fir);
    void fliplr();

    ////void filter(QVector<double> &b, QVector<double> &x, QVector<double> &y);
    QVector<double> filter(QVector<double> &b, QVector<double> &x);

public:
    CMainTask *m_pMainTask;
    bool m_bThreadRun;

    QString m_FileDT;

    ////QVector<double> ReadFIRData();
    void ReadFIRData();
};

#endif // CCALCDIS_H
