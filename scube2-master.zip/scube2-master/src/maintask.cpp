﻿#include <math.h>

#include <QTcpSocket>
#include <unistd.h>  // sleep 함수
#include <QTime>
#include <algorithm>
#include <QFile>
#include <QDateTime>
#include <QDir>
#include <QProcess>

#include "json.h"
#include "IoTSensor.h"

#include "maintask.h"

#include "CalcDis.h"

CMainTask::CMainTask(QObject *parent) : QObject(parent)
{
    ClearSensorData();

    m_sendTimeCount = 0;
    m_samplingRate = 150;

    m_DAQYear = 2017;
    m_DAQMonth = 12;
    m_DAQDay = 21;
    m_DAQHour = 12;
    m_DAQMinute = 0;
    m_DAQSec = 0;
    m_DAQMilSec = 0;

    m_Lat1 = 38;
    m_Lat2 = 0;
    m_Lon1 = 125;
    m_Lon2 = 0;
    m_isNorth = true;
    m_isEest = true;

    m_Temp = 0;
    m_Humi = 0;

    m_daqGPS.iLat1 = 38;
    m_daqGPS.iLat2 = 0;
    m_daqGPS.iLon1 = 125;
    m_daqGPS.iLon2 = 0;
    m_daqGPS.bisNorth = true;
    m_daqGPS.bisEest = true;

    m_isFirstStart = true;
    m_isTimeSet = false;

    for (int i=0; i<3; i++)
    {
        m_isEvent[i] = false;
        m_isMadeData[i] = false;
        m_eventDataCount[i] = 0;
    }
#ifdef KT_IOTMAKERS
    m_isConnectedKTIoTM = false;
    m_KtSendCount = 0;
    m_10minCount = 0;
    m_statSecs = 0;
    m_stat10m = 0;
    m_statIdx = 0;
#endif

    // 먼저 설정파일들을 읽기
    m_MainConfig.ReadFile();
    m_CubeConfig.ReadFile();
    m_SensorConfig.ReadFile();
    m_ProtocolConfig.ReadFile();
    m_AnalysisConfig.ReadFile();

    AttachCmdFuncPtr();
    ////AttachAnalysisFuncPtr();

    calcTriggerValue();
    setConverter();
    ////setSensorSampling();

    // Set Channel Number
    if (m_SensorConfig.m_setType == 3)
        m_CHnum = 3;
    else if (m_SensorConfig.m_setType == 10)
        m_CHnum = 2;
    else
        m_CHnum = 1;

    m_bnCubeConn = false;
    Init2nCube();

    m_bMQTTConnected = false;
    InitMqtt();

#ifdef KT_IOTMAKERS
    //if (m_ProtocolConfig.m_dam == 4 || m_ProtocolConfig.m_dam == 5 ||
    //        m_ProtocolConfig.m_dam == 6 || m_ProtocolConfig.m_dam == 8)
        InitKTIoT();
#endif

    ////m_pCameraTh = new CCameraThread(this);
    ////m_pCameraTh->m_pMainTask = this;
    if (m_AnalysisConfig.m_UseDis)
    {
        printf("Analysis Displacement !!\n");
        m_pCalcDisTh = new CCalcDis(this);
        m_pCalcDisTh->m_pMainTask = this;
        m_pCalcDisTh->ReadFIRData();
    }

    //connect(&m_sendTimer, SIGNAL(timeout()), this, SLOT(OnSendTimer()));
    connect(&m_10MinsTimer, SIGNAL(timeout()), this, SLOT(On10MinsTimer()));
#ifdef KT_IOTMAKERS
    ////connect(&m_OneSecTimer, SIGNAL(timeout()), this, SLOT(OnOneSecTimer()));
#endif

    m_Packets.clear();
    m_FileDatas.clear();
    m_MQTTDatas.clear();
    m_SensorDatas.clear();
    m_CalcDatas.clear();
    m_nCubeDatas.clear();
#ifdef KT_IOTMAKERS
    m_KtCalcDatas.clear();
#endif
    //startTimer();
    //m_CameraTh.start();
}

CMainTask::~CMainTask()
{
    ////m_pCameraTh->m_bThreadRun = false;
}

#ifdef KT_IOTMAKERS
void CMainTask::InitKTIoT()
{
    int nTry = 0;
    int err = 1;

    while (err)
    {
        nTry++;
        err = m_IoTM.KtIoTInit();
        sleep(2);

        if (err > 200)
        {
            m_IoTM.iotM_Term();
            //Data_Send_Standby &= 0xfd;
            //memset(ERR_Str,0,sizeof(ERR_Str));
            //Read_System_time();
            //sprintf(ERR_Str,"%04d%02d%02d%02d%02d%02d : Connect error %d\n",ST1.YY,ST1.MM,ST1.DD,ST1.hh,ST1.mm,ST1.ss,err);
            //Write_log(ERR_Str);
            //IoTM_err_Check = 5;

            if (nTry > 3)
                break;
        }
        else if (err == 0)
        {
            m_isConnectedKTIoTM = true;
            m_KtSendCount = m_IoTM.m_GatherDataN;
        }
    }
}
#endif

void CMainTask::calcTriggerValue()
{
    m_triggerValue[0] = m_SensorConfig.m_range[0] * m_AnalysisConfig.m_tv / 100;
    printf("TriggerValue0 = %.2f\r\n", m_triggerValue[0]);
    m_triggerValue[1] = m_SensorConfig.m_range[1] * m_AnalysisConfig.m_tv / 100;
    printf("TriggerValue1 = %.2f\r\n", m_triggerValue[1]);
    m_triggerValue[2] = m_SensorConfig.m_range[2] * m_AnalysisConfig.m_tv / 100;
    printf("TriggerValue2 = %.2f\r\n", m_triggerValue[2]);

    QMap<QString, pfn_analysis>::iterator iter = m_AnalMap.find(m_AnalysisConfig.m_AnalFn0);
    if (iter != m_AnalMap.end())
    {
        m_AnalFn0 = iter.value();    // iter->second
        printf("AnalFn0 : %x, ", m_AnalFn0);
    }

    iter = m_AnalMap.find(m_AnalysisConfig.m_AnalFn1);
    if (iter != m_AnalMap.end())
    {
        m_AnalFn1 = iter.value();    // iter->second
        printf("AnalFn1 : %x\n", m_AnalFn1);
    }

    iter = m_AnalMap.find(m_AnalysisConfig.m_AnalFn2);
    if (iter != m_AnalMap.end())
    {
        m_AnalFn2 = iter.value();    // iter->second
        printf("AnalFn2 : %x\n", m_AnalFn2);
    }

    iter = m_AnalMap.find(m_AnalysisConfig.m_AnalFn3);
    if (iter != m_AnalMap.end())
    {
        m_AnalFn3 = iter.value();    // iter->second
        printf("AnalFn3 : %x\n", m_AnalFn3);
    }
}

void CMainTask::setDAQFilter()
{
    // 센서설정 메시지에 CR,LF 붙이기
    memset(m_commandBuff, 0, 50);
    sprintf(m_commandBuff, "SETFILTER+%1d\r\n", m_SensorConfig.m_filteron);

    SendCommand(false);
}

void CMainTask::setDAQTime()
{
    if (m_setTimefromDAQ)   // DAQ time to SYS time
        return;

    QString time_format = "yyyyMMddHHmmsszzz";
//#ifdef XX
    QTime tick;
    tick.start();
//#endif //XX
    QDateTime a = QDateTime::currentDateTime();
    QString as = a.toString(time_format);

    // 센서설정 메시지에 CR,LF 붙이기
    memset(m_commandBuff, 0, 50);
    sprintf(m_commandBuff, "SETTIME+%s\r\n", as.toStdString().c_str());

    SendCommand(false);
    m_isTimeSet = true;
//#ifdef XX
    int nElapsed = tick.elapsed();
    printf(">>>SetTime : %s (%d) msecs\n", as.toStdString().c_str(), nElapsed);
//#endif //XX
}

void CMainTask::setDAQVoltage()
{
    // 센서설정 메시지에 CR,LF 붙이기
    memset(m_commandBuff, 0, 50);
    sprintf(m_commandBuff, "SETVOLTAGE+%.1f\r\n", m_SensorConfig.m_voltage);

    SendCommand(false);
#ifdef XX
    printf(">>>SetVoltage : %.1f\n", m_SensorConfig.m_voltage);
#endif //XX
}

void CMainTask::setSensorSampling()
{
    // 센서설정 메시지에 CR,LF 붙이기
    memset(m_commandBuff, 0, 50);
    sprintf(m_commandBuff, "SETSAMPLE+%d\r\nSETTYPE+%d\r\n", m_SensorConfig.m_setSample, m_SensorConfig.m_setType);

    m_samplingRate = m_SensorConfig.m_setSample * m_ProtocolConfig.m_ft;
    printf("sampling count / f-t = %d\r\n", m_samplingRate);

    //m_sendTimeValue = GetSendTimeValue();
    //m_SensorCmd = m_SensorConfig.m_setType;

    m_eventQueue[0].setSize(m_samplingRate*0.3);   // 1/3 of Sampling
    m_eventQueue[1].setSize(m_samplingRate*0.3);   // 1/3 of Sampling
    m_eventQueue[2].setSize(m_samplingRate*0.3);   // 1/3 of Sampling
    printf("event Queue size = %d\r\n", m_samplingRate*0.3);
}

void CMainTask::startTimer()
{
#ifdef XX
    if (m_ProtocolConfig.m_dam == 2 || m_ProtocolConfig.m_dam == 3 || m_ProtocolConfig.m_dam == 5 || m_ProtocolConfig.m_dam == 6)
    {
        m_sendTimer.start(m_ProtocolConfig.m_ft*1000);
        printf("Tcp-Send enable : %d secs\r\n", m_ProtocolConfig.m_ft);
    }
#endif
    m_10MinsTimer.start(1000*60*10);
#ifdef KT_IOTMAKERS
    ////m_OneSecTimer.start(1000);
#endif

    /**
    if (m_ProtocolConfig.m_dam == 2)
    {
        m_sendTimer.start(m_ProtocolConfig.m_ft*1000);
        printf("Tcp-Send enable : %d secs\r\n", m_ProtocolConfig.m_ft);
    }
    else if (m_ProtocolConfig.m_dam == 1)
    {
        printf("Mqtt-Publish enable\n");
    }
    else if (m_ProtocolConfig.m_dam == 3)
    {
        m_sendTimer.start(m_ProtocolConfig.m_ft*1000);
        printf("Tcp-Send & Mqtt-Publish enable : %d secs\r\n", m_ProtocolConfig.m_ft);
    }
    **/
}

void CMainTask::setConverter()
{
    m_converter.m_funcIdx = m_SensorConfig.m_setType;

    m_converter.m_sensitivity[0] = m_SensorConfig.m_sensitivity[0];
    m_converter.m_capacity[0] = m_SensorConfig.m_capacity[0];
    m_converter.m_extFactor[0] = m_SensorConfig.m_extfactor[0];
    m_converter.m_offset[0] = m_SensorConfig.m_offset[0];
    m_converter.m_range[0] = m_SensorConfig.m_range[0];

    m_converter.m_sensitivity[1] = m_SensorConfig.m_sensitivity[1];
    m_converter.m_capacity[1] = m_SensorConfig.m_capacity[1];
    m_converter.m_extFactor[1] = m_SensorConfig.m_extfactor[1];
    m_converter.m_offset[1] = m_SensorConfig.m_offset[1];
    m_converter.m_range[1] = m_SensorConfig.m_range[1];

    m_converter.m_sensitivity[2] = m_SensorConfig.m_sensitivity[2];
    m_converter.m_capacity[2] = m_SensorConfig.m_capacity[2];
    m_converter.m_extFactor[2] = m_SensorConfig.m_extfactor[2];
    m_converter.m_offset[2] = m_SensorConfig.m_offset[2];
    m_converter.m_range[2] = m_SensorConfig.m_range[2];

    m_converter.m_exVolt = m_SensorConfig.m_exVolt;
    m_converter.m_gFactor = m_SensorConfig.m_gFactor;
    m_converter.m_voltage = m_SensorConfig.m_voltage;
}

// Create socket and connect for comm. to nCube
void CMainTask::Init2nCube()
{
    m_socket = new QTcpSocket();
    connect(m_socket, SIGNAL(connected()), this, SLOT(nCubeConnected()));
    connect(m_socket, SIGNAL(disconnected()), this, SLOT(nCubeDisConnected()));
    connect(m_socket, SIGNAL(readyRead()), this, SLOT(OnReadSocket()));

    printf("Connect nCube-Thyme: %s\r\n", m_CubeConfig.m_tasIP.toStdString().c_str());

    if (m_CubeConfig.m_tasIP == "localhost")
    {
        m_socket->connectToHost(QHostAddress(QHostAddress::LocalHost), 3105);
    }
    else
    {
        m_socket->connectToHost(m_CubeConfig.m_tasIP, 3105);
    }

    if (m_socket->waitForConnected(5000))
    {
        m_bnCubeConn = true;

        // 제어명령을 받기 위해 json 형식으로 엔큐브에 전달
        QString text;
#ifdef NCUBE_172
        text.sprintf("{\"ctname\":\"%s\", \"con\":\"hello\"}<EOF>",
#else
        text.sprintf("{\"ctname\":\"%s\", \"con\":\"hello\"}",
#endif
                     m_CubeConfig.m_tcpCtnCtrl.toStdString().c_str());
        m_socket->write(text.toStdString().c_str());
    }
    else
    {
        m_bnCubeConn = false;
        printf("# Failed connect nCube-Thyme: %s\r\n", m_CubeConfig.m_tasIP.toStdString().c_str());
    }
}

void CMainTask::nCubeConnected()
{
    m_bnCubeConn = true;
    printf(">>>Connected nCube-Thyme: %s\r\n", m_CubeConfig.m_tasIP.toStdString().c_str());
}

void CMainTask::nCubeDisConnected()
{
    m_socket->close();
    delete m_socket; m_socket = NULL;
    m_bnCubeConn = false;
    printf(">>>Disconnected nCube-Thyme: %s\r\n", m_CubeConfig.m_tasIP.toStdString().c_str());

    sleep(20);
    Init2nCube();
}

// Control message from nCube
void CMainTask::OnReadSocket()
{
    if (m_socket->bytesAvailable() > 0)
    {
        bool ok = true;
        QString jsonData = (QString)m_socket->readAll();

        printf(">>>Read from nCube : %s\r\n", jsonData.toStdString().c_str()); //  jsonData.toLatin1().toStdString().c_str()

        // {"ctname":"control_sensor", "con":"1"} 형식으로 들어옴
        QtJson::JsonObject jsonObj = QtJson::parse(jsonData, ok).toMap();
        if (ok)
        {
            //QString strName = jsonObj["ctname"].toString();
            QString strCon = jsonObj["con"].toString();

            if (strCon == "hello")
            {
                printf("command:%s\r\n", strCon.toStdString().c_str());
                return;
            }
            else if (strCon == "2001")
            {
                return;
            }

            QString strCommand = strCon.left(4);
            QString strVal = strCon.mid(4);

            QMap<QString, pfn_setting>::iterator iter = m_funcMap.find(strCommand);
            if (iter != m_funcMap.end())
            {
                pfn_setting func = iter.value();    // iter->second
                (this->*func)(strVal);              // Function call
            }
            else
            {
                printf(">>> Unknown command !!!\r\n");
            }
        }
        else
        {
            printf("# Error: Json parsing\r\n");
        }
    }
}

void CMainTask::Stop2nCube()
{
    m_socket->close();
    delete m_socket;

    m_bnCubeConn = false;

    printf("Disconnect nCube-Thyme: %s\r\n", m_CubeConfig.m_tasIP.toStdString().c_str());
}

void CMainTask::send2nCube(QString msg)
{
    if (m_bnCubeConn)
        m_socket->write(msg.toStdString().c_str());
}

void CMainTask::send2nCubeEvent(QString msg)
{
    if (m_bnCubeConn)
        m_socket->write(msg.toStdString().c_str());
}

// mqtt 생성, 연결(퍼블리셔)
void CMainTask::InitMqtt()
{
    // mqtt - 퍼블리셔
    m_mqttClient = new QMQTT::Client();

    connect(m_mqttClient, SIGNAL(connected()), this, SLOT(ConnectedMqtt()));
    connect(m_mqttClient, SIGNAL(disconnected()), this, SLOT(DisconnectedMqtt()));

    // mqtt 서버와 연결
    m_mqttClient->setHost(QHostAddress(m_CubeConfig.m_mqttServer));
    m_mqttClient->setPort(1883);
    m_mqttClient->setClientId(m_CubeConfig.m_mqttId); // 장비마다 다르게 설정해 줘야 함.
    m_mqttClient->connectToHost();

    m_mqttClient->setAutoReconnect(true);
    m_mqttClient->setKeepAlive(30);
}

void CMainTask::publishMsg(QString msg)
{
    //mqttBMutex.lock();
    if (m_bMQTTConnected)
    {
        QMQTT::Message mqttMsg(0 /*or 1*/, m_CubeConfig.m_mqttTopic, msg.toUtf8());
        m_mqttClient->publish(mqttMsg);
    }
    else
        printf("Publish failed: %s, %s\n", m_CubeConfig.m_mqttTopic.toStdString().data(), msg.toStdString().data());
    //mqttBMutex.unlock();

#ifdef DBGPRINT
    printf("Publish: %s, %s\n", m_CubeConfig.m_mqttTopic.toStdString().data(), msg.toStdString().data());
#endif
}

void CMainTask::ClearSensorData()
{
    for (int ch=0; ch<MAX_CH; ch++)
    {
        m_rawString[ch].clear();
        m_rawVect[ch].clear();
        m_rawData[ch].clear();

        m_isEvent[ch] = false;
        m_isMadeData[ch] = false;
        m_eventDataCount[ch] = 0;

        m_rawavg[ch] = 0.0f;
        m_p2p[ch] = 0.0f;
        m_rms[ch] = 0.0f;
    }
}

// 함수포인터 연결
void CMainTask::AttachCmdFuncPtr()
{
    m_funcMap.insert("CMD0", &CMainTask::SetSensorConfig);
    m_funcMap.insert("CMD1", &CMainTask::SetCommunicationConfig);
    m_funcMap.insert("CMD2", &CMainTask::SetAnalysisConfig);
    m_funcMap.insert("CMD3", &CMainTask::SetMainConfig);
    m_funcMap.insert("RST0", &CMainTask::SetReboot);
    m_funcMap.insert("REQ0", &CMainTask::ReqSensorState);
}

#ifdef XX
void CMainTask::AttachAnalysisFuncPtr()
{
    m_AnalMap.insert("P2P", &CMainTask::Analysis_P2P);
    m_AnalMap.insert("RMS", &CMainTask::Analysis_Rms);
    m_AnalMap.insert("MIN", &CMainTask::Analysis_Min);
    m_AnalMap.insert("MAX", &CMainTask::Analysis_Max);
    m_AnalMap.insert("AVG", &CMainTask::Analysis_Avg);
    m_AnalMap.insert("STD", &CMainTask::Analysis_Std);
    printf("AnalFn - P2P : %x\n", &CMainTask::Analysis_P2P);
    printf("AnalFn - RMS : %x\n", &CMainTask::Analysis_Rms);
    printf("AnalFn - MIN : %x\n", &CMainTask::Analysis_Min);
    printf("AnalFn - MAX : %x\n", &CMainTask::Analysis_Max);
    printf("AnalFn - AVG : %x\n", &CMainTask::Analysis_Avg);
    printf("AnalFn - STD : %x\n", &CMainTask::Analysis_Std);
}


bool CMainTask::CheckSum(QByteArray data)
{
    char checkSum = 0x00;
    char *d = data.data();
    int dSize = data.size() - 1;

    for (int i=0; i<dSize; i++)
    {
        ////printf("{%x}", *d);
        checkSum = checkSum ^ *d;
        ++d;
    }

    ////printf("\n----CheckSum : %x\n", checkSum);
    if (checkSum == data.at(dSize))
        return true;
    else
        return false;
}

void CMainTask::CompletePacket(QByteArray data)
{
    QByteArray qData = data;

////#ifdef DBGPRINT
    char *d = qData.data();
    for (int i=0; i<qData.size(); i++)
    {
        printf("{%x}", *d);
        ++d;
    }
    printf("\r\n");
////#endif

    if (!CheckSum(data))
    {
        printf("\n----------------CheckSum Error\n");
        char *d = qData.data();
        for (int i=0; i<qData.size(); i++)
        {
            printf("{%x}", *d);
            ++d;
        }
        printf("\r\n");
        return;
    }

    m_PMutex.lock();    /////

    m_Packets.append(qData);
    printf("Pakcets -> %d\n", m_Packets.size());
    ////QByteArray pData;
    ////pData = m_Packets.first();

    ////emit ProcessPacket(pData);
    ////m_Packets.removeFirst();

    m_PMutex.unlock();  /////
}

void CMainTask::ProcPacket(QByteArray data)
{
    float sensorData[3];
    QByteArray qData = data;

    char cmd = qData.at(0);
    int nCmd = (int)cmd;
    //printf("Cmd = %d\r\n", nCmd);

    if (nCmd == m_SensorConfig.m_setType)    // for Sensor Data
    {
        //m_rawData.append(rawData);
        int dCnt = (int)qData.at(1);
#ifdef DBGPRINT
        printf("Sensor Data - %d\r\n", dCnt);
#endif

        int cnt = qData.size();
        if (cnt < 14)
        {
            printf("Packet_Error-S:%d ", cnt);
//#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("{%x}", *d);
                ++d;
            }
            printf("\r\n");
//#endif
        }
        else
        {
            char adcData = qData.at(1);
            int dataLen = (int)adcData;
            int val, sVal[3];

            adcData = qData.at(2);
            val = (int)adcData;
            adcData = qData.at(3);
            val <<= 8;
            m_DAQYear = val | adcData;

            adcData = qData.at(4);
            m_DAQMonth = (int)adcData;
            adcData = qData.at(5);
            m_DAQDay = (int)adcData;
            adcData = qData.at(6);
            m_DAQHour = (int)adcData;
            adcData = qData.at(7);
            m_DAQMinute = (int)adcData;
            adcData = qData.at(8);
            m_DAQSec = (int)adcData;

            adcData = qData.at(9);
            val = (int)adcData;
            adcData = qData.at(10);
            val <<= 8;
            m_DAQMilSec = val | adcData;

            for (int ch=0; ch<dCnt; ch++)
            {
                adcData = qData.at(11+ch);
                sVal[ch] = (int)adcData;
                adcData = qData.at(12+ch);
                sVal[ch] <<= 8;
                sVal[ch] = sVal[ch] | adcData;
            }

            if (m_isTimeSet)
            {
                if (m_isFirstStart)     // just once...at first data received
                {
#ifdef DBGFILESAVE

#endif
                    ////Take_aPicture(2);
                    startTimer();
                    m_isFirstStart = false;
                }

                for (int ch=0; ch<dCnt; ch++)
                {
                    sensorData[ch] = m_converter.SensorData(ch, sVal[ch]);

//#ifdef DBGPRINT
                    printf("%04d-%02d-%02d %02d:%02d:%02d.%03d,%d,%.5f\n",
                           m_DAQYear, m_DAQMonth, m_DAQDay, m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec, sVal[ch], sensorData[ch]);
//#endif

                    if (m_isEvent[ch] && !m_isMadeData[ch])
                    {
                        m_eventVect[ch].append(sensorData[ch]);

                        if (m_eventDataCount[ch] >= m_samplingRate)
                        {
                            // 전송용 으로 샘플링레이트 만큼 문자열로 저장
                            QString text = QString::number(sensorData[ch], 'f', 5);
                            m_rawString[ch] += text;

                            m_eventDataCount[ch] = 0;
                            m_isMadeData[ch] = true;
                        }
                        else
                        {
                            // 전송용 으로 샘플링레이트 만큼 문자열로 저장
                            QString text = QString::number(sensorData[ch], 'f', 5) + ",";
                            m_rawString[ch] += text;

                            m_eventDataCount[ch]++;
                        }
                    }

                    m_eventQueue[ch].enQueue(sensorData[ch]);

                    // 분석 변환 데이터용 으로 저장
                    m_rawVect[ch].append(sensorData[ch]);

                    // 시리얼 통신속도와 위에서 센서타입별로 데이터를 변환하는 시간 딜레이 때문에
                    // 1초단위로 분석하지 않고, 샘플링레이트(개수) 단위로 분석한다.
                    int count = m_rawVect[ch].size();
                    if (count == m_samplingRate)
                    {
                        m_p2p[ch] = (this->*m_AnalFn0)(m_rawVect[ch]);
                        m_rms[ch] = (this->*m_AnalFn1)(m_rawVect[ch]);

                        //PublishEvent();

                        if (m_AnalysisConfig.m_UseDis)
                            m_pCalcDisTh->start();

                        m_rawVect[ch].clear();
                    }

                    QString writeData, dt, dd;
                    dt.sprintf("%04d-%02d-%02d %02d:%02d:%02d.%03d",
                                      m_DAQYear, m_DAQMonth, m_DAQDay, m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);
                    dd.sprintf(",%f", sensorData[ch]);
                    writeData = dt + dd;
                    QString format = "yyyy-MM-dd HH:mm:ss.zzz";
                    QDateTime stsensorDateTime = QDateTime::fromString(dt, format);

#ifdef KT_IOTMAKERS
                    if (m_ProtocolConfig.m_dam != 1 && m_ProtocolConfig.m_dam != 2 && m_ProtocolConfig.m_dam != 3)
                    {
                        // for sending to KtIoTMakers
                        RAWDATA rData;
                        rData.dt.sprintf("%04d-%02d-%02d %02d:%02d:%02d.%03d\"",
                                         m_DAQYear, m_DAQMonth, m_DAQDay, m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);
                        rData.data = sensorData[ch];
                        m_KtRawData[ch].append(rData);

                        /*****
                        m_KtSendCount++;

                        if (m_KtSendCount >= m_IoTM.m_GatherDataN)
                        {
                            /// Send data to KtIoTMakers
                            SendtoKTIoTM(m_KtRawData);

                            m_KtSendCount = 0;
                            m_KtRawData.clear();
                        }
                        *****/

                        //// using sampling during one second for making one sec data
                        if (m_KtRawData[ch].size() == m_SensorConfig.m_setSample)
                        {
                            m_KtRawVect[ch].append(m_KtRawData[ch]);
                            m_KtRawData[ch].clear();
                        }

                        //printf("KT_write - Ch : %d, RawData : %d, RawVect : %d\n", ch, m_KtRawData[ch].size(), m_KtRawVect[ch].size());
                        Write_KtIoTData(ch, rData.data, stsensorDateTime);
                    }
#endif  // KT_IOTMAKERS

                    if (m_MainConfig.m_iFiletype == 1)      // save by ASCII
                        Write_MqttData(ch, writeData, stsensorDateTime);
                    else if (m_MainConfig.m_iFiletype == 2) // save by Binary
                        Write_BinData(ch, sensorData[ch], stsensorDateTime);

                    CheckEvent(ch, sensorData[ch]);

                    PublishEvent(ch);
                    Publish(sensorData[ch]);
                    SendData(ch);
                }
            }
            else if (m_DAQYear > 2017 && m_setTimefromDAQ)
            {
                QString command;
                command.sprintf("sudo date -s \"%04d-%02d-%02d %02d:%02d:%02d.%02d\"",
                                m_DAQYear, m_DAQMonth, m_DAQDay, m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);
                system(command.toStdString().c_str());
//#ifdef DBGPRINT
                printf("time Set : %s\r\n", command.toStdString().c_str());
//#endif
                //command = "sudo hwclock -w";
                //system(command.toStdString().c_str());

                m_isTimeSet = true;
            }
        }
    }
    else if (cmd == 0xa0)   // GPS Data
    {
#ifdef DBGPRINT
        printf("GPS Data\r\n");
#endif
        int cnt = qData.size();
        if (cnt < 12)
        {
            printf("Packet_Error-G:%d ", cnt);
//#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("{%x}", *d);
                ++d;
            }
            printf("\r\n");
//#endif
        }
        else
        {
            char ch = qData.at(2);
            int val = (int)ch;
            ch = qData.at(3);
            val <<= 8;
            m_Lat1 = val | ch;

            ch = qData.at(4);
            val = (int)ch;
            ch = qData.at(5);
            val <<= 8;
            m_Lat2 = val | ch;

            ch = qData.at(7);
            val = (int)ch;
            ch = qData.at(8);
            val <<= 8;
            m_Lon1 = val | ch;

            ch = qData.at(9);
            val = (int)ch;
            ch = qData.at(10);
            val <<= 8;
            m_Lon2 = val | ch;

            ch = qData.at(6);
            if (ch == 0x4E)
                m_isNorth = true;
            else
                m_isNorth = false;

            ch = qData.at(11);
            if (ch == 0x45)
                m_isEest = true;
            else
                m_isEest = false;

#ifdef DBGPRINT
            printf("<<<%0x-%04d.%04d : %0x-%04d.%04d>>>\n", m_isNorth, m_Lat1, m_Lat2, m_isEest, m_Lon1, m_Lon2);
#endif
        }
    }
    else if (cmd == 0xb0)   // Temperature & Humidity Data
    {
#ifdef DBGPRINT
        printf("Temp.Humi Data\r\n");
#endif
        int cnt = qData.size();
        if (cnt < 6)
        {
            printf("Packet_Error-T:%d ", cnt);
//#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("{%x}", *d);
                ++d;
            }
            printf("\r\n");
//#endif
        }
        else
        {
            int val, temp, humi;

            char ch = qData.at(2);
            val = (int)ch;
            ch = qData.at(3);
            val <<= 8;
            temp = val | ch;

            ch = qData.at(4);
            val = (int)ch;
            ch = qData.at(5);
            val <<= 8;
            humi = val | ch;

            m_Temp = ((float)temp / 65536) * 165 - 40;
            m_Humi = ((float)humi / 65536) * 100;

#ifdef DBGPRINT
            printf("<%d:%d<<%.2f : %.2f>>>\n", temp, humi, m_Temp, m_Humi);
#endif
        }
    }
    else if (cmd == 0xc0)   // Voltage
    {
#ifdef DBGPRINT
        printf("Voltage Data\r\n");
#endif
        int cnt = qData.size();
        if (cnt < 5)
        {
            printf("Packet_Error-T:%d ", cnt);
//#ifdef DBGPRINT
            char *d = qData.data();
            for (int i=0; i<qData.size(); i++)
            {
                printf("{%x}", *d);
                ++d;
            }
            printf("\r\n");
//#endif
        }
        else
        {
            int val, volt;

            char ch = qData.at(2);
            val = (int)ch;
            ch = qData.at(3);
            val <<= 8;
            volt = val | ch;

            m_Volt = (float)volt / 10;

#ifdef DBGPRINT
            printf("<%d<<%.2f>>\n", volt, m_Volt);
#endif
        }
    }
}


void CMainTask::CheckDirectory(void)
{
    QString dirPath = m_MainConfig.m_FileSaveDir;
    dirPath += "/";
    dirPath += DATA_FILEPATH;
    dirPath += "/";

    QDir dir(dirPath);
    if (!dir.exists())
    {
        dir.mkpath(dirPath);
    }
}

QString CMainTask::GetDataFileName(int ch, QDateTime curDT)
{
    QString dirPath = m_MainConfig.m_FileSaveDir;
    dirPath += "/";
    dirPath += DATA_FILEPATH;
    dirPath += "/";
    dirPath += SMARTCS_DATA_FILEPATH;
    dirPath += "/";
    dirPath += RAW_FILEPATH;
    dirPath += "/";
    if (m_MainConfig.m_iFiletype == 1)
        dirPath += ASCII_FILEPATH;
    else if (m_MainConfig.m_iFiletype == 2)
        dirPath += BINARY_FILEPATH;

    CheckDirectory(dirPath);

    dirPath += "/";
    dirPath += m_MainConfig.m_UID;
    dirPath += "_";
    dirPath += m_MainConfig.m_DN;
    dirPath += "_";
    dirPath += m_MainConfig.m_DID;
    dirPath += "_";
    if (m_CHnum > 1)
    {
        QString asc;
        asc.sprintf("%1d", ch);

        dirPath += asc;
        dirPath += "_";
    }
    dirPath += curDT.toString("yyyyMMddhh");
    //printf("file : %s\n", dirPath.toStdString().c_str());
    if (m_MainConfig.m_iFiletype == 1)
        dirPath += ".csv";
    else if (m_MainConfig.m_iFiletype == 2)
        dirPath += ".bin";

    return dirPath;
}

#ifdef KT_IOTMAKERS
QString CMainTask::GetDataFileName5Min(int ch, QDateTime curDT)
{
    QString dirPath = m_MainConfig.m_FileSaveDir;
    dirPath += "/";
    dirPath += DATA_FILEPATH;
    dirPath += "/";
    dirPath += KTIOT_DATA_FILEPATH;
    dirPath += "/";
    dirPath += m_IoTM.m_ServiceID;
    dirPath += "/";

    //// making 5min interval
    qint64 eTime = curDT.toMSecsSinceEpoch();
    qint64 min5 = eTime % (300*1000);  // 300 : 5mins
    eTime = eTime - min5;
    QDateTime min5DT;
    min5DT.setMSecsSinceEpoch(eTime);
    min5DT = min5DT.toLocalTime();

    dirPath += min5DT.toString("yyyyMMdd");
    dirPath += "/";
    dirPath += min5DT.toString("hh");
    dirPath += "/";

    CheckDirectory(dirPath);

    dirPath += m_IoTM.m_DevID;
    dirPath += "_";
    if (m_CHnum > 1)
    {
        dirPath += m_IoTM.m_SensingDataTag[ch];
        dirPath += "_";
    }
    dirPath += min5DT.toString("yyyyMMddhhmm");
    //printf("file : %s\n", dirPath.toStdString().c_str());
    dirPath += ".bin";

    return dirPath;
}

void CMainTask::Write_KtIoTData(int ch, float value, QDateTime stCurrentDateTime)
{
    qint64 nEpoch = stCurrentDateTime.toMSecsSinceEpoch();
    QByteArray binEpoch, binData;
    QByteArray BbinEpoch, BbinData;

    //printf("Epoch : %d, Value : %f\n", nEpoch, value);

    binEpoch = QByteArray::fromRawData(reinterpret_cast<char *>(&nEpoch), sizeof(qint64));
    binData = QByteArray::fromRawData(reinterpret_cast<char *>(&value), sizeof(float));
    //binEpoch.append(binData);
    int len = binEpoch.size();
    for (int i=0; i<len; i++)
        BbinEpoch[i] = binEpoch[len-1-i];
    len = binData.size();
    for (int i=0; i<len; i++)
        BbinData[i] = binData[len-1-i];

    binEpoch.append(binData);
    BbinEpoch.append(BbinData);
    len = BbinEpoch.size();

#ifdef DBGPRINT
    printf("Epoch : %d, qint64 = %d Value : %f, float = %d\n", nEpoch, sizeof(qint64), value, sizeof(float));
    printf("size = %d ", len);
    for (int i=0; i<len; i++)
        printf("[%x]", binEpoch.at(i));
    printf("\n");
    for (int i=0; i<len; i++)
        printf("[%x]", BbinEpoch.at(i));
    printf("\n");
#endif

    //CheckDirectory();
    QString strFile = GetDataFileName5Min(ch, stCurrentDateTime);
    QFile file(strFile);
    if (!file.open(QFile::WriteOnly | QFile::Append))
    {
        printf("# Data file Open Error: %s\n", strFile.toStdString().data());
        return;
    }

    QDataStream stream(&file);
    stream.writeRawData(BbinEpoch.data(), len);
    file.flush();
    file.close();
}
#endif

#ifdef DBGFILESAVE
#endif

void CMainTask::Write_BinData(int ch, float value, QDateTime stCurrentDateTime)
{
    qint64 nEpoch = stCurrentDateTime.toMSecsSinceEpoch();
    QByteArray binEpoch, binData;
    QByteArray BbinEpoch, BbinData;

    //printf("Epoch : %d, Value : %f\n", nEpoch, value);

    binEpoch = QByteArray::fromRawData(reinterpret_cast<char *>(&nEpoch), sizeof(qint64));
    binData = QByteArray::fromRawData(reinterpret_cast<char *>(&value), sizeof(float));
    //binEpoch.append(binData);
    int len = binEpoch.size();
    for (int i=0; i<len; i++)
        BbinEpoch[i] = binEpoch[len-1-i];
    len = binData.size();
    for (int i=0; i<len; i++)
        BbinData[i] = binData[len-1-i];

    binEpoch.append(binData);
    BbinEpoch.append(BbinData);
    len = BbinEpoch.size();

#ifdef DBGPRINT
    printf("Epoch : %d, qint64 = %d Value : %f, float = %d\n", nEpoch, sizeof(qint64), value, sizeof(float));
    printf("size = %d ", len);
    for (int i=0; i<len; i++)
        printf("[%x]", binEpoch.at(i));
    printf("\n");
    for (int i=0; i<len; i++)
        printf("[%x]", BbinEpoch.at(i));
    printf("\n");
#endif

    //CheckDirectory();
    QString strFile = GetDataFileName(ch, stCurrentDateTime);
    QFile file(strFile);
    if (!file.open(QFile::WriteOnly | QFile::Append))
    {
        printf("# Data file Open Error: %s\n", strFile.toStdString().data());
        return;
    }

    QDataStream stream(&file);
    stream.writeRawData(BbinEpoch.data(), len);
    file.flush();
    file.close();
}

void CMainTask::Write_MqttData(int ch, QString strData, QDateTime stCurrentDateTime)
{
    QString strFile = GetDataFileName(ch, stCurrentDateTime);
    QFile file(strFile);
    if (!file.open(QFile::WriteOnly | QFile::Append | QFile::Text))
    {
        printf("# Data file Open Error: %s\n", strFile.toStdString().data());
        return;
    }

    QTextStream stream(&file);
    stream << strData + "\n";
    file.flush();
    file.close();
}

void CMainTask::Write_SendData(int ch, QString strData, QDateTime stCurrentDateTime)
{
    QString strFile = GetDataFileName(ch, stCurrentDateTime);
    QFile file(strFile);
    if (!file.open(QFile::WriteOnly | QFile::Append | QFile::Text))
    {
        printf("# Data file Open Error: %s\n", strFile.toStdString().data());
        return;
    }

    QTextStream stream(&file);
    stream << strData + "\n";
    file.flush();
    file.close();
}
#endif //XX

void CMainTask::CheckDirectory(QString dirPath)
{
    QDir dir(dirPath);
    if (!dir.exists())
    {
        dir.mkpath(dirPath);
    }
}

void CMainTask::Take_aPicture(int mode, DAQDATA qData)
{
    /*****
    m_CameraTh.m_FileDT.sprintf("%4d%02d%02d%02d%02d%02d%03d", m_DAQYear, m_DAQMonth, m_DAQDay,
                                  m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);
    m_CameraTh.m_bThreadRun = true;
    *****/

    QString dataPath;
    QString dirPath = m_MainConfig.m_FileSaveDir;
    dirPath += "/";
    dataPath = dirPath;
    dataPath += DATA_FILEPATH;
    dataPath += "/";
    dataPath += SMARTCS_DATA_FILEPATH;
    dataPath += "/";
    dataPath += IMG_FILEPATH;

    CheckDirectory(dataPath);

    dataPath += "/";
    dataPath += m_MainConfig.m_UID;
    dataPath += "_";
    dataPath += m_MainConfig.m_DN;
    dataPath += "_";
    dataPath += m_MainConfig.m_DID;
    dataPath += "_";

    QString saveFileName;
    saveFileName.sprintf("%4d%02d%02d%02d%02d%02d%03d.jpg", qData.iYear, qData.iMonth, qData.iDay,
                                           qData.iHour, qData.iMinute, qData.iSec, qData.iMilSec);
    dataPath += saveFileName;

    //QProcess *proc;
    //m_extProc = new QProcess();
    QProcess proc;

    //connect(m_extProc, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(done(int, QProcess::ExitStatus)));

    /*****
    QString exePath = "fswebcam";
    QStringList arg;
    arg << "-r" << "640x480" << dirPath;
    *****/

    QString exePath = dirPath;
    if (mode == 1)
        exePath += "takePicAndsendMail.sh";
    else if (mode == 2)
        exePath += "takePicAndsendMail_1h.sh";

    QStringList arg;
    arg << dataPath << "&";
    //proc->start(exePath, arg);
    //m_extProc->execute(exePath, arg);
    proc.execute(exePath, arg);

#ifdef XX
    connect(proc, qOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
            [=](int exitCode, QProcess::ExitStatus exitStatus){proc->deleteLater();});

    connect(proc, static_cast<void(QProcess::*)(int, QProcess::ExitStatus)>(&QProcess::finished),
            [proc](int exitCode, QProcess::ExitStatus exitStatus)
    {
        proc->deleteLater();
    })
#endif

    qDebug() << exePath << arg;
    printf("Created jpeg image by camera !!!\n\r");
}

void CMainTask::done(int exitCode, QProcess::ExitStatus exitStatus)
{
    qDebug() << "CameraThread done";
}

#ifdef XX
// mqtt publish (mqtt 전송)
void CMainTask::Publish(float rawdata)
{
    if (m_ProtocolConfig.m_dam == 7)
        return;
    if (m_ProtocolConfig.m_dam == 2)
        return;

    // Date/Time
    QString payload;
    payload.sprintf("%4d%02d%02d %02d%02d%02d.%03d,", m_DAQYear, m_DAQMonth, m_DAQDay,
                   m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);

    payload += QString::number(rawdata, 'f', 5);
    QMQTT::Message mqttMsg(0 /*or 1*/, m_CubeConfig.m_mqttTopic, payload.toUtf8());

    m_mqttClient->publish(mqttMsg);
#ifdef DBGPRINT
    printf("Publish: %s, %s\n", m_CubeConfig.m_mqttTopic.toStdString().data(), payload.toStdString().data());
#endif
}

// 이벤트 조건을 체크하고,
void CMainTask::CheckEvent(int ch, float rawdata)
{
    if (m_AnalysisConfig.m_tv > 0 && !m_isEvent)
    {
        //if (qFabs(rawdata) > m_triggerValue)
        if (fabs(rawdata) > m_triggerValue[ch])
        {
            m_isEvent[ch] = true;
            m_isMadeData[ch] = false;
            m_eventDataCount[ch] = 0;

            m_eventVect[ch].clear();

            // Date/Time
            QString text;
            text.sprintf("%4d%02d%02d %02d%02d%02d.%03d,", m_DAQYear, m_DAQMonth, m_DAQDay,
                           m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);
            m_rawString[ch] = text;
            m_rawString[ch] += m_eventQueue[ch].getQueue(m_eventVect[ch]);

            //// Take a Picture
            ////Take_aPicture(1);   // taking picture for Event

            printf("Value Triggered !!! - %.5f:%.5f\r\n", rawdata, m_triggerValue[ch]);
        }
    }
}

// 이벤트 조건을 체크하고, 이벤트가 발생했을 경우 MQTT로 데이터를 전송한다.
void CMainTask::PublishEvent(int ch)
{
    if (m_isEvent[ch] && m_isMadeData[ch])
    {
        m_isEvent[ch] = false;
        m_isMadeData[ch] = false;

        QString payload = m_rawString[ch];

        /*
        QMQTT::Message mqttMsg(0, m_CubeConfig.m_eventTopic, payload.toUtf8());
        m_mqttClient->publish(mqttMsg);
        */

        QString contents;
#ifdef NCUBE_172
        contents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}<EOF>",
#else
        contents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}",
#endif
                         m_CubeConfig.m_tcpCtnRawe.toStdString().c_str(),
                         payload.toStdString().c_str());

        // 앤큐브에 전송한다. 결과적으로 서버플랫폼의 DB에 데이터가 저장됨
        m_socket->write(contents.toStdString().c_str());

        printf("Tcp-Send:%s\r\n", contents.toStdString().c_str());

        m_rawString[ch].clear();

        printf("Event data published!!!\n");

        SendEventAnalData(ch);
    }
}
#endif //XX

unsigned int CMainTask::GetSendTimeValue()
{
    return m_ProtocolConfig.m_tcpPeriod * m_ProtocolConfig.m_ft;
}

#ifdef XX
// tcp, 앤큐브에 전송
void CMainTask::SendData(int ch)
{
    if (m_ProtocolConfig.m_dam == 7)
        return;
    if (m_ProtocolConfig.m_dam == 1 || m_AnalysisConfig.m_tp == 1)
        return;

#ifdef DBGPRINT
    printf("Count=%d\r\n", m_sendTimeCount);
#endif

    if (m_sendTimeCount >= m_ProtocolConfig.m_tcpPeriod)
    {
        m_sendTimeCount = 0;

        QString packet;
        QString text;

        // Date/Time
        packet.sprintf("%4d%02d%02d %02d%02d%02d.%03d,", m_DAQYear, m_DAQMonth, m_DAQDay,
                       m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);

        // P-P
        text.sprintf("%.5f,", m_p2p[ch]); // 주의: 값뒤에 "," 있음
        packet += text;

        // RMS
        text.sprintf("%.5f,", m_rms[ch]); // 주의: 값뒤에 "," 있음
        packet += text;

        // Event
        text = m_isEvent[ch] ? "1," : "0,";
        packet += text;

        // Location
        text.sprintf("%04d.%04d,%c,%04d.%04d,%c,", m_Lat1, m_Lat2, m_isNorth ? 'N' : 'S',
                     m_Lon1, m_Lon2, m_isEest ? 'E' : 'W');
        packet += text;

        // 온도
        text.sprintf("%.2f,", m_Temp);
        packet += text;

        // 습도
        text.sprintf("%.2f,", m_Humi);
        packet += text;

        // D-inf
        text = "000";
        packet += text;

        QString contents;
#ifdef  NCUBE_172
        contents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}<EOF>",
#else
        contents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}",
#endif
                         m_CubeConfig.m_tcpCtnAnal.toStdString().c_str(),
                         packet.toStdString().c_str());

        // 앤큐브에 전송한다. 결과적으로 서버플랫폼의 DB에 데이터가 저장됨
        m_socket->write(contents.toStdString().c_str());

        printf("Tcp-Send: %d sec: %s\r\n", m_sendTimeValue, contents.toStdString().c_str());
        fflush(stdout);
        //printf("Tcp-Send: %d sec: %s\r\n", m_sendTimeValue, packet.toStdString().c_str());
    }
}
#endif /XX

//
void CMainTask::OnSendTimer()
{
    m_sendTimeCount++;
}

void CMainTask::On10MinsTimer()
{
    static int TenMinsCnt = 0;

    ////Take_aPicture(2);

    TenMinsCnt++;

    if (TenMinsCnt >= m_MainConfig.m_iSetTimePeriod)
    {
        TenMinsCnt = 0;
        setDAQTime();
    }
}

#ifdef KT_IOTMAKERS
#ifdef XX
void CMainTask::OnOneSecTimer()
{
    //statSecs++;
    //stat10m++;
}

void CMainTask::OnOneSecTimer()
{
    static int statSecs = 0;
    static int stat10m = 0;

    static int statIdx = 0;

    if (m_ProtocolConfig.m_dam == 7)
        return;

    if (m_ProtocolConfig.m_dam == 1 || m_ProtocolConfig.m_dam == 2 || m_ProtocolConfig.m_dam == 3)
        return;

    statSecs++;

    if (statSecs >= m_IoTM.m_Stat_Sec)
    {
        statSecs = 0;

        for (int ch=0; ch<m_CHnum; ch++)
        {
            QVector<float> statData;
            QVector<RAWDATA> statRawData;

            printf("\n>>>>>>Ch = %d\n", ch);
            statRawData = makeStatData(ch, statIdx, m_IoTM.m_Stat_Sec);

            if (statRawData.size() < 1)
                return;

            for (int i=0; i<statRawData.size(); i++)
            {
                RAWDATA rData;
                rData = statRawData.at(i);
                statData.append(rData.data);
            }
            printf("\n>>Ch=%d>> %d sec(s) !!! ---> %d, %d\n", ch, m_IoTM.m_Stat_Sec, m_KtRawVect[ch].size(), statData.size());

            float minValue = Analysis_Min(statData);
            float maxValue = Analysis_Max(statData);

            RAWDATA lastData = statRawData.last();

            printf(">>Ch=%d>>%s -> Min : %f, Max : %f\n", ch, lastData.dt.toStdString().c_str(), minValue, maxValue);

            if (m_isConnectedKTIoTM)
            {
                m_IoTM.SendMinMax(ch, minValue, maxValue, lastData.dt);
            }

            statData.clear();
            statRawData.clear();
        }
        statIdx += m_IoTM.m_Stat_Sec;
    }

    stat10m++;

    if (stat10m >= SECS10MINS)    // 10 mins
    {
        stat10m = 0;

        // Make 10mins Statistics
        for (int ch=0; ch<m_CHnum; ch++)
        {
            QVector<float> statData;
            QVector<RAWDATA> statRawData;

            printf("\n>>>>>>Ch = %d\n", ch);
            statRawData = makeStatData(ch, 0, SECS10MINS);

            if (statRawData.size() < 1)
                return;

            for (int i=0; i<statRawData.size(); i++)
            {
                RAWDATA rData;
                rData = statRawData.at(i);
                statData.append(rData.data);
            }
            printf(">>Ch=%d>> 10 mins !!! ---> %d, %d\n", ch, m_KtRawVect[ch].size(), statData.size());

            float minValue = Analysis_Min(statData);
            float maxValue = Analysis_Max(statData);
            float avgValue = Analysis_Avg(statData);
            float stdValue = Analysis_Std(statData);

            RAWDATA lastData = statRawData.last();

            printf(">>Ch=%d>>%s -> Min : %f, Max : %f, Avg : %f, Std : %f\n",
                   ch, lastData.dt.toStdString().c_str(), minValue, maxValue, avgValue, stdValue);

            if (m_isConnectedKTIoTM)
            {
                m_IoTM.Send10minStat(ch, minValue, maxValue, avgValue, stdValue, lastData.dt);
            }

            //m_KtRawVect.clear();
            for (int i=0; i<SECS10MINS; i++)
            {
                QVector<RAWDATA> rawVect = m_KtRawVect[ch].first();
                rawVect.clear();
                m_KtRawVect[ch].removeFirst();
            }

            statData.clear();
            statRawData.clear();
        }
        statIdx -= SECS10MINS;
    }
}

//QVector<float> CMainTask::makeStatData()
QVector<RAWDATA> CMainTask::makeStatData(int ch, int nIdx, int nNum)
{
    //QVector<float> statData;
    QVector<RAWDATA> statRawData;
    statRawData.clear();

    printf("[Ch = %d [Idx : %d, nNum : %d]] - %d\n", ch, nIdx, nNum, m_KtRawVect[ch].size());
    if (m_KtRawVect[ch].size() < nIdx+nNum)
        return statRawData;

    //if (m_KtRawVect.size() >= 1)
    {
        //printf("\n");
        for (int i=nIdx; i<nIdx+nNum; i++)
        {
            QVector<RAWDATA> rawData;
            rawData = m_KtRawVect[ch].at(i);
            statRawData = statRawData + rawData;
            //printf(">%d ", rawData.size());
        }
        //printf("\n");
        //printf(">>>>>%d\n", statRawData.size());

    }

    //return statData;
    return statRawData;
}
#endif //XX
#endif  // KT_IOTMAKERS

#ifdef XX
void CMainTask::SendEventAnalData(int ch)
{
    QString packet;
    QString text;

    float analdata0 = (this->*m_AnalFn0)(m_eventVect[ch]);
    float analdata1 = (this->*m_AnalFn1)(m_eventVect[ch]);

    // Date/Time
    packet.sprintf("%4d%02d%02d %02d%02d%02d.%03d,", m_DAQYear, m_DAQMonth, m_DAQDay,
                   m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec);

    // Analysis function - main
    text.sprintf("%.5f,", analdata0); // Warning : There is a "," at the end of the value
    packet += text;

    // Analysis function - sub
    text.sprintf("%.5f,", analdata1); // Warning : There is a "," at the end of the value
    packet += text;

    // Event
    text = "1,";
    packet += text;

    // Location
    text.sprintf("%04d.%04d,%c,%04d.%04d,%c,", m_Lat1, m_Lat2, m_isNorth ? 'N' : 'S',
                 m_Lon1, m_Lon2, m_isEest ? 'E' : 'W');
    packet += text;

    // 온도
    text.sprintf("%.2f,", m_Temp);
    packet += text;

    // 습도
    text.sprintf("%.2f,", m_Humi);
    packet += text;

    // D-inf
    text = "000";
    packet += text;

    QString contents;
#ifdef  NCUBE_172
    contents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}<EOF>",
#else
    contents.sprintf("{\"ctname\":\"%s\", \"con\":\"%s\"}",
#endif
                     m_CubeConfig.m_tcpCtnAnal.toStdString().c_str(),
                     packet.toStdString().c_str());

    // 앤큐브에 전송한다. 결과적으로 서버플랫폼의 DB에 데이터가 저장됨
    m_socket->write(contents.toStdString().c_str());

    printf("Tcp-Send(Event): %d sec: %s\r\n", m_sendTimeValue, contents.toStdString().c_str());
    fflush(stdout);
}

#ifdef KT_IOTMAKERS
void CMainTask::SendtoKTIoTM(int ch, QVector<RAWDATA> RawVect)
{
    if (m_ProtocolConfig.m_dam == 7)
        return;

    if (m_ProtocolConfig.m_dam == 1 || m_ProtocolConfig.m_dam == 2 || m_ProtocolConfig.m_dam == 3)
        return;

    if (m_isConnectedKTIoTM)
    {
//#ifdef DBGPRINT
        qDebug() << "Send Data to KT IoTM:";
//#endif
        //if (m_IoTM.SendData(RawVect) < 0)
        //    m_isConnectedKTIoTM = false;
        m_IoTM.SendData(ch, RawVect);
    }
}
#endif
#endif /XX

void CMainTask::ConnectedMqtt()
{
    mqttBMutex.lock();
    m_bMQTTConnected = true;
    mqttBMutex.unlock();
    printf("Connected Mqtt: ID=%s, Address=%s \r\n",
           m_CubeConfig.m_mqttId.toStdString().c_str(),
           m_CubeConfig.m_mqttServer.toStdString().c_str());
}

void CMainTask::DisconnectedMqtt()
{
    mqttBMutex.lock();
    m_bMQTTConnected = false;
    mqttBMutex.unlock();
    printf("# Disconnected ID=%s, Address=%s \r\n",
           m_CubeConfig.m_mqttId.toStdString().c_str(),
           m_CubeConfig.m_mqttServer.toStdString().c_str());

}

// 센서의 설정명령을 전송하고, 센서에게 데이터 전송요청
void CMainTask::SendCommand(bool isEnd)
{
    int len = strlen(m_commandBuff);
    emit SendSensorPacket(m_commandBuff, len, false);
    printf("Send to Serial -> %s\r\n", m_commandBuff);
}

#ifdef XX
float CMainTask::Analysis_Min(QVector<float> rawVect)
{
    //printf("Make MIN\r\n");
    float min = *std::min_element(rawVect.constBegin(), rawVect.constEnd());

    return min;
}

float CMainTask::Analysis_Max(QVector<float> rawVect)
{
    //printf("Make MAX\r\n");
    float max = *std::max_element(rawVect.constBegin(), rawVect.constEnd());

    return max;
}

float CMainTask::Analysis_Avg(QVector<float> rawVect)
{
    //printf("Make AVG\r\n");
    double avg;

    for (int i = 0; i < rawVect.size(); i++)
    {
        avg += rawVect.at(i);
    }
    avg = avg / (float)rawVect.size();

    return (float)avg;
}

float CMainTask::Analysis_Std(QVector<float> rawVect)
{
    //printf("Make STD\r\n");
    double avg, sum, variance;
    float stdVal;

    avg = Analysis_Avg(rawVect);

    for (int i = 0; i < rawVect.size(); i++)
    {
        sum += pow(rawVect.at(i)-avg, 2);
    }

    variance = sum / (float)rawVect.size();
    stdVal = sqrt(variance);

    return stdVal;
}

float CMainTask::Analysis_P2P(QVector<float> rawVect)
{
    //printf("Make P-P\r\n");
    float minVal = *std::min_element(rawVect.constBegin(), rawVect.constEnd());
    float maxVal = *std::max_element(rawVect.constBegin(), rawVect.constEnd());
    float p2p = maxVal - minVal;

    return p2p;
}

float CMainTask::Analysis_Rms(QVector<float> rawVect)
{
    //printf("Make RMS\r\n");
    float rms = 0.0f;
    foreach (float f, rawVect)
    {
        rms += (f * f);
    }
    rms = sqrt( (rms / (float)rawVect.size()) );
    return rms;

    //float rms = std::inner_product(m_rawVect.constBegin(), m_rawVect.constEnd(), m_rawVect.constBegin(), 0);
    //rms = sqrt( (rms / (float)m_rawVect.size()) );

    //return rms;
}
#endif //XX

void CMainTask::SetReboot(QString val)
{
    ////m_sendTimer.stop();
    ////m_sendTimeCount = 0;
    emit stopTimer();

    ClearSensorData();

    QStringList strlist = val.split(",");

    QString text = strlist.at(1);
    int ibootType = text.toInt();

    QProcess *proc = new QProcess();

    printf("Set Reboot... %d\r\n", ibootType);

    if (ibootType == 0)         // Warm boot -- IotSensor program only...
    {
        //proc->start("killall IotSensor7");
        emit quitProgram();
    }
    else if (ibootType == 1)    // Cold boot -- system reboot...
    {
        proc->start("reboot");
    }
}

// 실행중 분석 설정/제어 명령어를 수신했을 때
void CMainTask::SetMainConfig(QString val)
{
    //m_sendTimer.stop();
    //m_sendTimeCount = 0;
    emit stopTimer();

    printf("Setting Main-Config \r\n");

    QStringList strlist = val.split(",");

    QString text = strlist.at(0);
    m_MainConfig.m_iFiletype = text.toInt();
    text = strlist.at(1);
    m_MainConfig.m_iUseCamera = text.toInt();
    text = strlist.at(2);
    m_MainConfig.m_iSetTimePeriod = text.toInt();

    // 파일에 저장
    m_MainConfig.WriteFile();
    usleep(30000);

    // 타이머 재시작
    //startTimer();
    emit beginTimer();
}

// 실행중 센서 설정/제어 명령어를 수신했을 때 적용
void CMainTask::SetSensorConfig(QString val)
{
    //m_sendTimer.stop();
    //m_sendTimeCount = 0;
    emit stopTimer();

    printf("Setting Sensor-Config \r\n");

    ClearSensorData();

    // 데이터 순서: SET명령, Sensitivity, Capacity, Factor
    QStringList strlist = val.split(",");

    QStringList strText = strlist.at(0).split("-");
    QString value1 = strText.at(0).trimmed();
    QString value2 = strText.at(1).trimmed();
    QString value3 = strText.at(2).trimmed();
    m_SensorConfig.m_command = value1 + "," + value2;
    m_SensorConfig.m_setSample = value1.toInt();
    m_SensorConfig.m_setType = value2.toInt();
    m_SensorConfig.m_filteron = value3.toInt();

    value1 = strlist.at(1);
    m_SensorConfig.m_sensitivity[0] = value1.toFloat();
    m_SensorConfig.m_sensitivity[1] = value1.toFloat();
    m_SensorConfig.m_sensitivity[2] = value1.toFloat();

    value1 = strlist.at(2);
    m_SensorConfig.m_capacity[0] = value1.toFloat();
    m_SensorConfig.m_capacity[1] = value1.toFloat();
    m_SensorConfig.m_capacity[2] = value1.toFloat();

    value1 = strlist.at(3);
    m_SensorConfig.m_extfactor[0] = value1.toFloat();
    m_SensorConfig.m_extfactor[1] = value1.toFloat();
    m_SensorConfig.m_extfactor[2] = value1.toFloat();

    value1 = strlist.at(4);
    m_SensorConfig.m_offset[0] = value1.toFloat();
    m_SensorConfig.m_offset[1] = value1.toFloat();
    m_SensorConfig.m_offset[2] = value1.toFloat();

    value1 = strlist.at(5);
    m_SensorConfig.m_range[0] = value1.toFloat();
    m_SensorConfig.m_range[1] = value1.toFloat();
    m_SensorConfig.m_range[2] = value1.toFloat();

    value1 = strlist.at(6);
    m_SensorConfig.m_exVolt = value1.toFloat();

    value1 = strlist.at(7);
    m_SensorConfig.m_gFactor = value1.toFloat();

    setConverter();

    // 파일에 저장
    m_SensorConfig.WriteFile();
    usleep(30000);

    setSensorSampling();
    SendCommand(false);
    setDAQFilter();

    // 타이머 재시작
    //startTimer();
    emit beginTimer();
}

// 실행중 통신 설정/제어 명령어를 수신했을 때 적용
void CMainTask::SetCommunicationConfig(QString val)
{
    //m_sendTimer.stop();
    //m_sendTimeCount = 0;
    emit stopTimer();

    printf("Setting Communication-Config \n");

    ClearSensorData();

    QStringList strlist = val.split(",");

    QString text = strlist.at(0);
    m_ProtocolConfig.m_dam = text.toInt();

    text = strlist.at(1);
    int value = text.toInt();
    m_ProtocolConfig.m_ft = value;

    // 파일에 저장
    m_ProtocolConfig.WriteFile();
    usleep(30000);

    setSensorSampling();
    SendCommand(false);

    // 타이머 재시작
    //startTimer();
    emit beginTimer();
}

// 실행중 분석 설정/제어 명령어를 수신했을 때
void CMainTask::SetAnalysisConfig(QString val)
{
    //m_sendTimer.stop();
    //m_sendTimeCount = 0;
    emit stopTimer();

    printf("Setting Analysis-Config \r\n");

    for (int i=0; i<3; i++)
    {
        m_p2p[i] = 0;
        m_rms[i] = 0;
        //m_analFn0 = 0;
        //m_analFn1 = 1;
    }

    QStringList strlist = val.split(",");

    QString text = strlist.at(0);
    m_AnalysisConfig.m_tv = text.toInt();
    text = strlist.at(1);
    m_AnalysisConfig.m_tp = text.toInt();

    if (strlist.size() >= 4)
    {
        text = strlist.at(2);
        m_AnalysisConfig.m_AnalFn0 = text.toUpper();
        text = strlist.at(3);
        m_AnalysisConfig.m_AnalFn1 = text.toUpper();
    }

    calcTriggerValue();

    // 파일에 저장
    m_AnalysisConfig.WriteFile();
    usleep(30000);

    // 타이머 재시작
    //startTimer();
    emit beginTimer();
}

// 실행중 패킷 설정/제어 명령어를 수신했을 때 적용
void CMainTask::SetPacketConfig(QString val)
{
    printf("Setting Packet-Config \r\n");

    // TCP 전송 중지
    //m_sendTimer.stop();
    //m_sendTimeCount = 0;
/*
    int sendFlag = CProtocolConfig::m_tcpsendFlag;
    CProtocolConfig::m_tcpsendFlag = 0;

    // 데이터 순서: 위치, 온도, 습도
    QStringList strlist = val.split(",");

    QString text = strlist.at(0);
    CProtocolConfig::m_locFlag = text.toInt();

    text = strlist.at(1);
    CProtocolConfig::m_tempFlag = text.toInt();

    text = strlist.at(2);
    CProtocolConfig::m_humFlag = text.toInt();

    // 기존 sendFlag 복구 시키고, 값에 따라 타이머 재시작
    CProtocolConfig::m_tcpsendFlag = sendFlag;
    if( CProtocolConfig::m_tcpsendFlag == 1 )
    {
        m_sendTimer.start(1000);
    }

    // 파일에 저장
    CProtocolConfig::WriteFile();
*/
}

// 센서의 설정상태, 통신 설정상태 요청 메시지 처리
void CMainTask::ReqSensorState(QString val)
{
    printf("Request Sensor state\r\n");

    QString response;
    QString text;

    response = "{\"ctname\":\"";
    response += m_CubeConfig.m_tcpCtnCnfg;
    response += "\", \"con\":\"";

    // datetime,sensortype,samplingrate,filteronoff,sensitivity,capacity,extfactor,t-v,t-p,d-a-m,f-t
    text.sprintf("%4d%02d%02d %02d%02d%02d.%03d,%d,%d,%01d,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%.3f,%d,%d,%d,%d",
                 m_DAQYear, m_DAQMonth, m_DAQDay, m_DAQHour, m_DAQMinute, m_DAQSec, m_DAQMilSec,
                 m_SensorConfig.m_setType,
                 m_SensorConfig.m_setSample,
                 m_SensorConfig.m_filteron,
                 m_SensorConfig.m_sensitivity[0],
                 m_SensorConfig.m_capacity[0],
                 m_SensorConfig.m_extfactor[0],
                 m_SensorConfig.m_offset[0],
                 m_SensorConfig.m_range[0],
                 m_SensorConfig.m_exVolt,
                 m_SensorConfig.m_gFactor,
                 m_AnalysisConfig.m_tv,
                 m_AnalysisConfig.m_tp,
                 m_ProtocolConfig.m_dam,
                 m_ProtocolConfig.m_ft);
    response += text;
#ifdef  NCUBE_172
    response += "\"}<EOF>";
#else
    response += "\"}";
#endif
    m_socket->write(response.toStdString().c_str());
    printf("Respond Sensor state: %s\r\n", response.toStdString().c_str());
}
