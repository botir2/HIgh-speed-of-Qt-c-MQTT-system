﻿#include <QString>
#include <QFile>

#include "DisQueue.h"

CDisQueue::CDisQueue()
{
    m_queueSize = 0;
}

void CDisQueue::setSize(int size)
{
    m_queueSize = size;
}

int CDisQueue::getSize()
{
    return m_Veclist.size();
}

void CDisQueue::enQueue(const QVector<double> &DisVec)
{
    if (m_Veclist.size() >= m_queueSize)
        m_Veclist.pop_front();
    m_Veclist.push_back(DisVec);
    //printf("Queue Size : %d\r\n", m_flist.count());
}

QVector<double> CDisQueue::deQueue()
{
    QVector<double> DisVec = m_Veclist.first();
    m_Veclist.pop_front();

    return DisVec;
}

/*****
QString CDisQueue::getQueue()
{
    QString val;
    QString ret;
    float fval;

    ret.clear();

    while (!m_flist.isEmpty())
    {
        fval = m_flist.first();
        m_flist.pop_front();

        //val = QString::number(m_flist.pop_front(), 'f', 5) + ",";
        val.sprintf("%.5f,", fval);
        ret += val;
    }

    return ret;
}

QString CDisQueue::getQueue(QVector<float> eventVect)
{
    QString val;
    QString ret;
    float fval;

    ret.clear();

    while (!m_flist.isEmpty())
    {
        fval = m_flist.first();
        m_flist.pop_front();

        eventVect.append(fval);
        //val = QString::number(m_flist.pop_front(), 'f', 5) + ",";
        val.sprintf("%.5f,", fval);
        ret += val;
    }

    return ret;
}
*****/
