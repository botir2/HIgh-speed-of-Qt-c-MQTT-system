#include "IoTSensor.h"
#include "maintask.h"

#include "mqtttask.h"

MQTTTask::MQTTTask(QObject *parent) :
    QObject(parent)
{
}

void MQTTTask::runProc(void)
{
    DAQDATA qData;

    while (1)
    {
        QThread::usleep(1000);
        qData.iYear = 1970;

        m_pMain->m_MQTTMutex.lock();   ////

        if (m_pMain->m_MQTTDatas.size() > 0)
        {
            qData = m_pMain->m_MQTTDatas.first();
        }

        m_pMain->m_MQTTMutex.unlock(); ////

        if (qData.iYear > 1970)
        {
#ifdef DBGPRINT
        printf("\n");
        printf("> Ch:%01d> %04d-%02d-%02d %02d:%02d:%02d.%03d <%.4f><%.4f><%.4f>\n",
               qData.iCh, qData.iYear, qData.iMonth, qData.iDay, qData.iHour, qData.iMinute, qData.iSec, qData.iMilSec,
               qData.fsensorData[0], qData.fsensorData[1], qData.fsensorData[2]);
#endif
            Publish(qData);

            m_pMain->m_MQTTMutex.lock();   ////
            m_pMain->m_MQTTDatas.removeFirst();
            m_pMain->m_MQTTMutex.unlock(); ////
        }
    }
}

/*
void MQTTTask::ConnectedMqtt()
{
    printf("Connected Mqtt: ID=%s, Address=%s \r\n",
           m_pMain->m_CubeConfig.m_mqttId.toStdString().c_str(),
           m_pMain->m_CubeConfig.m_mqttServer.toStdString().c_str());
}

void MQTTTask::DisconnectedMqtt()
{
    printf("# Disconnected ID=%s, Address=%s \r\n",
           m_pMain->m_CubeConfig.m_mqttId.toStdString().c_str(),
           m_pMain->m_CubeConfig.m_mqttServer.toStdString().c_str());
}

// mqtt 생성, 연결(퍼블리셔)
void MQTTTask::InitMqtt()
{
    // mqtt - 퍼블리셔
    m_mqttClient = new QMQTT::Client();

    connect(m_mqttClient, SIGNAL(connected()), m_pMain, SLOT(ConnectedMqtt()));
    connect(m_mqttClient, SIGNAL(disconnected()), m_pMain, SLOT(DisconnectedMqtt()));

    // mqtt 서버와 연결
    m_mqttClient->setHost(QHostAddress(m_pMain->m_CubeConfig.m_mqttServer));
    m_mqttClient->setPort(1883);
    m_mqttClient->setClientId(m_pMain->m_CubeConfig.m_mqttId); // Set different id each device.
    m_mqttClient->connectToHost();

    m_mqttClient->setAutoReconnect(true);
    m_mqttClient->setKeepAlive(30);
}
*/

// mqtt publish (mqtt 전송)
void MQTTTask::Publish(DAQDATA qData)
{
    if (m_pMain->m_ProtocolConfig.m_dam == 2 || m_pMain->m_ProtocolConfig.m_dam == 4 || m_pMain->m_ProtocolConfig.m_dam == 6 || m_pMain->m_ProtocolConfig.m_dam == 7)
        return;

    // Date/Time
    QString payload;
    payload.sprintf("%4d%02d%02d %02d%02d%02d.%03d,", qData.iYear, qData.iMonth, qData.iDay,
                   qData.iHour, qData.iMinute, qData.iSec, qData.iMilSec);

    payload += QString::number(qData.fsensorData[0], 'f', 5);

    for (int ch=1; ch<qData.iCh; ch++)
    {
        payload += ",";
        payload += QString::number(qData.fsensorData[ch], 'f', 5);
    }

    emit publishMsg(payload);
#ifdef XX
    for (int ch=0; ch<qData.iCh; ch++)
        payload += QString::number(qData.fsensorData[ch], 'f', 5);

    emit publishMsg(payload);

    m_pMain->mqttBMutex.lock();
    if (m_pMain->m_bMQTTConnected)
    {
        QMQTT::Message mqttMsg(0 /*or 1*/, m_pMain->m_CubeConfig.m_mqttTopic, payload.toUtf8());
        m_pMain->m_mqttClient->publish(mqttMsg);
    }
    else
        printf("Publish failed: %s, %s\n", m_pMain->m_CubeConfig.m_mqttTopic.toStdString().data(), payload.toStdString().data());
    m_pMain->mqttBMutex.unlock();

#ifdef DBGPRINT
    printf("Publish: %s, %s\n", m_pMain->m_CubeConfig.m_mqttTopic.toStdString().data(), payload.toStdString().data());
#endif
#endif /XX
}
