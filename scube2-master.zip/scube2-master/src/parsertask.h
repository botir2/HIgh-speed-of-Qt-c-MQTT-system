#ifndef PARSERTASK_H
#define PARSERTASK_H

#include <QObject>
#include <QThread>
#include <QDebug>

#include "IoTSensor.h"
#include "maintask.h"

class ParserTask : public QObject
{
    Q_OBJECT
public:
    explicit ParserTask(QObject *parent = 0);

signals:

public slots:
    void runProc(void);

public:
    CMainTask *m_pMain;

    DAQDATA m_oldData;
    DAQGPSDATA m_daqGPS;
    DAQSTATUS m_daqStatus;

    bool isTimeValid(DAQDATA daqData);
    void TimeCheckAndFill(DAQDATA daqData);
    void FillTime(DAQDATA oldData, int iter, int iTimeGap);
    void MakeFileData(DAQDATA daqData);

    void ParsePacket(QByteArray data);
};

#endif // PARSERTASK_H
