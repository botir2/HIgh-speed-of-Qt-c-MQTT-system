﻿#ifndef SENSORCONFIG_H
#define SENSORCONFIG_H

#include <QString>


#define ANALYSIS_NUM  2

// sensor_config.txt 파일을 읽어 각 상태를 설정하거나,
// 설정데이터를 받아서 적용하고 파일로 저장
// 객체생성없이 전역적으로 사용하기 위해서 static 변수와 함수 사용

//enum SENSORTYPE_INDEX { ACC_Y, ACC_X, ACC_Z, ACC_ALL, STRAIN, DISPLACEMENT
//                      , LOADCELL, TILT, ACC_STRAIN, THERMOCOUPLE, IEPE };


class CSensorConfig
{

public:
    CSensorConfig();

public:
    void ReadFile();
    void WriteFile();

    QString m_command;
    int m_filteron;
    float m_sensitivity[3];
    float m_capacity[3];
    float m_extfactor[3];
    float m_offset[3];
    float m_range[3];
    float m_exVolt;
    float m_gFactor;
    float m_voltage;
    float m_ctemp1;
    float m_ctemp2;

    int m_setSample;
    int m_setType;
};


class CProtocolConfig
{
public:
    CProtocolConfig();

    void ReadFile();
    void WriteFile();

    int m_dam;
    int m_ft;
    int m_tcpPeriod;
};


class CAnalysisConfig
{
public:
    CAnalysisConfig();

    void ReadFile();
    void WriteFile();

    int m_tv;
    int m_tp;
    int m_AnalDis;      // for Displacement Use/NotUse (1/0) - 20181013 TrueCat...
    bool m_UseDis;
    QString m_AnalFn0;
    QString m_AnalFn1;
    QString m_AnalFn2;
    QString m_AnalFn3;
};

#endif // SENSORCONFIG_H
