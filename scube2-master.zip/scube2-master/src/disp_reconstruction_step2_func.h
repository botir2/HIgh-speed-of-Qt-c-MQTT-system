/*
 * File: disp_reconstruction_step2_func.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 22-Feb-2018 15:59:29
 */

#ifndef __DISP_RECONSTRUCTION_STEP2_FUNC_H__
#define __DISP_RECONSTRUCTION_STEP2_FUNC_H__

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "disp_reconstruction_step2_func_types.h"

/* Function Declarations */
extern void disp_reconstruction_step2_func(const double acceleration_temp[32000],
  const double FIR_filter_dis[169], const double FIR_filter_vel[169], double
  displacement[32000], double velocity[32000]);

#endif

/*
 * File trailer for disp_reconstruction_step2_func.h
 *
 * [EOF]
 */
