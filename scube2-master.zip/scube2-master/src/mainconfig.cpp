﻿#include <QCoreApplication>

#include <QDebug>
#include <QFile>
#include <QTextStream>

#include "IoTSensor.h"
#include "mainconfig.h"

MainConfig::MainConfig()
{
    m_PFIP = "210.105.85.7";
    m_UID = "smartcs";
    m_DN = "1";
    m_DID = "cs001";
    m_SerialPort = "/dev/ttyAMA0";
    m_FileSaveDir = "/home/pi/SCube2/bin";
    m_iFiletype = 1;
    //m_iAutotrans = 1;
    m_iUseCamera = 0;
    m_iSetTimePeriod = 6;
}

// ncube_config.txt 파일을 읽어 해당 변수에 저장
void MainConfig::ReadFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += MAIN_CONFIG_FILE;

    QFile file(confFile);
    if( !file.open(QFile::ReadOnly | QFile::Text) )
    {
        printf("# Read Error: %s \n", MAIN_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);
    QString line, text;
    int idx = 0, num = 0;

    while( !stream.atEnd() )
    {
        line = stream.readLine();
        qDebug() << "main-config " << line;
        idx = line.indexOf("=");
        //text = line.mid(idx+1).trimmed(); // 앞뒤 공백 제거
        text = line.mid(idx+1).simplified(); // 앞뒤 공백 제거 + 문자열 사이 여러개 공백을 하나로 대체

        switch(num)
        {
        case 0:
            m_PFIP = text;
            break;
        case 1:
            m_UID = text;
            break;
        case 2:
            m_DN = text;
            break;
        case 3:
            m_DID = text;
            break;
        case 4:
            m_SerialPort = text;
            break;
        case 5:
            m_FileSaveDir = text;
            break;
        case 6:
            m_iFiletype = text.toInt();
            break;
#ifdef XX
        case 7:
            m_iAutotrans = text.toInt();
            break;
#endif
        case 7:
            m_iUseCamera = text.toInt();
            break;
        case 8:
            m_iSetTimePeriod = text.toInt();
            break;
        }
        num++;
    }

    file.close();
    printf("Read %s \n", MAIN_CONFIG_FILE);
}

// main_config.txt 파일에 설정값들 쓰기
void MainConfig::WriteFile()
{
    QString confFile = QCoreApplication::applicationDirPath();
    confFile += "/";
    confFile += CONFIG_DIR;
    confFile += "/";
    confFile += MAIN_CONFIG_FILE;

    QFile file(confFile);
    if( !file.open(QFile::WriteOnly) )
    {
        printf("# Write Error: Cannot open %s \n", MAIN_CONFIG_FILE);
        return;
    }

    QTextStream stream(&file);

    stream << "PF-IP = " << m_PFIP << endl;
    stream << "U-ID = " << m_UID << endl;
    stream << "D-N = " << m_DN << endl;
    stream << "D-ID = " << m_DID << endl;
    stream << "SerialPort = " << m_SerialPort << endl;
    stream << "FileSaveDirectory = " << m_FileSaveDir << endl;
    stream << "Filetype = " << m_iFiletype << endl;
    stream << "UseCamera = " << m_iUseCamera << endl;
    stream << "SetTimePeriod = " << m_iSetTimePeriod << endl;

    file.close();
    printf("Write %s \n", MAIN_CONFIG_FILE);
}
