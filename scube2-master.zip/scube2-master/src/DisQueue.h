﻿#ifndef DISQUEUE_H
#define DISQUEUE_H

#include <QList>
#include <QVector>

class CDisQueue
{
public:
    CDisQueue();

    void setSize(int size);
    int getSize();

    void enQueue(const QVector<double> &DisVec);
    QVector<double> deQueue();

    ////QString getQueue();

private:
    int     m_queueSize;

    QList<QVector<double> >  m_Veclist;
};

#endif // DISQUEUE_H
