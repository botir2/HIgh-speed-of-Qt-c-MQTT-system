﻿#include <QCoreApplication>
#include <QProcess>

#include "camerathread.h"
#include "maintask.h"

CCameraThread::CCameraThread(QObject *parent) :
    QObject(parent)
{
    m_pMainTask = NULL;
    m_bThreadRun = false;
}

void CCameraThread::run()
{
    if (m_pMainTask == NULL)
        return;

    QString saveFileName = m_FileDT + ".jpg";

    if (m_bThreadRun)
    {
        //QThread::usleep(1000);

        QProcess * proc;
        proc = new QProcess();

        connect(proc, SIGNAL(finished(int, QProcess:ExitStatus)), this, SLOT(done()));

        QString exePath = "fswebcam";
        QStringList arg;
        arg << "-r" << "640x480" << saveFileName;
        proc->start(exePath, arg);

        if (!proc->waitForStarted())
            qDebug() << "Error Thread";
        else
            proc->moveToThread(QCoreApplication::instance()->thread());

        qDebug() << exePath << arg;
        printf("Created jpeg image by camera !!!\n\r");

        /*****
        msleep(200);

        if (proc != NULL)
        {
            if (proc->isOpen())
            {
                proc->close();
            }
            proc->deleteLater();
        }
        *****/
        m_bThreadRun = false;
    }
}

void CCameraThread::done()
{
    qDebug() << "CameraThread done";
}
