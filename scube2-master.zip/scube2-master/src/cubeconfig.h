﻿#ifndef CUBECONFIG_H
#define CUBECONFIG_H

#include <QString>

#include "IoTSensor.h"

// ncube_config.txt 파일을 읽어 각 상태를 설정함.
// 객체생성없이 전역적으로 사용하기 위해서 static 변수와 함수 사용


class CCubeConfig
{
public:
    CCubeConfig();

public:
    void ReadFile();

    QString  m_tasIP;        // TAS ip
    QString  m_tcpCtnAnal; // tcp 로 전송할 컨테이너 이름
    QString  m_tcpCtnRawe; // tcp 로 전송할 컨테이너 이름
    QString  m_tcpCtnCtrl;      // 센서컨트롤을 위한 control subscibe
    QString  m_tcpCtnCnfg;  // response sensor status
    QString  m_mqttServer;   // mqtt server ip
    QString  m_mqttId;       // mqtt id
    QString  m_mqttTopic;    // mqtt 전송을 위한 토픽(topic)
    QString  m_respTopic;    // 센서상태를 mqtt로 전송하기 위한 토픽(topic)
    QString  m_eventTopic;   // 이벤트 발생시 센서의 raw 데이터를 mqtt로 전송하기 위한 토픽(topic)
    QString  m_disTopic;   // 변위 데이터를 mqtt로 전송하기 위한 토픽(topic) - 20181013 TrueCat...
};

#endif // CUBECONFIG_H
