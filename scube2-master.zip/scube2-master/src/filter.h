/*
 * File: filter.h
 *
 * MATLAB Coder version            : 2.6
 * C/C++ source code generated on  : 22-Feb-2018 15:59:29
 */

#ifndef __FILTER_H__
#define __FILTER_H__

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "disp_reconstruction_step2_func_types.h"

/* Function Declarations */
extern void filter(const double b[169], const double x[32000], double y[32000]);

#endif

/*
 * File trailer for filter.h
 *
 * [EOF]
 */
