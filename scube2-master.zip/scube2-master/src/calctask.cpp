#include <math.h>

#include "IoTSensor.h"
#include "maintask.h"

#include "calctask.h"

CalcTask::CalcTask(QObject *parent) :
    QObject(parent)
{
}

void CalcTask::runProc(void)
{
    CALCVECT qData;

    AttachAnalysisFuncPtr();

    while (1)
    {
        QThread::usleep(1000);
        qData.iType = 0;

        m_pMain->m_CalcMutex.lock();   ////

        if (m_pMain->m_CalcDatas.size() > 0)
        {
            qData = m_pMain->m_CalcDatas.first();
        }

        m_pMain->m_CalcMutex.unlock(); ////

        if (qData.iType == 1)
        {
            MakeStatistics(qData);

            m_pMain->m_CalcMutex.lock();   ////
            m_pMain->m_CalcDatas.removeFirst();
#ifdef DBGPRINT
            printf("<<< nCalcDatas = (%d: %d) %d\n", qData.iType, qData.rawVect.size(), m_pMain->m_CalcDatas.size());
#endif
            m_pMain->m_CalcMutex.unlock(); ////
            qData.rawVect.clear();
        }

#ifdef KT_IOTMAKERS
        m_pMain->m_KtCalcMutex.lock();   ////

        if (m_pMain->m_KtCalcDatas.size() > 0)
        {
            qData = m_pMain->m_KtCalcDatas.first();
        }

        m_pMain->m_KtCalcMutex.unlock(); ////

        if (qData.iType == 2)
        {
            MakeStatistics(qData);

            m_pMain->m_KtCalcMutex.lock();   ////
            m_pMain->m_KtCalcDatas.removeFirst();
#ifdef DBGPRINT
            printf("<<< nCalcDatas = (%d: %d) %d\n", qData.iType, qData.rawVect.size(), m_pMain->m_CalcDatas.size());
#endif
            m_pMain->m_KtCalcMutex.unlock(); ////
            qData.rawVect.clear();
        }

        m_pMain->m_Kt10MinCalcMutex.lock();   ////

        if (m_pMain->m_Kt10MinCalcDatas.size() > 0)
        {
            qData = m_pMain->m_Kt10MinCalcDatas.first();
        }

        m_pMain->m_Kt10MinCalcMutex.unlock(); ////

        if (qData.iType == 3)
        {
            MakeStatistics(qData);

            m_pMain->m_Kt10MinCalcMutex.lock();   ////
            m_pMain->m_Kt10MinCalcDatas.removeFirst();
#ifdef DBGPRINT
            printf("<<< nCalcDatas = (%d: %d) %d\n", qData.iType, qData.rawVect.size(), m_pMain->m_CalcDatas.size());
#endif
            m_pMain->m_Kt10MinCalcMutex.unlock(); ////
            qData.rawVect.clear();
        }
#endif
    }
}

void CalcTask::AttachAnalysisFuncPtr()
{
    m_AnalMap.insert("P2P", &CalcTask::Analysis_P2P);
    m_AnalMap.insert("RMS", &CalcTask::Analysis_Rms);
    m_AnalMap.insert("MIN", &CalcTask::Analysis_Min);
    m_AnalMap.insert("MAX", &CalcTask::Analysis_Max);
    m_AnalMap.insert("AVG", &CalcTask::Analysis_Avg);
    m_AnalMap.insert("STD", &CalcTask::Analysis_Std);
    printf("AnalFn - P2P : %x\n", &CalcTask::Analysis_P2P);
    printf("AnalFn - RMS : %x\n", &CalcTask::Analysis_Rms);
    printf("AnalFn - MIN : %x\n", &CalcTask::Analysis_Min);
    printf("AnalFn - MAX : %x\n", &CalcTask::Analysis_Max);
    printf("AnalFn - AVG : %x\n", &CalcTask::Analysis_Avg);
    printf("AnalFn - STD : %x\n", &CalcTask::Analysis_Std);

    QMap<QString, pfn_analysis>::iterator iter = m_AnalMap.find(m_pMain->m_AnalysisConfig.m_AnalFn0);
    if (iter != m_AnalMap.end())
    {
        m_AnalFn0 = iter.value();    // iter->second
        printf("AnalFn0 : %x, ", m_AnalFn0);
    }

    iter = m_AnalMap.find(m_pMain->m_AnalysisConfig.m_AnalFn1);
    if (iter != m_AnalMap.end())
    {
        m_AnalFn1 = iter.value();    // iter->second
        printf("AnalFn1 : %x\n", m_AnalFn1);
    }

    iter = m_AnalMap.find(m_pMain->m_AnalysisConfig.m_AnalFn2);
    if (iter != m_AnalMap.end())
    {
        m_AnalFn2 = iter.value();    // iter->second
        printf("AnalFn2 : %x\n", m_AnalFn2);
    }

    iter = m_AnalMap.find(m_pMain->m_AnalysisConfig.m_AnalFn3);
    if (iter != m_AnalMap.end())
    {
        m_AnalFn3 = iter.value();    // iter->second
        printf("AnalFn3 : %x\n", m_AnalFn3);
    }
}

float CalcTask::Analysis_Min(QVector<float> rawVect)
{
    //printf("Make MIN\r\n");
    float min = *std::min_element(rawVect.constBegin(), rawVect.constEnd());

    return min;
}

float CalcTask::Analysis_Max(QVector<float> rawVect)
{
    //printf("Make MAX\r\n");
    float max = *std::max_element(rawVect.constBegin(), rawVect.constEnd());

    return max;
}

float CalcTask::Analysis_Avg(QVector<float> rawVect)
{
    //printf("Make AVG\r\n");
    double avg = 0.0f, sum = 0.0f;
    int cnt = rawVect.size();

#ifdef PRINTDBG
    printf(">>> AVG --> ")
#endif
    for (int i = 0; i < cnt; i++)
    {
        sum += rawVect.at(i);
#ifdef PRINTDBG
        printf("%.5f,", rawVect.at(i));
#endif
    }
#ifdef PRINTDBG
    printf("\n");
#endif
    avg = sum / (double)cnt;

#ifdef PRINTDBG
    printf(">>> AVG --> Count : %d, AVG : %.5f", cnt, avg);
#endif
    return (float)avg;
}

float CalcTask::Analysis_Std(QVector<float> rawVect)
{
    //printf("Make STD\r\n");
    double avg = 0.0f, sum = 0.0f, variance = 0.0f;
    float stdVal;
    int cnt = rawVect.size();

    if (cnt < 2)
    {
        printf(">>> STD Not available !!! - size : %d\n", cnt);
        return sqrt(-1.0);
    }

    avg = (double)Analysis_Avg(rawVect);
#ifdef PRINTDBG
    printf(">>> STD --> ")
#endif
    for (int i = 0; i < cnt; i++)
    {
        sum += pow(rawVect.at(i)-avg, 2);
#ifdef PRINTDBG
        printf("%.5f,", rawVect.at(i));
#endif
    }
#ifdef PRINTDBG
    printf("\n");
#endif

    variance = sum / (double)cnt;
    stdVal = sqrt(variance);
#ifdef PRINTDBG
    printf(">>> STD --> Count : %d, AVG : %.5f, VAR : %.5f, STD : %.5f", cnt, avg, variance, stdVal);
#endif

    return stdVal;
}

float CalcTask::Analysis_P2P(QVector<float> rawVect)
{
    //printf("Make P-P\r\n");
    float minVal = *std::min_element(rawVect.constBegin(), rawVect.constEnd());
    float maxVal = *std::max_element(rawVect.constBegin(), rawVect.constEnd());
    float p2p = maxVal - minVal;

    return p2p;
}

float CalcTask::Analysis_Rms(QVector<float> rawVect)
{
    //printf("Make RMS\r\n");
    float rms = 0.0f;
    foreach (float f, rawVect)
    {
        rms += (f * f);
    }
    rms = sqrt( (rms / (float)rawVect.size()) );
    return rms;

    //float rms = std::inner_product(m_rawVect.constBegin(), m_rawVect.constEnd(), m_rawVect.constBegin(), 0);
    //rms = sqrt( (rms / (float)m_rawVect.size()) );

    //return rms;
}

void CalcTask::MakeStatistics(CALCVECT qData)
{
    QString packet;
    QString text;

#ifdef KT_IOTMAKERS
    QString dt;
    dt.sprintf("%04d-%02d-%02d %02d:%02d:%02d.%03d\"",
        qData.iYear, qData.iMonth, qData.iDay, qData.iHour, qData.iMinute, qData.iSec, qData.iMilSec);
#endif

    if (qData.iType == 1)
    {
        if (m_pMain->m_ProtocolConfig.m_dam == 1 || m_pMain->m_ProtocolConfig.m_dam == 4 || m_pMain->m_ProtocolConfig.m_dam == 5 || m_pMain->m_ProtocolConfig.m_dam == 7)
            return;

        m_AnalValue0[qData.iCh] = (this->*m_AnalFn0)(qData.rawVect);
        m_AnalValue1[qData.iCh] = (this->*m_AnalFn1)(qData.rawVect);
        m_AnalValue2[qData.iCh] = (this->*m_AnalFn2)(qData.rawVect);
        m_AnalValue3[qData.iCh] = (this->*m_AnalFn3)(qData.rawVect);

        // Date/Time
        packet.sprintf("%4d%02d%02d %02d%02d%02d.%03d,", qData.iYear, qData.iMonth, qData.iDay,
                       qData.iHour, qData.iMinute, qData.iSec, qData.iMilSec);

        // Channel
        if (m_pMain->m_CHnum > 1)
        {
            text.sprintf("%1d,", qData.iCh); // Watch...there is ',' at the end of value
            packet += text;
        }

        // P-P
        text.sprintf("%.5f,", m_AnalValue0[qData.iCh]); // Watch...there is ',' at the end of value
        packet += text;

        // RMS
        text.sprintf("%.5f,", m_AnalValue1[qData.iCh]); // Watch...there is ',' at the end of value
        packet += text;

        // Event
        text = qData.bEvent ? "1," : "0,";
        packet += text;

        // Location
        text.sprintf("%04d.%04d,%c,%04d.%04d,%c,", qData.daqGPS.iLat1, qData.daqGPS.iLat2, qData.daqGPS.bisNorth ? 'N' : 'S',
                     qData.daqGPS.iLon1, qData.daqGPS.iLon2, qData.daqGPS.bisEest ? 'E' : 'W');
        packet += text;

        // 온도
        text.sprintf("%.2f,", qData.daqStatus.fTemp);
        packet += text;

        // 습도
        text.sprintf("%.2f,", qData.daqStatus.fHumi);
        packet += text;

        // D-inf
        text = "000";
        packet += text;

        nCUBEDATA qData;
        qData.iType = 1;    // Anal Data
        qData.strContents = packet;

        m_pMain->m_nCubeMutex.lock();    ////
        m_pMain->m_nCubeDatas.append(qData);
        //printf(">>> nCubeDatas = (%d: %d) %d\n", qData.iType, qData.strContents.size(), m_pMain->m_nCubeDatas.size());
        m_pMain->m_nCubeMutex.unlock();  ////
    }
#ifdef KT_IOTMAKERS
    else if (qData.iType == 2)  // KT IotMakers Normal Period Stat.
    {
        if (m_pMain->m_ProtocolConfig.m_dam == 1 || m_pMain->m_ProtocolConfig.m_dam == 2 || m_pMain->m_ProtocolConfig.m_dam == 3 || m_pMain->m_ProtocolConfig.m_dam == 7)
            return;

        float minValue = Analysis_Min(qData.rawVect);
        float maxValue = Analysis_Max(qData.rawVect);

        if (m_pMain->m_isConnectedKTIoTM)
        {
            printf("<<< KT MinMax Send : [%d]-%d %s - %.5f, %.5f\n", qData.iCh, qData.rawVect.size(), dt.toStdString().c_str(), minValue, maxValue);
            m_pMain->m_IoTM.SendMinMax(qData.iCh, minValue, maxValue, dt);
        }
    }
    else if (qData.iType == 3)  // KT IotMakers 10Mins Period Stat.
    {
        if (m_pMain->m_ProtocolConfig.m_dam == 1 || m_pMain->m_ProtocolConfig.m_dam == 2 || m_pMain->m_ProtocolConfig.m_dam == 3 || m_pMain->m_ProtocolConfig.m_dam == 7)
            return;

        float minValue = Analysis_Min(qData.rawVect);
        float maxValue = Analysis_Max(qData.rawVect);
        float avgValue = Analysis_Avg(qData.rawVect);
        float stdValue = Analysis_Std(qData.rawVect);

        if (m_pMain->m_isConnectedKTIoTM)
        {
            printf("<<< KT 10Mins Statistics Send : [%d]-%d, %s - %.5f, %.5f, %.5f, %.5f\n", qData.iCh, qData.rawVect.size(), dt.toStdString().c_str(), minValue, maxValue, avgValue, stdValue);
            m_pMain->m_IoTM.Send10minStat(qData.iCh, minValue, maxValue, avgValue, stdValue, dt);
        }
    }
#endif
}
