﻿#include <QFile>

#include "converter.h"
#include "sensorconfig.h"


CConverter::CConverter()
{
    m_funcIdx = 0;

    m_sensitivity[0] = m_sensitivity[1] = m_sensitivity[2] = 174.0f;
    m_capacity[0] = m_capacity[1] = m_capacity[2] = 1.0f;
    m_extFactor[0] = m_extFactor[1] = m_extFactor[2] = 2.0f;
    m_offset[0] = m_offset[1] = m_offset[2] = 0.0f;
    m_range[0] = m_range[1] = m_range[2] = 2.0f;

    m_voltage = 3300.0f;
    ////m_ctemp1 = 0.0f;
    ////m_ctemp2 = 0.0f;
}

// 센서타입(계측항목) 설정, 변환함수와 맵핑
void CConverter::SetSensorType(char sensorType)
{
    switch(sensorType)
    {
    case '0':   // acc_y
    case '1':   // acc_x
    case '2':   // acc_z
    case '3':   // acc_all
        m_funcIdx = 0;
        break;
    case '4':   // strain
        m_funcIdx = 1;
        break;
    case '5': // displacement
        m_funcIdx = 2;
        break;
    case '6': // LOADCELL
        m_funcIdx = 3;
        break;
    case '7': // TILT
        m_funcIdx = 1;
        break;
    case '10': // WIND
        m_funcIdx = 10;
        break;
    default:
        m_funcIdx = 0;
        break;
    }
}

// accel(가속도) 데이터로 변환
float CConverter::ToAccel(int ch, int adcData)
{
#ifdef DBGPRINT
    printf("ToAccel - %d\r\n", adcData);
#endif
    float result = (((float)adcData*(m_voltage/65535.0f)-(m_voltage/2.0f)) / m_sensitivity[ch]) - m_offset[ch];
    return result;
}

// strain (인장=늘어난 정도) 데이터로 변환
float CConverter::ToStrain(int ch, int adcData)
{
    float result = ((((float)adcData*(m_voltage/65535.0f)-(m_voltage/2)))/(100*m_extFactor[ch])) / ((m_exVolt/4)*m_gFactor)*1000000.0f - m_offset[ch];
    return result;
}

// displacement (변위) 데이터로 변환
float CConverter::ToDisplacement(int ch, int adcData)
{
    float result = ((((float)adcData*(m_voltage/65535.0f)-(m_voltage/2)))/(100*m_extFactor[ch])) / (((m_exVolt/1000.0f)*m_sensitivity[ch])/m_capacity[ch]) - m_offset[ch];
    return result;
}

// converting to Wind data
float CConverter::ToWind(int ch, int adcData)
{
    float result = (((float)adcData*(m_voltage/65535.0f)) / m_sensitivity[ch]) - m_offset[ch];
    return result;
}

// ADC 데이터를 센서타입(계측항목)에 맞게 변환하여 리턴
float CConverter::SensorData(int ch, int adcData)
{
    float val;

    switch (m_funcIdx)
    {
    case 0:
    case 1:
    case 2:
    case 3:
        val = ToAccel(ch, adcData);
        break;
    case 4:
        val = ToStrain(ch, adcData);
        break;
    case 5:
    case 6:
        val = ToDisplacement(ch, adcData);
        break;
    case 10:
        val = ToWind(ch, adcData);
        break;
    default:
        val = 0.0f;
        break;
    }

    return val;
}
