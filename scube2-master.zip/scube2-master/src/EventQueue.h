﻿#ifndef EVENTQUEUE_H
#define EVENTQUEUE_H

#include <QList>
#include <QVector>

class CEventQueue
{
public:
    CEventQueue();

    void setSize(int size);
    int getSize();

    void enQueue(const float &value);
    float deQueue();

    QString getQueue();
    QString getQueue(QVector<float> eventVect);

private:
    int     m_queueSize;

    QList<float>    m_flist;
};

#endif // EVENTQUEUE_H
