﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <ctype.h>

#include <ftw.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <string>
#include <sys/stat.h>

#include "cminiseeddata.h"
#include "cparameter.h"
#include "cuartdataproc.h"


CMiniSeedData::CMiniSeedData()
{

}

void CMiniSeedData::clearData()
{
    m_vRawData.clear();
    m_nSequenceNumber=0;

    m_year=0;
    m_mon=0;
    m_mday=0;
    m_hour=0;
    m_min=0;
    m_sec=0;
    m_mSec=0 ;

}
