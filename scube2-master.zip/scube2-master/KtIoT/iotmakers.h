/*
 * GiGA IoT Platform version 2.0
 *
 *  Copyright �� 2015 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_H
#define IOTMAKERS_H

#include "im_common.h"

#define IOTMAKERS_SDK_C_VERSION				"3.0.17"


#define LOG_LEVEL_ERROR   1                    /* Log level  : Error               */
#define LOG_LEVEL_INFO    2                    /* Log level  : Information         */
#define LOG_LEVEL_DEBUG   3                    /* Log level  : Debug               */

/*
typedef void (*IMCbErrorHndl)(int errCode);
typedef void (*IMCBResBodyHndl)(void* pIMPacketBody);
typedef void (*IMCbTagidNumDataHndl)(char *devid, char *tagid, double val);
typedef void (*IMCbTagidStrDataHndl)(char *devid, char *tagid, char *val);
*/

#ifdef __cplusplus
extern "C"
{
#endif

/*
sdk version string 
*/
char* im_version_string();

int im_base_set_aria_key(unsigned char *key_hexstring);

/*
sdk init 
*/
int im_init(char *ip, int port, char *deviceId, char *athnRqtNo, char *extrSysId, char *log_file_name);
int im_init_with_config_file(char *fname);
void im_release() ;

int im_get_LastErrCode();
void im_set_loglevel(int loglevel);

#if  defined (_IM_C_SOCK_) 
void im_set_socktimeout_sec(int sec);
#endif


/*
connection 
*/
int im_connect();
int im_connected();
void im_disconnect();

int im_ssl_set_trusred_ca_path(char *ca_bundlestr);

/*
internally, sends keepalive and receives data from server
*/
int im_loop();
void im_set_error_handler(IMCbErrorHndl cb_proc);


/*
IF200s: auth 
*/
int im_auth_device();
int im_auth_device_ktbi(char* key_file);




/*
IF300s: device mngr 
*/
int im_332_init();
int im_332_set_update_all();
int im_332_put_default(char* devId, char* devName, char* makerCd, char* modelCd, char* ipAddr, char* statCd, char* frmwrVer);
int im_332_send();
int im_332_set_insert();
int im_332_release();
int im_332_set_delete();


/*
IF411: setting handler for response 
*/
int im_411_set_res_body_handler(IMCBResBodyHndl  res_body_handler);
char* im_body411_req_get_respCd(void* pbody);

/*
IF411: advanced APIs
*/
int im_411_init_with_devid(char *devId);
int im_411_init();
int im_411_put_numdata(char *tagid, double val);
int im_411_put_strdata(char *tagid, char *val);
int im_411_append_new_devColecData(char *devId);
int im_411_appned_new_colecRow();
int im_411_send();
int im_411_release();
int im_411_print_body();
int im_411_append_new_colecRow_with_occDt(char *occDateStr);

/*
IF411: sample APIs
*/
int im_send_numdata(char *tagid, double val);
int im_send_strdata(char* tagid, char* val);
int im_send_numdata_with_devid(char *devId, char *tagid, double val);
int im_send_strdata_with_devid(char *devId, char *tagid, char *val);


/*
IF525: setting handler for a control data 
*/
int im_525_set_numdata_handler(IMCbTagidNumDataHndl numdata_handler);
int im_525_set_strdata_handler(IMCbTagidStrDataHndl strdata_handler);
int im_send_report_strdata_with_devid(char *devId, char *tagid, char *val);


#ifdef __cplusplus
}
#endif

#endif
