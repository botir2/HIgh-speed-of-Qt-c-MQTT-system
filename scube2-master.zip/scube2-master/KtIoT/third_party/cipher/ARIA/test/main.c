
#include <stdio.h>

#include "aria.h"

#if 1
static void printfDump (const char* p, int len)
{
	unsigned int    coff, roff;
	unsigned int    off;
	char    szOutput[258] ;
	char    szString[128] ;
	unsigned int    i = 0 ;
	unsigned int    j = 0 ;
	unsigned int    base = 16;

	for (roff = 0; roff < (len + base -1)/base; roff++)
	{
		i = 0 ;
		j = 0 ;
		memset(szOutput, 0x20, sizeof(szOutput)) ;
		memset(szString, 0x20, sizeof(szString)) ;

		sprintf(&szOutput[i],"[%04X] :", roff * base);
		i = i + 8 ;
		for (coff = 0; coff < base; coff++)
		{
			off = roff * base + coff;
			if (off < len)
			{
				if (base <= 10)
					sprintf(&szOutput[i], "%02d  ",(unsigned char)p[off]);
				else
					sprintf(&szOutput[i],"%02X  ", (unsigned char)p[off]);

				if ((unsigned char)p[off] < 0x20)
					szString[j] = (unsigned char)'.' ;
				else
					szString[j] = (unsigned char)p[off] ;

				if ((coff % 4) == 3)
					i = i + 4 ;
				else
					i = i + 3 ;

				j = j + 1 ;
			}
		}

		szOutput[i]     = (unsigned char)0x20 ;
		szOutput[60]    = (unsigned char)'\0' ;
		szString[j]     = (unsigned char)'\0' ;

		printf ("%-60s  %s \n", szOutput, szString) ;
	}
}
#endif

/*

user@u16:~/project/coding/java/Aria$ make run
cd  ./bin
java -version
java version "1.7.0_17"
Java(TM) SE Runtime Environment (build 1.7.0_17-b02)
Java HotSpot(TM) Server VM (build 23.7-b01, mixed mode)
java -classpath "./bin" kr.re.nsri.aria.Hello
BEGIN testing the roundtrip...
For key size of 128 bits, starting with the zero plaintext and the zero key, let's see if we may recover the plaintext by decrypting the encrypted ciphertext.
plaintext : 00000000 00000000 00000000 00000000
ciphertext: 4b40a63c 7f0171ee 3cdda436 3fbfae75
decrypted : 00000000 00000000 00000000 00000000
Okay.  The result is correct.
END   testing the roundtrip.

*/
static int test_basic_pkcs5()
{
    AriaContext ariaContextEnc;
    AriaContext ariaContextDec;

    unsigned char psk_128[32];
    unsigned char plain_text[32];


    char plain[100];
    char cipher[100];

    int i;
    int fail = 0;
    int cipher_len, plain_len;


    memset(psk_128, 0x00, 16);
    memset(plain_text, 0x00, 16);


    ///////////////// Encryption
    if ( aria_set_key128(&ariaContextEnc, psk_128) < 0 )    {
        return -1;
    }    ;

    memset(plain, 0x00, 16);
	printf ("ORG:\n");
    printfDump(plain, 16);

    cipher_len = aria_encrypt_pkcs5(&ariaContextEnc, plain, 16, cipher, sizeof(cipher));

    printf ("ENC:%d\n", cipher_len);
    printfDump(cipher, cipher_len);


    ///////////////// Decryption
    if ( aria_set_key(&ariaContextDec, psk_128) < 0 )    {
        return -1;
    }    ;


    plain_len = aria_decrypt_pkcs5(&ariaContextDec, cipher, cipher_len, plain, sizeof(plain));

	printf ("DEC:%d\n", plain_len);
	printfDump (plain, plain_len);

}

#if 1
/**
ARIA-128 CBC
- Test Vector 1
Key         00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F
IV          01 01 01 01 01 01 01 01 01 01 01 01 01 01 01 01
Plaintext   01 23 45 67 89 AB CD EF 01 23 45 67 89 AB CD EF
Ciphertext
            9C D3 FE 15 0C ED 37 85 56 D8 03 D4 7A 58 AC F7
            13 4F 10 64 6F EA 94 4E DE 42 DB 4F 42 13 6E 01
*/

static int test_cbc_pkcs5_basic()
{
    AriaContext ariaContextEnc;
    AriaContext ariaContextDec;

    unsigned char psk_128[32];
    unsigned char iv[32];
    unsigned char plain_text[32];


    char plain[100];
    char cipher[100];

    int i;
    int fail = 0;
    int cipher_len, plain_len;


    memset(psk_128, 0x00, 16);
    memset(plain_text, 0x00, 16);

    ///////////////// Encryption
    // KISA TEST VECTOR
    memcpy(psk_128, "\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff", 16);
    memcpy(psk_128, "\x00\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\x0C\x0D\x0E\x0F", 16);

    
    printf ("psk_128:\n");
    printfDump(psk_128, 16);

    memcpy(iv, "\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01", 16);
	printf ("iv:\n");
    printfDump(iv, 16);


    if ( aria_set_key128_cbc(&ariaContextEnc, psk_128, iv) < 0 )    {
        return -1;
    }    ;

    // KISA TEST VECTOR
    memcpy(plain, "\x11\x11\x11\x11\xaa\xaa\xaa\xaa\x11\x11\x11\x11\xbb\xbb\xbb\xbb", 16);
    memcpy(plain, "\x01\x23\x45\x67\x89\xAB\xCD\xEF\x01\x23\x45\x67\x89\xAB\xCD\xEF", 16);



	printf ("plain:\n");
    printfDump(plain, 16);

    cipher_len = aria_encrypt_cbc_pkcs5(&ariaContextEnc, plain, 16, cipher, sizeof(cipher));

    printf ("ENC:%d\n", cipher_len);
    printfDump(cipher, cipher_len);


    ///////////////// Decryption
    if ( aria_set_key128_cbc(&ariaContextDec, psk_128, iv) < 0 )    {
        return -1;
    }    ;


    plain_len = aria_decrypt_cbc_pkcs5(&ariaContextDec, cipher, cipher_len, plain, sizeof(plain));

	printf ("DEC:%d\n", plain_len);
	printfDump (plain, plain_len);

}


static int test_cbc_pkcs5_testvector()
{
    AriaContext ariaContextEnc;
    AriaContext ariaContextDec;

    unsigned char psk_128[32];
    unsigned char iv[32];

    unsigned char plain_text[32];


    char plain[1000];
    char cipher[1000];

    int i;
    int fail = 0;
    int cipher_len, plain_len;


    memset(psk_128, 0x00, 16);
    memset(plain_text, 0x00, 16);

    ///////////////// Encryption
    // KISA TEST VECTOR
    memcpy(psk_128, "\x00\x11\x22\x33\x44\x55\x66\x77\x88\x99\xaa\xbb\xcc\xdd\xee\xff", 16);
	printf ("psk_128:\n");
    printfDump(psk_128, 16);

    memcpy(iv, "\x0f\x1e\x2d\x3c\x4b\x5a\x69\x78\x87\x96\xa5\xb4\xc3\xd2\xe1\xf0", 16);
	printf ("iv:\n");
    printfDump(iv, 16);


    if ( aria_set_key128_cbc(&ariaContextEnc, psk_128, iv) < 0 )    {
        return -1;
    }    ;

    // KISA TEST VECTOR
    i = 0;
    memcpy(plain+(i++*16), "\x11\x11\x11\x11\xaa\xaa\xaa\xaa\x11\x11\x11\x11\xbb\xbb\xbb\xbb", 16);
    memcpy(plain+(i++*16), "\x11\x11\x11\x11\xcc\xcc\xcc\xcc\x11\x11\x11\x11\xdd\xdd\xdd\xdd", 16);
    memcpy(plain+(i++*16), "\x22\x22\x22\x22\xaa\xaa\xaa\xaa\x22\x22\x22\x22\xbb\xbb\xbb\xbb", 16);
    memcpy(plain+(i++*16), "\x22\x22\x22\x22\xcc\xcc\xcc\xcc\x22\x22\x22\x22\xdd\xdd\xdd\xdd", 16);
    memcpy(plain+(i++*16), "\x33\x33\x33\x33\xaa\xaa\xaa\xaa\x33\x33\x33\x33\xbb\xbb\xbb\xbb", 16);
    memcpy(plain+(i++*16), "\x33\x33\x33\x33\xcc\xcc\xcc\xcc\x33\x33\x33\x33\xdd\xdd\xdd\xdd", 16);
    memcpy(plain+(i++*16), "\x44\x44\x44\x44\xaa\xaa\xaa\xaa\x44\x44\x44\x44\xbb\xbb\xbb\xbb", 16);
    memcpy(plain+(i++*16), "\x44\x44\x44\x44\xcc\xcc\xcc\xcc\x44\x44\x44\x44\xdd\xdd\xdd\xdd", 16);
    memcpy(plain+(i++*16), "\x55\x55\x55\x55\xaa\xaa\xaa\xaa\x55\x55\x55\x55\xbb\xbb\xbb\xbb", 16);
    memcpy(plain+(i++*16), "\x55\x55\x55\x55\xcc\xcc\xcc\xcc\x55\x55\x55\x55\xdd\xdd\xdd\xdd", 16);



    printf ("plain:\n");
    printfDump(plain, 16*10);

    cipher_len = aria_encrypt_cbc_pkcs5(&ariaContextEnc, plain, 16*10, cipher, sizeof(cipher));

    printf ("ENC:%d\n", cipher_len);
    printfDump(cipher, cipher_len);


    ///////////////// Decryption
    if ( aria_set_key128_cbc(&ariaContextDec, psk_128, iv) < 0 )    {
        return -1;
    }    ;


    plain_len = aria_decrypt_cbc_pkcs5(&ariaContextDec, cipher, cipher_len, plain, sizeof(plain));

	printf ("DEC:%d\n", plain_len);
	printfDump (plain, plain_len);

}



static void test_basic_testvector()
{
    AriaContext ariaContextEnc;
    AriaContext ariaContextDec;


  unsigned char plain[16]={0x11, 0x11, 0x11, 0x11, 0xaa, 0xaa, 0xaa, 0xaa, 0x11, 0x11, 0x11, 0x11, 0xbb, 0xbb, 0xbb, 0xbb};
  unsigned char psk_128[16]={0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF};
  const unsigned char cryptResult[] = {0xc6, 0xec, 0xd ,0x8e, 0x22, 0xc3, 0x0a, 0xbd, 0xb2, 0x15, 0xcf, 0x74, 0xe2, 0x07, 0x5e, 0x6e}; 

    char cipher[1000];

    int i;
    int fail = 0;
    int cipher_len, plain_len;


    ///////////////// Encryption
    // KISA TEST VECTOR
	printf ("psk_128:\n");
    printfDump(psk_128, 16);

    if ( aria_set_key128(&ariaContextEnc, psk_128) < 0 )    {
        return -1;
    }    ;

    printf ("plain:\n");
    printfDump(plain, 16);

    cipher_len = aria_encrypt_pkcs5(&ariaContextEnc, plain, sizeof(plain), cipher, sizeof(cipher));

	printf ("cipher:\n");
    printfDump(cipher, cipher_len);

	printf ("should be:\n");
    printfDump(cryptResult, 16);

}


static void test_basic_testvector_cbc()
{
    AriaContext ariaContextEnc;
    AriaContext ariaContextDec;

  unsigned char psk_128[16]={0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF};
  unsigned char iv[16]={0x0f, 0x1e, 0x2d, 0x3c, 0x4b, 0x5a, 0x69, 0x78, 0x87, 0x96, 0xa5, 0xb4, 0xc3, 0xd2, 0xe1, 0xf0};

  unsigned char plain[16*10]={0x11, 0x11, 0x11, 0x11, 0xaa, 0xaa, 0xaa, 0xaa, 0x11, 0x11, 0x11, 0x11, 0xbb, 0xbb, 0xbb, 0xbb,
                            0x11, 0x11, 0x11, 0x11, 0xcc, 0xcc, 0xcc, 0xcc, 0x11, 0x11, 0x11, 0x11, 0xdd, 0xdd, 0xdd, 0xdd,
                            0x22, 0x22, 0x22, 0x22, 0xaa, 0xaa, 0xaa, 0xaa, 0x22, 0x22, 0x22, 0x22, 0xbb, 0xbb, 0xbb, 0xbb,
                            0x22, 0x22, 0x22, 0x22, 0xcc, 0xcc, 0xcc, 0xcc, 0x22, 0x22, 0x22, 0x22, 0xdd, 0xdd, 0xdd, 0xdd,
                            0x33, 0x33, 0x33, 0x33, 0xaa, 0xaa, 0xaa, 0xaa, 0x33, 0x33, 0x33, 0x33, 0xbb, 0xbb, 0xbb, 0xbb,
                            0x33, 0x33, 0x33, 0x33, 0xcc, 0xcc, 0xcc, 0xcc, 0x33, 0x33, 0x33, 0x33, 0xdd, 0xdd, 0xdd, 0xdd,
                            0x44, 0x44, 0x44, 0x44, 0xaa, 0xaa, 0xaa, 0xaa, 0x44, 0x44, 0x44, 0x44, 0xbb, 0xbb, 0xbb, 0xbb,
                            0x44, 0x44, 0x44, 0x44, 0xcc, 0xcc, 0xcc, 0xcc, 0x44, 0x44, 0x44, 0x44, 0xdd, 0xdd, 0xdd, 0xdd,
                            0x55, 0x55, 0x55, 0x55, 0xaa, 0xaa, 0xaa, 0xaa, 0x55, 0x55, 0x55, 0x55, 0xbb, 0xbb, 0xbb, 0xbb,
                            0x55, 0x55, 0x55, 0x55, 0xcc, 0xcc, 0xcc, 0xcc, 0x55, 0x55, 0x55, 0x55, 0xdd, 0xdd, 0xdd, 0xdd};


  const unsigned char cryptResult[] = {0x49, 0xD6, 0x18, 0x60, 0xB1, 0x49, 0x09, 0x10, 0x9C, 0xEF, 0x0D, 0x22, 0xA9, 0x26, 0x81, 0x34,
                                    0xFA, 0xDF, 0x9F, 0xB2, 0x31, 0x51, 0xE9, 0x64, 0x5F, 0xBA, 0x75, 0x01, 0x8B, 0xDB, 0x15, 0x38,
                                    0xB5, 0x33, 0x34, 0x63, 0x4B, 0xBF, 0x7D, 0x4C, 0xD4, 0xB5, 0x37, 0x70, 0x33, 0x06, 0x0C, 0x15,
                                    0x5F, 0xE3, 0x94, 0x8C, 0xA7, 0x5D, 0xE1, 0x03, 0x1E, 0x1D, 0x85, 0x61, 0x9E, 0x0A, 0xD6, 0x1E,
                                    0xB4, 0x19, 0xA8, 0x66, 0xB3, 0xC2, 0xDB, 0xFD, 0x10, 0xA4, 0xED, 0x18, 0xB2, 0x21, 0x49, 0xF7,
                                    0x58, 0x97, 0xF0, 0xB8, 0x66, 0x8B, 0x0C, 0x1C, 0x54, 0x2C, 0x68, 0x77, 0x78, 0x83, 0x5F, 0xB7,
                                    0xCD, 0x46, 0xE4, 0x5F, 0x85, 0xEA, 0xA7, 0x07, 0x24, 0x37, 0xDD, 0x9F, 0xA6, 0x79, 0x3D, 0x6F,
                                    0x8D, 0x4C, 0xCE, 0xFC, 0x4E, 0xB1, 0xAC, 0x64, 0x1A, 0xC1, 0xBD, 0x30, 0xB1, 0x8C, 0x6D, 0x64,
                                    0xC4, 0x9B, 0xCA, 0x13, 0x7E, 0xB2, 0x1C, 0x2E, 0x04, 0xDA, 0x62, 0x71, 0x2C, 0xA2, 0xB4, 0xF5,
                                    0x40, 0xC5, 0x71, 0x12, 0xC3, 0x87, 0x91, 0x85, 0x2C, 0xFA, 0xC7, 0xA5, 0xD1, 0x9E, 0xD8, 0x3A}; 


    char cipher[1000];

    int i;
    int fail = 0;
    int cipher_len, plain_len;


    ///////////////// Encryption
    // KISA TEST VECTOR
	printf ("psk_128:\n");
    printfDump(psk_128, 16);
	
    printf ("iv:\n");
    printfDump(iv, 16);

    if ( aria_set_key128_cbc(&ariaContextEnc, psk_128, iv) < 0 )    {
        return -1;
    }    ;

    printf ("plain:\n");
    printfDump(plain, 16*10);

    cipher_len = aria_encrypt_cbc_pkcs5(&ariaContextEnc, plain, sizeof(plain), cipher, sizeof(cipher));

	printf ("cipher:\n");
    printfDump(cipher, cipher_len);

	printf ("should be:\n");
    printfDump(cryptResult, 16*10);

}


#endif

int main()
{
#if 0

puts("\n test_basic_pkcs5 \n");
    AriaCore_Crypt_main();
    test_basic_pkcs5();
puts("\n\n");


puts("\n test_cbc_pkcs5_basic \n");
    test_cbc_pkcs5_basic();

puts("\n\n");

puts("\n test_cbc_pkcs5_testvector \n");
    test_cbc_pkcs5_testvector();


#endif


puts("\n test_basic_testvector \n");
test_basic_testvector();

puts("\n test_basic_testvector_cbc \n");
test_basic_testvector_cbc();
   
    return 0;
}

