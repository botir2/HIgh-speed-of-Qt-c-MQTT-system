#include <stdio.h>
#include <string.h>

#include "AES/aes.h"


static void printfDump (const char* p, int len)
{
	unsigned int    coff, roff;
	unsigned int    off;
	char    szOutput[258] ;
	char    szString[128] ;
	unsigned int    i = 0 ;
	unsigned int    j = 0 ;
	unsigned int    base = 16;

	for (roff = 0; roff < (len + base -1)/base; roff++)
	{
		i = 0 ;
		j = 0 ;
		memset(szOutput, 0x20, sizeof(szOutput)) ;
		memset(szString, 0x20, sizeof(szString)) ;

		sprintf(&szOutput[i],"[%04X] :", roff * base);
		i = i + 8 ;
		for (coff = 0; coff < base; coff++)
		{
			off = roff * base + coff;
			if (off < len)
			{
				if (base <= 10)
					sprintf(&szOutput[i], "%02d  ",(unsigned char)p[off]);
				else
					sprintf(&szOutput[i],"%02X  ", (unsigned char)p[off]);

				if ((unsigned char)p[off] < 0x20)
					szString[j] = (unsigned char)'.' ;
				else
					szString[j] = (unsigned char)p[off] ;

				if ((coff % 4) == 3)
					i = i + 4 ;
				else
					i = i + 3 ;

				j = j + 1 ;
			}
		}

		szOutput[i]     = (unsigned char)0x20 ;
		szOutput[60]    = (unsigned char)'\0' ;
		szString[j]     = (unsigned char)'\0' ;

		printf ("%-60s  %s \n", szOutput, szString) ;
	}
}


static int ecb_test()
{
	char key[20];
	char plain[100];
	char cipher[100];
	int len;

	struct aes_context aes_encrypt_ctx;
	struct aes_context aes_decrypt_ctx;

	memset (key, 0x00, sizeof(key));
	memset (plain, 0x00, sizeof(plain));
	memset (cipher, 0x00, sizeof(cipher));

	strcpy (key, "1234567890123456");
	strcpy (plain, "12345678901234567");

	len = strlen(plain);

	printf ("ORG:%s\n", plain);

	aes_set_key(&aes_encrypt_ctx, (unsigned char*)key, 128);
	len = aes_encrypt_ecb_pkcs5 (&aes_encrypt_ctx, (unsigned char*)plain, len, (unsigned char*)cipher, len+16);

	printf ("ENC:%d\n", len);
	printfDump (cipher, len);


	memset (plain, 0x00, sizeof(plain));

	aes_set_key(&aes_decrypt_ctx, (unsigned char*)key, 128);
	len = aes_decrypt_ecb_pkcs5 (&aes_decrypt_ctx, (unsigned char*)cipher, len, (unsigned char*)plain, len);
	printf ("DEC:%d:%s\n", len, plain);
	printfDump (plain, len);

	return 0;
}

static int cbc_128bits_test()
{
    unsigned char *psk_128 = "1234567890123456";
    unsigned char *plain_text = "12345678";
	char iv[20];
	char plain[100];
	char cipher[100];

	struct aes_cbc_context aes_cbc_encrypt_ctx;
	struct aes_cbc_context aes_cbc_decrypt_ctx;

	int cipher_len;
	int plain_len;

#if 0
    plain_text = "{\"extrSysId\":\"ENC_TCP_TEST\",\"devId\":\"ENC_TEST_DEV\",\"athnRqtNo\":\"ENC_TEST_DEV\"}";
#endif


    memset (cipher, 0x00, sizeof(cipher));
	strcpy (plain, plain_text);
	printf ("ORG:%s\n", plain);

    /**
    128bits 암호화
    */
    // IV in 16 bytes long
	memcpy (iv, psk_128, 16);

	aes_set_key_cbc(&aes_cbc_encrypt_ctx, psk_128, (unsigned char*)iv);
	cipher_len = aes_encrypt_cbc_pkcs5 (&aes_cbc_encrypt_ctx, (unsigned char*)plain, strlen(plain), 
        (unsigned char*)cipher, sizeof(cipher));

	printf ("ENC:%d\n", cipher_len);
	printfDump (cipher, cipher_len);
    /*
    [0000] :F8 80 01 09  FB C1 64 72  58 15 47 A4  F2 FA 77 1A
    */

    /*
    ### openssl로 검증
    https://wiki.openssl.org/index.php/Command_Line_Utilities

    $ echo -n "12345678" > plain.txt
    $ openssl enc -aes-128-cbc -in plain.txt  -out encrypt.txt  -K 31323334353637383930313233343536 -iv 31323334353637383930313233343536 -p 
    $ xxd encrypt.txt
    00000000: f880 0109 fbc1 6472 5815 47a4 f2fa 771a  ......drX.G...w.
    */
    
      
    memset (plain, 0x00, sizeof(plain));

    /**
    128bits 복호화
    */
    // IV in 16 bytes long
	memcpy (iv, psk_128, 16);

    aes_set_key_cbc(&aes_cbc_decrypt_ctx, psk_128, (unsigned char*)iv);
	
    plain_len = aes_decrypt_cbc_pkcs5 (&aes_cbc_decrypt_ctx, (unsigned char*)cipher, cipher_len, 
            (unsigned char*)plain, sizeof(plain));
	printf ("DEC:%d\n", plain_len);
	printfDump (plain, plain_len);

    /*
    ### openssl로 검증
    $ openssl enc -d -aes-128-cbc -in encrypt.txt  -out plain.txt.new  -K 31323334353637383930313233343536 -iv 31323334353637383930313233343536 -p 
    $ xxd plain.txt.new
    00000000: 3132 3334 3536 3738                      12345678
    */
	return 0;
}


static int cbc_256bits_test()
{
    unsigned char *psk_256 = "12345678901234561234567890123456";
    unsigned char *plain_text = "12345678";
	char iv[20];
	char plain[100];
	char cipher[100];

	struct aes_cbc_context aes_cbc_encrypt_ctx;
	struct aes_cbc_context aes_cbc_decrypt_ctx;

	int cipher_len;
	int plain_len;


    memset (cipher, 0x00, sizeof(cipher));
	strcpy (plain, plain_text);
	printf ("ORG:%s\n", plain);

    /**
    256bits 암호화
    */
    // IV in 16 bytes long
	memcpy (iv, psk_256, 16);

	aes_set_key256_cbc(&aes_cbc_encrypt_ctx, psk_256, (unsigned char*)iv);
	cipher_len = aes_encrypt_cbc_pkcs5 (&aes_cbc_encrypt_ctx, (unsigned char*)plain, strlen(plain), 
        (unsigned char*)cipher, sizeof(cipher));

	printf ("ENC:%d\n", cipher_len);
	printfDump (cipher, cipher_len);
    /*
        [0000] :AF DC C2 76  3D C3 76 E3  67 AB 9C CE  A7 16 CD 3A
    */

    /*
    ### openssl로 검증
    https://wiki.openssl.org/index.php/Command_Line_Utilities

    $ echo -n "12345678" > plain.txt
    $ openssl enc -aes-256-cbc -in plain.txt  -out encrypt.txt  -K 3132333435363738393031323334353631323334353637383930313233343536 -iv 31323334353637383930313233343536 -p 
    $ xxd encrypt.txt
    00000000: afdc c276 3dc3 76e3 67ab 9cce a716 cd3a  ...v=.v.g......:
    */
    
      
    memset (plain, 0x00, sizeof(plain));

    /**
    256bits 복호화
    */
    // IV in 16 bytes long
	memcpy (iv, psk_256, 16);

    aes_set_key256_cbc(&aes_cbc_decrypt_ctx, psk_256, (unsigned char*)iv);
	
    plain_len = aes_decrypt_cbc_pkcs5 (&aes_cbc_decrypt_ctx, (unsigned char*)cipher, cipher_len, 
            (unsigned char*)plain, sizeof(plain));
	printf ("DEC:%d\n", plain_len);
	printfDump (plain, plain_len);

    /*
    ### openssl로 검증
    $ openssl enc -d -aes-256-cbc -in encrypt.txt  -out plain.txt.new  -K 3132333435363738393031323334353631323334353637383930313233343536 -iv 31323334353637383930313233343536 -p 
    $ xxd plain.txt.new
    00000000: 3132 3334 3536 3738                      12345678
    */
	return 0;
}


static int cbc_file_test()
{
	char key[20];
	char iv[20];

	struct aes_cbc_context aes_cbc_encrypt_ctx;
	struct aes_cbc_context aes_cbc_decrypt_ctx;

	memset (key, 0x00, sizeof(key));
	memset (iv, 0x00, sizeof(iv));

	strcpy (key, "1234567890123456");
	memset (iv, 0x01, 16);


	aes_set_key_cbc(&aes_cbc_encrypt_ctx, (unsigned char*)key, (unsigned char*)iv);
	aes_encrypt_cbc_pkcs5_file (&aes_cbc_encrypt_ctx, "plain.txt", "cipher.txt");

	aes_set_key_cbc(&aes_cbc_decrypt_ctx, (unsigned char*)key, (unsigned char*)iv);
	aes_decrypt_cbc_pkcs5_file (&aes_cbc_decrypt_ctx, "cipher.txt", "plain2.txt");

	return 0;
}

static	struct aes_cbc_context __aes_cbc_ctx;

/* =====
keyHex = "00010203040506070809000102030405"
*/
static int cbc_test_02_init_encrypt_ctx(char* keyHex)
{
    char *pos = keyHex;
    unsigned char key[16];
    int count = 0;
	memset (key, 0x00, sizeof(key));

    if ( strlen(keyHex)!=32 )    {
        return -1;
    }

    for(count = 0; count < sizeof(key)/sizeof(key[0]); count++) {
        sscanf(pos, "%2hhx", &key[count]);
        pos += 2;
    }
    aes_set_key_cbc(&__aes_cbc_ctx, (unsigned char*)key, (unsigned char*)key);

    return 0;
}

static int cbc_test_02_encrypt(char* plain, int plain_len, char* cipher_buff, int cipher_buff_len)
{
	memset (cipher_buff, 0x00, sizeof(cipher_buff_len));
	printf ("ORG:%s\n", plain);

	int len = aes_encrypt_cbc_pkcs5 (&__aes_cbc_ctx, (unsigned char*)plain, plain_len, 
        (unsigned char*)cipher_buff, cipher_buff_len);

    return len;
}

static int cbc_test_02_decrypt(char* cipher, int cipher_len, char* plain_buff, int plain_buff_len)
{
	memset (plain_buff, 0x00, sizeof(plain_buff_len));

    int len = aes_decrypt_cbc_pkcs5 (&__aes_cbc_ctx, (unsigned char*)cipher, cipher_len, 
        (unsigned char*)plain_buff, plain_buff_len);

    return len;
}




static int cbc_test_02()
{
	char plain[100];
	char cipher[100+32];
	int len;

    if ( cbc_test_02_init_encrypt_ctx("00010203040506070809000102030405") < 0 )    {
        return -1;
    }

	memset (cipher, 0x00, sizeof(cipher));

	len = cbc_test_02_encrypt ("12345678", strlen("12345678"), cipher, sizeof(cipher));

	printf ("ENC:%d\n", len);
	printfDump (cipher, len);

    len = cbc_test_02_decrypt(cipher, len, plain, sizeof(plain));
	printfDump (plain, len);

	return 0;
}


static int cbc_test_03()
{
	char buff[100];
	int len;

    if ( cbc_test_02_init_encrypt_ctx("00010203040506070809000102030405") < 0 )    {
        return -1;
    }

	memset (buff, 0x00, sizeof(buff));

    sprintf(buff, "%s", "12345678");

	len = cbc_test_02_encrypt (buff, strlen(buff), buff, sizeof(buff));

	printf ("ENC:%d\n", len);
	printfDump (buff, len);

    len = cbc_test_02_decrypt(buff, len, buff, sizeof(buff));
	printfDump (buff, len);

	return 0;
}



int main(int argc, char* argv[])
{
	cbc_128bits_test();

    //cbc_256bits_test();

	return 0;
}

