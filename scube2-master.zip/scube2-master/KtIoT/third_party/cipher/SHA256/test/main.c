#include <stdio.h>
#include <string.h>

#include "SHA256/sha256.h"


static void printfDump (const char* p, int len)
{
	unsigned int    coff, roff;
	unsigned int    off;
	char    szOutput[258] ;
	char    szString[128] ;
	unsigned int    i = 0 ;
	unsigned int    j = 0 ;
	unsigned int    base = 16;

	for (roff = 0; roff < (len + base -1)/base; roff++)
	{
		i = 0 ;
		j = 0 ;
		memset(szOutput, 0x20, sizeof(szOutput)) ;
		memset(szString, 0x20, sizeof(szString)) ;

		sprintf(&szOutput[i],"[%04X] :", roff * base);
		i = i + 8 ;
		for (coff = 0; coff < base; coff++)
		{
			off = roff * base + coff;
			if (off < len)
			{
				if (base <= 10)
					sprintf(&szOutput[i], "%02d  ",(unsigned char)p[off]);
				else
					sprintf(&szOutput[i],"%02X  ", (unsigned char)p[off]);

				if ((unsigned char)p[off] < 0x20)
					szString[j] = (unsigned char)'.' ;
				else
					szString[j] = (unsigned char)p[off] ;

				if ((coff % 4) == 3)
					i = i + 4 ;
				else
					i = i + 3 ;

				j = j + 1 ;
			}
		}

		szOutput[i]     = (unsigned char)0x20 ;
		szOutput[60]    = (unsigned char)'\0' ;
		szString[j]     = (unsigned char)'\0' ;

		printf ("%-60s  %s \n", szOutput, szString) ;
	}
}

static void sha_256_test()
{
    unsigned char *message = "12345678";
    unsigned char hash[32];

    sha256_get(hash, message, strlen(message));

    printfDump(hash, 32);
    /*
    [0000] :EF 79 7C 81  18 F0 2D FB  64 96 07 DD  5D 3F 8C 76
    [0010] :23 04 8C 9C  06 3D 53 2C  C9 5C 5E D7  A8 98 A6 4F
    */

    /**
    ### 검증

    $ echo -n 12345678 | sha256sum
    ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f  -

    */

    return 0;
}


int main(int argc, char* argv[])
{
    sha_256_test();

	return 0;
}

