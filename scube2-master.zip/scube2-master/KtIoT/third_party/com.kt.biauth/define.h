

#define DEBUG           0

//key size 
#define FUTURE_KEY_SIZE		1024
#define KEYFILENAME_SIZE	255

#define SUCC 				0
#define ERR  				-1

#define SERVERINFOFILE		"ServerInfo.dat"
#define FUTUREKEYFILE		"FutureKey.bin"
//#define CONFIGUREFILE		"2c28a309.txt"

/* kcshin replaced im_base_get_deviceId() */
//#define DANMALDEIVEID		"KT-GW-MUTUAL-112233AABBCC"

/* kcshin replaced im_base_get_extrSysId() */
//#define EXTRSYSID			"LITE_TEST"

#define ATHNFORMLCD			"0007"

// ����� �����޼��� ����
#define AUTH_ERR_URL				-1
#define AUTH_ERR_SOCKET				-2
#define AUTH_ERR_ENCRYPT			-3
#define AUTH_ERR_DECRYPT			-4
#define AUTH_ERR_SOCKET_RECV		-5
#define AUTH_ERR_PARSER 			-6
#define AUTH_ERR_MESSAGE			-7
#define AUTH_ERR_SEQUENCE			-8	

#define BUF_SIZE 					2048
//���������
//����
#define AUTH_EXTRSYSID_LEN			32
#define AUTH_ATHNFORMICD_LEN		32

//1st 3st SDK->EC Request
#define AUTH_DEVICEID_LEN			32		// device id
#define AUTH_RQTSESSNID_LEN			10		//KSN
#define AUTH_ATHNRQTNO_LEN			32		// Encryped_key_A_D(S, R1)
//2st 4st ED->SDK Response 
#define AUTH_ATHNRQTNO_LEN			32		// NO USE
#define AUTH_ATHNSESSNID_LEN		8		// ��������ID��
#define AUTH_ATHNNO_LEN				32		// Encrypted_key_A_S(R2)��
#define AUTH_PLTFRMATHNRQTNO_LEN	16		// Encrypted_key_B_S(S-1)
#define AUTH_RESPCD_LEN				10		// Response code
#define AUTH_RESPMSG_LEN			16		// Response message

#define AUTH_PACKETSIZE_LEN			4
#define AUTH_PACKETHEADER_LEN		35
#define AUTH_KEY_SEQNUM_LEN			4
#define AUTH_KEY_RANDOM1_LEN		16
#define AUTH_KEY_RANDOM2_LEN		16

#define AUTH_KSN_LEN				10
#define AUTH_KEY_MAX_LEN			32

// header define 
#define AUTH_HEADER_TYPE_BASIC			0x01
#define AUTO_HEADER_TYPE_LIGHTWEIGHT	0x02
#define AUTO_HEADER_TYPE_KTZWAVE		0x11

#define AUTH_MSG_TYPE_REQUEST			0x40
#define AUTH_MSG_TYPE_RESPONSE			0x80
#define AUTH_MSG_TYPE_REPORT			0xc0

#define AUTH_MSG_EXCHANGE_ONEWAYACKEDGE	0x00
#define AUTH_MSG_EXCHANGE_ONEWAY		0x10
#define AUTH_MSG_EXCHANGE_ONEWAYACK		0x20
#define AUTH_MSG_EXCHANGE_THREEWAY		0x30

#define AUTH_METHOD_NODEFINE			242  //0xf2

#define AUTH_ENCRYPTION_USAGE_NO		0x01
#define AUTH_ENCRYPTION_USAGE_YES		0x02

#define AUTH_ENCRYPTION_AES128			0x01
#define AUTH_ENCRYPTION_AES256			0x02

#define AUTH_COMPRESSION_USAGE_NO		0x01
#define AUTH_COMPRESSION_USAGE_YES		0x02

#define AUTH_COMPRESSION_HUFFMAN		0x01
#define AUTH_COMPRESSION_RUNLENGTH		0x02
#define AUTH_COMPRESSION_SHANNONFANO	0x03

#define AUTH_ENCODING_USEDEFINED		0x01
#define AUTH_ENCODING_XML				0x02
#define AUTH_ENCODING_JSON				0x03

#define AUTH_RESULT_SUCCESS				0x64

#define AUTH_HEADER_LEN_LOC				6
#pragma pack(push, 1)

/* �������� ���� ����ü */
struct info_st { 
	char iotserverurl[255];
	int  iotserverport;
	char iotserverip[20];
}; 

// ��������� �������
struct Auth_Header_st {
	unsigned char 		Packet_Length[4];
	unsigned char 		Protocol_Version;
	unsigned char		Header_Type;
	unsigned char		Header_Length[2];
	unsigned char		Method_Type1;
	unsigned char		Method_Type2;
	unsigned char 		Trm_Transaction_ID[8];
	unsigned char 		Channel_Auth_Token[16];
	unsigned char 		Encryption_Usage:1;
	unsigned char 		Encryption_Method:7;
	unsigned char		Compression_Usage:1;
	unsigned char 		Compression_Method:7;
	unsigned char		Encoding_Type;
	unsigned char 		Result_code[2];
};

// ��������� ������û �޽��� body ����ü
struct Auth_SDKToEC_request1_st {
	unsigned char extrSysId[AUTH_EXTRSYSID_LEN*2+1];
	unsigned char devId[AUTH_DEVICEID_LEN*2+1];
	unsigned char athnFormlCd[AUTH_ATHNFORMICD_LEN*2+1];
	unsigned char rqtSessnId[AUTH_RQTSESSNID_LEN*2+1];
	unsigned char athnRqtNo[AUTH_ATHNRQTNO_LEN*2+1];
};

// ��������� ���������������� �޽��� body ����ü
struct Auth_SDKFromEC_response2_st {
	unsigned char athnFormlCd[AUTH_ATHNFORMICD_LEN*2+1];
	unsigned char athnRqtNo[AUTH_ATHNRQTNO_LEN*2+1];
	unsigned char athnSessnId[AUTH_ATHNSESSNID_LEN*2+1];
	unsigned char athnNo[AUTH_ATHNNO_LEN*2+1];
	unsigned char pltfrmAthnRqtNo[AUTH_PLTFRMATHNRQTNO_LEN*2+1];
	unsigned char respCd[AUTH_RESPCD_LEN*2+1];
	unsigned char respMsg[AUTH_RESPMSG_LEN*2+1];
};

// ��������� �ܸ������������� �޽��� body ����ü
struct Auth_SDKToEC_request3_st {
	unsigned char extrSysId[AUTH_EXTRSYSID_LEN*2+1];
	unsigned char devId[AUTH_DEVICEID_LEN*2+1];
	unsigned char athnFormlCd[AUTH_ATHNFORMICD_LEN*2+1];
	unsigned char athnSessnId[AUTH_ATHNSESSNID_LEN*2+1];
	unsigned char athnRqtNo[AUTH_ATHNRQTNO_LEN*2+1];
};

// ��������� ������� �� �ܸ�Ƽ�� ���� �޽��� body ����ü
struct Auth_SDKFromEC_response4_st {
	unsigned char athnFormlCd[AUTH_ATHNFORMICD_LEN*2+1];
	unsigned char athnSessnId[AUTH_ATHNSESSNID_LEN*2+1];
	unsigned char athnRqtNo[AUTH_ATHNRQTNO_LEN*2+1];
	unsigned char athnNo[AUTH_ATHNNO_LEN*2+1];
	unsigned char respCd[AUTH_RESPCD_LEN*2+1];
	unsigned char respMsg[AUTH_RESPMSG_LEN*2+1];
};


// ����� ������ �Ϻ�ȣ���� ���� ����ü
struct Auth_Key_st {
	unsigned char keyFile[1024];
	unsigned char configFile[1024];
	unsigned char SeqNum[AUTH_KEY_SEQNUM_LEN+1];
	unsigned char SeqNum2[AUTH_KEY_SEQNUM_LEN+1];
	unsigned char Random1[AUTH_KEY_RANDOM1_LEN+1];
	unsigned char Random2[AUTH_KEY_RANDOM2_LEN+1];
	unsigned char Ksn[AUTH_KSN_LEN+1];
	unsigned char Key_A_D[AUTH_KEY_MAX_LEN];
	unsigned char Key_A_S[AUTH_KEY_MAX_LEN];
	unsigned char Key_B_D[AUTH_KEY_MAX_LEN];
	unsigned char Key_B_S[AUTH_KEY_MAX_LEN];
	int 		  Key_Len;
};

#pragma pack(pop)
