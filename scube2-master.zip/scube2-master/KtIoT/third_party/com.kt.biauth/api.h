
int serverinfofilecheck(struct info_st *info);
int stringsize(unsigned char *stringdata,int len);
int strtohex(unsigned char *stringdata, unsigned char *hexdata, int len);
int hextostr(unsigned char *hexdata, unsigned char *stringdata, int len);
int futurekeyfilecheck(unsigned char *keytablename);
int futurekeyfileread(unsigned char *keytablename, unsigned char *futurekey, int len);
int futurekeyfilesave(unsigned char *keytablename, unsigned char *futurekey, int len);
