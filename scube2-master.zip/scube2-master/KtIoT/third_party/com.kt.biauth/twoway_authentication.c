#include <stdio.h> 
#include <stdlib.h> 
#include <stdarg.h> 
#include <string.h> 
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

#include <SDKCommon.h>
#include <CommonType.h>
#include <aes.h>

#include "define.h"
#include "twoway_authentication.h"
#include "api.h"
#include "sha256.h"

/* kcshin 2016-10-28 */
#define BAS_LOG_PREFIX_FRM		"%s %04d %-10.10s"		//  __FILE__,__LINE__,__FUNCTION__
#define LOG(format, ...)      do{fprintf(stderr, "DBG "BAS_LOG_PREFIX_FRM": "format"\n", __FILE__,__LINE__,__FUNCTION__,  ##__VA_ARGS__);}while(0)

//------------------------------------------------------------------------------
// �Ϻ�ȣ �˰����� ���� �ʱ�ȭ�Ѵ�.
// 
//------------------------------------------------------------------------------
void TwoWayAuth_Init(CipherAlgorithmSet cipherAlgorithmSet, struct Auth_Key_st *Auth_Key)
{	
	if((cipherAlgorithmSet == AES_128_CBC) || (cipherAlgorithmSet == AES_128_CTR)) Auth_Key->Key_Len = 16;
	else if((cipherAlgorithmSet == AES_256_CBC) || (cipherAlgorithmSet == AES_256_CTR)) Auth_Key->Key_Len = 32;
}

//------------------------------------------------------------------------------
// ��������������� ������û �޽����� ������ �����Ѵ�. 
// 
//------------------------------------------------------------------------------
int TwoWayAuthentication1(CipherAlgorithmSet cipherAlgorithmSet, struct Auth_Key_st *Auth_Key, 
		unsigned char *encryptedA)
{
	int i=0;
	int plain_len = 0;
	int encrypt_len = 0;
	AuthCrypt       	crypt;
	unsigned char sequenceNumberAndRandom1[SEQUENCE_LEN + RANDOM_NUM_LEN + 1];
	
	createRandom(Auth_Key->SeqNum, 1);
	createRandom(Auth_Key->Random1, 4);
	createKeyA(Auth_Key);
	
	memset(sequenceNumberAndRandom1, 0, sizeof(sequenceNumberAndRandom1));
	memcpy(&sequenceNumberAndRandom1[0], Auth_Key->SeqNum, SEQUENCE_LEN);
	memcpy(&sequenceNumberAndRandom1[SEQUENCE_LEN], Auth_Key->Random1, RANDOM_NUM_LEN);
	memset(&crypt, 0x00, sizeof(crypt));

	AuthCryptSet(cipherAlgorithmSet, &crypt);
	plain_len = SEQUENCE_LEN+RANDOM_NUM_LEN;
	encrypt_len = encrypt(&crypt, Auth_Key->Key_A_D, sequenceNumberAndRandom1, plain_len, encryptedA);
	if(DEBUG) {
		printf("createKeyA\n");
		printf("ksn     %d: ",KSN_LEN);
		for(i=0;i<KSN_LEN;i++) printf("%02x ",Auth_Key->Ksn[i]);
		printf("\n");
		printf("Key_A_D %d: ",Auth_Key->Key_Len);
		for(i=0;i<Auth_Key->Key_Len;i++) printf("%02x ",Auth_Key->Key_A_D[i]);
		printf("\n");
		printf("Key_A_S %d: ",Auth_Key->Key_Len);
		for(i=0;i<Auth_Key->Key_Len;i++) printf("%02x ",Auth_Key->Key_A_S[i]);
		printf("\n");
		printf("plain %d: ",plain_len);
		for(i=0;i<plain_len;i++) printf("%02x ",sequenceNumberAndRandom1[i]);
		printf("\n");
		printf("encrypt %d: ",encrypt_len);
		for(i=0;i<encrypt_len;i++) printf("%02x ",encryptedA[i]);
		printf("\n");
	}
	if(encrypt_len<=0) return AUTH_ERR_ENCRYPT;
	return encrypt_len;
}

//------------------------------------------------------------------------------
// ��������������� ���������������� �޽����� ���� �� �ܸ��������� ���� �޽����� �����Ѵ�. 
// 
//------------------------------------------------------------------------------
int TwoWayAuthentication2(CipherAlgorithmSet cipherAlgorithmSet, struct Auth_Key_st *Auth_Key, 
		struct Auth_SDKFromEC_response2_st *Auth_SDKFromEC_response2, unsigned char *encryptedA)
{
	int i=0;
	unsigned char 	encryptedB[1024];
	unsigned char 	tmp[1024];
	unsigned char   sequencenumber[32]={0x00,};
	AuthCrypt       	crypt;
	int				encrypt_len = 0;
	int 			plain_len=0;
	int 			nSequenceNumber=0;
	
	memset(encryptedB, 0, sizeof(encryptedB));
	memset(tmp,0,sizeof(tmp));

	memset(&crypt, 0x00, sizeof(crypt));
	AuthCryptSet(cipherAlgorithmSet, &crypt);
	encrypt_len = strlen(Auth_SDKFromEC_response2->athnNo);
	encrypt_len = strtohex(Auth_SDKFromEC_response2->athnNo,encryptedA,encrypt_len);

	plain_len = decrypt(&crypt, Auth_Key->Key_A_S, encryptedA, encrypt_len, tmp);
	if(DEBUG) {
		printf("athno         : %s\n",Auth_SDKFromEC_response2->athnNo);
		printf("encryptedA %d : ",encrypt_len);
		for(i=0;i<encrypt_len;i++) printf("%02x ",encryptedA[i]);
		printf("\n");
		printf("random2 %d    : ",plain_len);
		for(i=0;i<plain_len;i++) printf("%02x ",tmp[i]);
		printf("\n");
	}
	if(plain_len<=0) return AUTH_ERR_DECRYPT;
	memcpy(Auth_Key->Random2, tmp, plain_len);

	createKeyB(Auth_Key);

	encrypt_len = strlen(Auth_SDKFromEC_response2->pltfrmAthnRqtNo);
	encrypt_len = strtohex(Auth_SDKFromEC_response2->pltfrmAthnRqtNo,encryptedB,encrypt_len);

	plain_len = decrypt(&crypt, Auth_Key->Key_B_S, encryptedB, encrypt_len, tmp);
	if(DEBUG) {
		printf("KEY_B_D :");
		for(i=0;i<16;i++) printf("%02x ",Auth_Key->Key_B_D[i]);
		printf("\n");
		printf("KEY_B_S :");
		for(i=0;i<16;i++) printf("%02x ",Auth_Key->Key_B_S[i]);
		printf("\n");
		printf("athno : %s\n",Auth_SDKFromEC_response2->pltfrmAthnRqtNo);
		printf("enctyptedB %d",encrypt_len);
		for(i=0;i<encrypt_len;i++) printf("%02x ",encryptedB[i]);
		printf("\n");
		printf("SeqNum1 %d : ",4);
		for(i=0;i<plain_len;i++) printf("%02x ",Auth_Key->SeqNum[i]);
		printf("\n");
		printf("SeqNum2 %d : ",4);
		for(i=0;i<plain_len;i++) printf("%02x ",tmp[i]);
		printf("\n");
	}
	if(plain_len<=0) return AUTH_ERR_DECRYPT;
	memcpy(Auth_Key->SeqNum2, tmp, plain_len);

	memcpy(sequencenumber,	Auth_Key->SeqNum, AUTH_KEY_SEQNUM_LEN);
	
	nSequenceNumber  = ((sequencenumber[0]<<0 )&0x000000ff);
	nSequenceNumber |= ((sequencenumber[1]<<8 )&0x0000ff00);
	nSequenceNumber |= ((sequencenumber[2]<<16)&0x00ff0000);
	nSequenceNumber |= ((sequencenumber[3]<<24)&0xff000000);
	nSequenceNumber -= 1;
	sequencenumber[0] = ((nSequenceNumber&0x000000ff)>>0)&0xff;
	sequencenumber[1] = ((nSequenceNumber&0x0000ff00)>>8)&0xff;
	sequencenumber[2] = ((nSequenceNumber&0x00ff0000)>>16)&0xff;
	sequencenumber[3] = ((nSequenceNumber&0xff000000)>>24)&0xff;
	if(strcmp(sequencenumber,Auth_Key->SeqNum2)){
		printf("Seqnum not Equal\n");
		return AUTH_ERR_SEQUENCE;
	}
	nSequenceNumber -= 1;
	if(DEBUG) {
		printf("Seqnum Equal Send 0x%x\n",nSequenceNumber);
	}
	sequencenumber[0] = ((nSequenceNumber&0x000000ff)>>0)&0xff;
	sequencenumber[1] = ((nSequenceNumber&0x0000ff00)>>8)&0xff;
	sequencenumber[2] = ((nSequenceNumber&0x00ff0000)>>16)&0xff;
	sequencenumber[3] = ((nSequenceNumber&0xff000000)>>24)&0xff;
	
 	plain_len = AUTH_KEY_SEQNUM_LEN;
	memset(encryptedA,0,sizeof(encryptedA));
	encrypt_len = encrypt(&crypt, Auth_Key->Key_B_D, sequencenumber, plain_len, encryptedA);
	if(encrypt_len<=0) return AUTH_ERR_ENCRYPT;
	if(DEBUG) {
		printf("sequencenumber encrypt %d : ",encrypt_len);
		for(i=0;i<encrypt_len;i++) printf("%02x ",encryptedA[i]);
		printf("\n");
	}
	return encrypt_len;
}

//------------------------------------------------------------------------------
// ��������������� ���ŵ� �ܸ���������� �ܸ�Ƽ������ �޽����� Ȯ���Ѵ�. 
// 
//---------------------------------------------------------------------------------
int TwoWayAuthentication3(int sock, CipherAlgorithmSet cipherAlgorithmSet, struct Auth_Key_st *Auth_Key, 
		struct Auth_SDKFromEC_response4_st *Auth_SDKFromEC_response4)
{
	int i=0;
	int result = 0;
	unsigned char 	encryptedB[1024];
	unsigned char 	decryptedB[1024];
	unsigned char 	tmp[1024];
	unsigned char   ticket[32]={0x00,};
	unsigned char   decryptedSequenceNumber_3[1024];
	unsigned char   sequenceNumber_3[1024];
	AuthCrypt       	crypt;
	int				encrypt_len = 0;
	int 			plain_len=0;
	int 			ticket_len=0;
	int				decryptedSN_3_len = 0;
	int 			nSequenceNumber=0;
	memset(encryptedB, 0, sizeof(encryptedB));
	memset(decryptedB, 0, sizeof(decryptedB));
	memset(ticket,0,sizeof(ticket));
	memset(decryptedSequenceNumber_3,0,sizeof(decryptedSequenceNumber_3));
	memset(sequenceNumber_3,0,sizeof(sequenceNumber_3));
	memset(tmp,0,sizeof(tmp));

	memset(&crypt, 0x00, sizeof(crypt));
	AuthCryptSet(cipherAlgorithmSet, &crypt);

	encrypt_len = strlen(Auth_SDKFromEC_response4->athnNo);
	encrypt_len = strtohex(Auth_SDKFromEC_response4->athnNo,encryptedB,encrypt_len);
	
	plain_len = decrypt(&crypt, Auth_Key->Key_B_S, encryptedB, encrypt_len, decryptedB);
	if(DEBUG) {
		printf("athno : %s\n",Auth_SDKFromEC_response4->athnNo);
		printf("encryptedA %d\n",encrypt_len);
		for(i=0;i<encrypt_len;i++) printf("%02x ",encryptedB[i]);
		printf("\n");
		printf("decryptedB %d\n",plain_len);
		for(i=0;i<plain_len;i++) printf("%02x ",decryptedB[i]);
		printf("\n");
	}
	if(plain_len<=0) return AUTH_ERR_DECRYPT;
	memcpy(Auth_Key->SeqNum2, tmp, plain_len);

	ticket_len =  getTicketFromB(decryptedB, ticket, plain_len);
	decryptedSN_3_len = getS_3FromB(decryptedB,decryptedSequenceNumber_3,plain_len);
	if(DEBUG) {
		printf("sequenceNumber_3 %d : ",decryptedSN_3_len);
		for(i=0;i<decryptedSN_3_len;i++) printf("%02x ",decryptedSequenceNumber_3[i]);
		printf("\n");
		printf("dSeqNum %d          : ",decryptedSN_3_len);
		for(i=0;i<decryptedSN_3_len;i++) printf("%02x ",Auth_Key->SeqNum[i]);
		printf("\n");

	}

	memcpy(sequenceNumber_3,Auth_Key->SeqNum, AUTH_KEY_SEQNUM_LEN);
	
	nSequenceNumber  = ((sequenceNumber_3[0]<<0 )&0x000000ff);
	nSequenceNumber |= ((sequenceNumber_3[1]<<8 )&0x0000ff00);
	nSequenceNumber |= ((sequenceNumber_3[2]<<16)&0x00ff0000);
	nSequenceNumber |= ((sequenceNumber_3[3]<<24)&0xff000000);
	nSequenceNumber -= 3;
	sequenceNumber_3[0] = ((nSequenceNumber&0x000000ff)>>0)&0xff;
	sequenceNumber_3[1] = ((nSequenceNumber&0x0000ff00)>>8)&0xff;
	sequenceNumber_3[2] = ((nSequenceNumber&0x00ff0000)>>16)&0xff;
	sequenceNumber_3[3] = ((nSequenceNumber&0xff000000)>>24)&0xff;

	           
    if(strncmp(sequenceNumber_3, decryptedSequenceNumber_3,AUTH_KEY_SEQNUM_LEN)==0) {
		printf("Two Way Authentication SUCCESS. Server and Device Verified!!!\n" );
		result = SUCC;
	} else {
		printf("Server Verification Fail\n" );
		result = ERR;
	}

	if(result == SUCC){
		printf("[TwoWayAuthentication] Two Way Authentication SUCCESS.\n");
	}else{
		printf("Two Way Authentication FAIL\n" );
	}		
}              

//------------------------------------------------------------------------------
// �޼��� �۽Ž� header ����. 
// 
//---------------------------------------------------------------------------------
int Message_Header_Create(int idx, unsigned char *Trm_Transaction_ID, struct Auth_Header_st *Auth_Header)
{								
	memset(Auth_Header,0,sizeof(struct Auth_Header_st));
	memset(Auth_Header->Packet_Length,0,sizeof(Auth_Header->Packet_Length));
	Auth_Header->Protocol_Version 			= 0x11;
	Auth_Header->Header_Type				= AUTH_HEADER_TYPE_BASIC;
	Auth_Header->Header_Length[0] 			= 0x00;
	Auth_Header->Header_Length[1] 			= 0x23;

	Auth_Header->Method_Type1	= AUTH_MSG_TYPE_REQUEST | AUTH_MSG_EXCHANGE_ONEWAYACK;
	Auth_Header->Method_Type1	= AUTH_MSG_TYPE_REQUEST | AUTH_MSG_EXCHANGE_ONEWAYACK;
	if(idx == 1) {
		Auth_Header->Method_Type2				= 0xf2;
	} else {
		Auth_Header->Method_Type2				= 0xe0;
	}
	memcpy(Auth_Header->Trm_Transaction_ID,Trm_Transaction_ID,sizeof(Auth_Header->Trm_Transaction_ID));
	memset(Auth_Header->Channel_Auth_Token,0x00,sizeof(Auth_Header->Channel_Auth_Token));
	Auth_Header->Encryption_Usage 			= 0x00;
	Auth_Header->Encryption_Method 			= 0x00;
	Auth_Header->Compression_Usage 			= 0x00;
	Auth_Header->Compression_Method 		= 0x00;
	Auth_Header->Encoding_Type 				= AUTH_ENCODING_JSON;
	memset(Auth_Header->Result_code,0x00,sizeof(Auth_Header->Result_code));
	return sizeof(struct Auth_Header_st);
}

//------------------------------------------------------------------------------
// ��������������� ������û �޼��� ������ �����Ѵ�. 
// 
//---------------------------------------------------------------------------------
void message1_send(int sock, unsigned char *Trm_Transaction_ID, unsigned char *encryptedA, int encrypt_len, struct Auth_Key_st *Auth_Key, 
			struct Auth_SDKToEC_request1_st *Auth_SDKToEC_request1)

{
	int i;
	struct Auth_Header_st	Auth_Header;
	unsigned char msg_header[1024] = {0x00,};
	int len;
	int	 msg_header_len = 0;
	int  msg_body_len = 0;
	char  msg_body[BUF_SIZE];
	int  send_msg_len=0;
	unsigned char send_msg[BUF_SIZE];
	unsigned char tmp[1024];
	memset(&Auth_Header,0,sizeof(Auth_Header));
	memset(send_msg,0,sizeof(send_msg));
	memset(msg_body,0,sizeof(msg_body));
	msg_header_len = Message_Header_Create(1, Trm_Transaction_ID, &Auth_Header);
	memcpy(msg_header,&Auth_Header,msg_header_len);

    /* kcshin 2016-10-24 */
	sprintf(Auth_SDKToEC_request1->extrSysId,"%s",im_base_get_extrSysId());
	sprintf(Auth_SDKToEC_request1->devId,"%s",im_base_get_deviceId());

    sprintf(Auth_SDKToEC_request1->athnFormlCd,"%s",ATHNFORMLCD);
	memset(tmp,0,sizeof(tmp));
	hextostr(Auth_Key->Ksn,tmp,KSN_LEN);
	sprintf(Auth_SDKToEC_request1->rqtSessnId,"%s",tmp);
	memset(tmp,0,sizeof(tmp));
	hextostr(encryptedA,tmp,encrypt_len);
	sprintf(Auth_SDKToEC_request1->athnRqtNo,"%s",tmp);

	sprintf(msg_body,"{\"extrSysId\":\"%s\",\"devId\":\"%s\",\"athnFormlCd\":\"%s\",\"rqtSessnId\":\"%s\",\"athnRqtNo\":\"%s\",\"msgHeadVO\":{\"mapHeaderExtension\":{}}}",
		Auth_SDKToEC_request1->extrSysId,Auth_SDKToEC_request1->devId,Auth_SDKToEC_request1->athnFormlCd,Auth_SDKToEC_request1->rqtSessnId,Auth_SDKToEC_request1->athnRqtNo);
	

	if(DEBUG) {
        printf("%s\n", msg_body);    
    }
    msg_body_len = strlen(msg_body);
	send_msg_len = (msg_header_len-4)+msg_body_len;
	memcpy(send_msg,msg_header,msg_header_len);
	send_msg[0] = (send_msg_len&0xff000000)>>24;
	send_msg[1] = (send_msg_len&0x00ff0000)>>16;
	send_msg[2] = (send_msg_len&0x0000ff00)>>8;
	send_msg[3] = (send_msg_len&0x000000ff)>>0;
	memcpy(&send_msg[msg_header_len],msg_body,msg_body_len);
#if JAVATESTSERVER_LINK
	memcpy(&send_msg[msg_header_len+msg_body_len],"\r\n",2);
	send_msg_len += 2;
#endif
	if(DEBUG) {
		printf("header(%d)\n",msg_header_len);
		for(i=0;i<msg_header_len;i++) printf("%02x",send_msg[i]);
		printf("\n");
		printf("body(%d)\n%s\n",msg_body_len,msg_body);
		printf("socket send %d\n",send_msg_len);
	}

		LOG("body(%d)\n%s\n",msg_body_len,msg_body);

#if defined(_IM_C_SSL_)
    im_ssl_send(send_msg, send_msg_len+4);
#else
	write(sock, send_msg, send_msg_len+4);
#endif
}

//------------------------------------------------------------------------------
// ��������������� �ܸ������������� �޼��� ������ �����Ѵ�. 
// 
//------------------------------------------------------------------------------
void message2_send(int sock, unsigned char *Trm_Transaction_ID, unsigned char *encryptedA, int encrypt_len, struct Auth_Key_st *Auth_Key, 
			struct Auth_SDKFromEC_response2_st *Auth_SDKFromEC_response2, struct Auth_SDKToEC_request3_st *Auth_SDKToEC_request3)
{
	int i=0;
	struct Auth_Header_st	Auth_Header;
	unsigned char msg_header[1024] = {0x00,};
	int len;
	int	 msg_header_len = 0;
	int  msg_body_len = 0;
	char  msg_body[BUF_SIZE];
	int  send_msg_len=0;
	unsigned char send_msg[BUF_SIZE];
	unsigned char tmp[1024];
	memset(&Auth_Header,0,sizeof(Auth_Header));
	memset(send_msg,0,sizeof(send_msg));
	memset(msg_body,0,sizeof(msg_body));
	msg_header_len = Message_Header_Create(2, Trm_Transaction_ID, &Auth_Header);
	memcpy(msg_header,&Auth_Header,msg_header_len);

    /* kcshin 2016-10-24 */
	sprintf(Auth_SDKToEC_request3->extrSysId,"%s",im_base_get_extrSysId());
	sprintf(Auth_SDKToEC_request3->devId,"%s",im_base_get_deviceId());
	
    sprintf(Auth_SDKToEC_request3->athnFormlCd,"%s",ATHNFORMLCD);
	sprintf(Auth_SDKToEC_request3->athnSessnId,"%s",Auth_SDKFromEC_response2->athnSessnId);
	memset(tmp,0,sizeof(tmp));
	hextostr(encryptedA,tmp,encrypt_len);
	sprintf(Auth_SDKToEC_request3->athnRqtNo,"%s",tmp);


	sprintf(msg_body,"{\"extrSysId\":\"%s\",\"devId\":\"%s\",\"athnFormlCd\":\"%s\",\"athnSessnId\":\"%s\",\"athnRqtNo\":\"%s\",\"msgHeadVO\":{\"mapHeaderExtension\":{}}}",
		Auth_SDKToEC_request3->extrSysId,Auth_SDKToEC_request3->devId,Auth_SDKToEC_request3->athnFormlCd,Auth_SDKToEC_request3->athnSessnId,Auth_SDKToEC_request3->athnRqtNo);
	msg_body_len = strlen(msg_body);
	send_msg_len = (msg_header_len-4)+msg_body_len;
	memcpy(send_msg,msg_header,msg_header_len);
	send_msg[0] = (send_msg_len&0xff000000)>>24;
	send_msg[1] = (send_msg_len&0x00ff0000)>>16;
	send_msg[2] = (send_msg_len&0x0000ff00)>>8;
	send_msg[3] = (send_msg_len&0x000000ff)>>0;
	memcpy(&send_msg[msg_header_len],msg_body,msg_body_len);
#if JAVATESTSERVER_LINK
	memcpy(&send_msg[msg_header_len+msg_body_len],"\r\n",2);
	send_msg_len += 2;
#endif
	if(DEBUG) {
		printf("header %d\n",msg_header_len);
		for(i=0;i<msg_header_len;i++) printf("%02x",send_msg[i]);
		printf("\n");
		printf("body(%d)\n%s\n",msg_body_len,msg_body);
		printf("socket send %d\n",send_msg_len);
	}
    LOG("body(%d)\n%s\n",msg_body_len,msg_body);

#if defined(_IM_C_SSL_)
    im_ssl_send(send_msg, send_msg_len+4);
#else
	write(sock, send_msg, send_msg_len+4);
#endif
}

//------------------------------------------------------------------------------
// ��������������� �޼����� �����Ѵ�. 
// 
//------------------------------------------------------------------------------
int recv_message(int sock,unsigned char *recv_msg,int *header_len)   // read thread main
{
	int i=0;
	int str_len = 0;
	int recv_msg_len = 0;
	int recv_packet_len = 0;
	while(1)
	{

#if defined(_IM_C_SSL_)
		str_len=im_ssl_recv(&recv_msg[recv_msg_len], BUF_SIZE-1);
#else
		str_len=read(sock, &recv_msg[recv_msg_len], BUF_SIZE-1);
#endif


/*	p.i.w buffer display 
		for(i=0;i<str_len;i++) {
			if(!(i%20)) printf("\n%03d:",i);
			printf("%02x ",recv_msg[recv_msg_len+i]);
		}
		printf("\n");
*/		
		if(str_len<=0) break; 
		if(!(recv_msg_len)) {
			recv_packet_len  = ((int)recv_msg[0])<<24;
			recv_packet_len += ((int)recv_msg[1])<<16;
			recv_packet_len += ((int)recv_msg[2])<<8;
			recv_packet_len += ((int)recv_msg[3])<<0;
		}
		if(DEBUG) {
			printf("all read len %d,%d\n",str_len,recv_packet_len);
		}
		recv_msg_len += str_len;
		if(recv_msg_len>=recv_packet_len) break;
	}
	if(str_len<=0) return AUTH_ERR_SOCKET_RECV;
	*header_len = (recv_msg[AUTH_HEADER_LEN_LOC]<<8) | (recv_msg[AUTH_HEADER_LEN_LOC+1]<<0);
	if(DEBUG) {
		printf("header(%d)\n",(*header_len)+4);
		for(i=0;i<(*header_len)+4;i++) printf("%02x",recv_msg[i]);
		printf("\n");
		printf("body\n%s\n",&recv_msg[AUTH_PACKETSIZE_LEN+AUTH_PACKETHEADER_LEN]);
		printf("recv_message end %d\n",recv_msg_len);
	}

	LOG("body\n%s\n",&recv_msg[AUTH_PACKETSIZE_LEN+AUTH_PACKETHEADER_LEN]);

	return recv_msg_len;
}



//======================= recv message parser ================================
//------------------------------------------------------------------------------
// ��������� �������� ������ �޽����� �Ľ��Ѵ�.
// 
//------------------------------------------------------------------------------
int parsemsg(char *msg, char *search,char *data,char *result)
{
	int i=0,loc=0;
	char *start=NULL;
	char *end=NULL;
	
	char ch;
	result = strstr(msg,search);
	if(result!=NULL) {
		start = strstr(result,":");
		end = strstr(result,",");
		if(end==NULL) {
			end = strstr(result,"}");
		}
		if((start!=NULL) &&(end!=NULL)) {
			i=1;
			loc = 0;
			start++;
			while(1) {
				ch = (char)*start;
//				printf("ch %c",ch);

				if((ch == ',') || (ch == '}')) {
					data[loc]='\0';
					break;
				} else if(ch == '"') {

				} else {
					data[loc++]=ch;
				}
				start++;
				if(loc>=1024) break;
			}
		}
	}else {
		LOG("not found %s",search);
		return 0;
	}
	return loc;
}

//------------------------------------------------------------------------------
// ��������� �������� ������ �޽����� �Ľ��Ѵ�.
// ���������������� �޽��� �Ľ�
//------------------------------------------------------------------------------
int recv_parser1(char *msg, struct Auth_SDKFromEC_response2_st *response,int len)
{
	int  ret;
	char *result=NULL;
	ret = parsemsg(msg,"athnFormlCd",response->athnFormlCd,result);
	if(!ret) return AUTH_ERR_PARSER;
	ret = parsemsg(msg,"athnRqtNo",response->athnRqtNo,result);
	if(!ret) return AUTH_ERR_PARSER;
	ret = parsemsg(msg,"athnSessnId",response->athnSessnId,result);
	if(!ret) return AUTH_ERR_PARSER;
	ret = parsemsg(msg,"athnNo",response->athnNo,result);
	if(!ret) return AUTH_ERR_PARSER;
	ret = parsemsg(msg,"pltfrmAthnRqtNo",response->pltfrmAthnRqtNo,result);
	if(!ret) return AUTH_ERR_PARSER;
	ret = parsemsg(msg,"respCd",response->respCd,result);
	if(!ret) return AUTH_ERR_PARSER;
	ret = parsemsg(msg,"respMsg",response->respMsg,result);
	if(!ret) return AUTH_ERR_PARSER;
	if(strcmp(response->respMsg,"SUCCESS")) {
		LOG("respCd %s,respMsg %s",response->respCd,response->respMsg);
		return AUTH_ERR_MESSAGE;
	}
	return SUCC;

}

//------------------------------------------------------------------------------
// ��������� �������� ������ �޽����� �Ľ��Ѵ�.
// ��������� �ܸ�Ƽ�� ���� �޽��� �Ľ�
//------------------------------------------------------------------------------
int recv_parser2(char *msg, struct Auth_SDKFromEC_response4_st *response,int len)
{
	int  ret;
	char *result=NULL;
	ret = parsemsg(msg,"athnFormlCd",response->athnFormlCd,result);
	if(!ret) return ret;
	ret = parsemsg(msg,"athnSessnId",response->athnSessnId,result);
	if(!ret) return ret;
	ret = parsemsg(msg,"athnNo",response->athnNo,result);
	if(!ret) return ret;
	ret = parsemsg(msg,"respCd",response->respCd,result);
	if(!ret) return ret;
	ret = parsemsg(msg,"respMsg",response->respMsg,result);
	if(!ret) return ret;
	if(strcmp(response->respMsg,"SUCCESS")) {
		LOG("respCd %s,respMsg %s",response->respCd,response->respMsg);
		return AUTH_ERR_MESSAGE;
	}
	return SUCC;

}

//======================================================================================
//------------------------------------------------------------------------------
// iotmaker ������ ��������� �����Ѵ�.
// domain name ���� ����ϴ°��
//------------------------------------------------------------------------------
int iotmaker_domain_connect(struct info_st *serverinfo, int *iot_socket)
{
	int sock;
	struct sockaddr_in serv_addr;
	struct timeval     tv;
	struct hostent *host_entry;
    int             ndx;

    host_entry = gethostbyname( serverinfo->iotserverurl);
    if ( !host_entry)
    {
        LOG( "gethostbyname() fail");
        return AUTH_ERR_URL;
    }
    for ( ndx = 0; NULL != host_entry->h_addr_list[ndx]; ndx++) {
//        printf( "%s\n", inet_ntoa( *(struct in_addr*)host_entry->h_addr_list[ndx]));
	}

	memset(&serv_addr, 0x00, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(serverinfo->iotserverport);
	bcopy(host_entry->h_addr,(char *)&serv_addr.sin_addr,host_entry->h_length);
	if(DEBUG) {
		LOG("Trying IP : %s...\n",inet_ntoa(serv_addr.sin_addr));
	}
	sock =  socket(PF_INET, SOCK_STREAM, 0);
	if(sock < 0)
	{
		LOG("socket create error!\n");
		return AUTH_ERR_SOCKET;
	}

	// Read �� Ÿ�� �ƿ� ����
	tv.tv_sec = 300;
	tv.tv_usec = 0;
	setsockopt( sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv, sizeof(struct timeval) );

	// Server Connect
	if(connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
	{
		LOG("socket connect error !\n");
		return AUTH_ERR_SOCKET;
	}
	*iot_socket = sock;
	return SUCC;

}

//------------------------------------------------------------------------------
// iotmaker ������ ��������� �����Ѵ�.
// ip�� ����ϴ� ���
//------------------------------------------------------------------------------
int iotmaker_ip_connect(struct info_st *serverinfo, int *iot_socket)
{
	int sock;
	struct sockaddr_in serv_addr;
	struct timeval     tv;
    int             ndx;

	memset(&serv_addr, 0x00, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(serverinfo->iotserverport);
	serv_addr.sin_addr.s_addr=inet_addr(serverinfo->iotserverip);
	sock =  socket(PF_INET, SOCK_STREAM, 0);
	if(sock < 0)
	{
		LOG("socket create error!\n");
		return AUTH_ERR_SOCKET;
	}

	// Read �� Ÿ�� �ƿ� ����
	tv.tv_sec = 300;
	tv.tv_usec = 0;
	setsockopt( sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv, sizeof(struct timeval) );

	// Server Connect
	if(connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
	{
		LOG("socket connect error !\n");
		return AUTH_ERR_SOCKET;
	}
	*iot_socket = sock;
	return SUCC;

}

//======================================================================================
//------------------------------------------------------------------------------
// random ���� �����Ѵ�..
//
//------------------------------------------------------------------------------
void createRandom(char *targetPtr, int count)
{
    int rand_num, repeatCount;
    char intToByte[5] = {0x00,};  //p.i.w
    unsigned char tmpChar;
    for(repeatCount = 0; repeatCount < count; repeatCount++)
    {
      	rand_num = rand(); // % 255 + 1;
        //printf("rand_num = %d\n", rand_num);

        bzero(intToByte, sizeof(intToByte));
        tmpChar = rand_num & 0xff;
        sprintf(&intToByte[0], "%c", tmpChar);
        tmpChar = (rand_num >> 8) & 0xff;
        sprintf(&intToByte[1], "%c", tmpChar);
        tmpChar = (rand_num >> 16) & 0xff;
        sprintf(&intToByte[2], "%c", tmpChar);
        tmpChar = (rand_num >> 24) & 0xff;
        sprintf(&intToByte[3], "%c", tmpChar);

      	memcpy(&targetPtr[repeatCount*4], &intToByte[0], 4);
    }
}

//------------------------------------------------------------------------------
// KSN, KEY_A_D, KEY_A_S �� �����Ѵ�.
//
//------------------------------------------------------------------------------
int createKeyA(struct Auth_Key_st *Auth_Key)
{
	int iret=0;
	unsigned char *pin = "1234";
	unsigned char *account_num = "4012345678909";
	unsigned char outputFutureKeySet[1024];
	DukptPinEntry	key;

	memset(&key, 0x00, sizeof(key));
    // kcshin 2016-11-01
    if ( FutureKey_File_Read(Auth_Key->keyFile, Auth_Key->configFile) < 0 ) {
        return -1;
    };

	iret = DAMO_DUKPT_Request_Pin_Entry(pin, 4, account_num, 13, DAMO_DUKPT_FLAG_USE_ALL_KEY, &key);

	memcpy(Auth_Key->Ksn, key.ksn, KSN_LEN);
	memcpy(Auth_Key->Key_A_D, key.req_enc_key, Auth_Key->Key_Len);
	memcpy(Auth_Key->Key_A_S, key.res_enc_key, Auth_Key->Key_Len);
	memset(outputFutureKeySet, 0x00, sizeof(outputFutureKeySet));

	DAMO_DUKPT_Export_Future_Key_Info((DukptFutureKeyInfo *)outputFutureKeySet);
	FutureKey_File_Write(Auth_Key->keyFile,outputFutureKeySet);

	return DAMO_DUKPT_SUCCESS;

}

//------------------------------------------------------------------------------
// KEY_B_D, KEY_B_S �� �����Ѵ�.
//
//------------------------------------------------------------------------------
int createKeyB(struct Auth_Key_st *Auth_Key)
{
	int i=0;
	unsigned char key[AUTH_KEY_MAX_LEN];
	memset(key,0,sizeof(key));
	hmac_sha256_generate(Auth_Key->Key_A_D, Auth_Key->Key_Len, Auth_Key->Random1, AUTH_KEY_RANDOM1_LEN, Auth_Key->Random2, AUTH_KEY_RANDOM2_LEN,key);
	for(i=0;i<Auth_Key->Key_Len;i++) Auth_Key->Key_B_D[i] = key[i];
	memset(key,0,sizeof(key));
	hmac_sha256_generate(Auth_Key->Key_A_S, Auth_Key->Key_Len, Auth_Key->Random1, AUTH_KEY_RANDOM1_LEN, Auth_Key->Random2, AUTH_KEY_RANDOM2_LEN,key);
	for(i=0;i<Auth_Key->Key_Len;i++) Auth_Key->Key_B_S[i] = key[i];
	return 0;
}

//------------------------------------------------------------------------------
// Futurekey ������ read�Ѵ�.
//
//------------------------------------------------------------------------------
int FutureKey_File_Read(unsigned char *keySetFilePath, unsigned char *configFilePath)
{
	FILE	*fp;
	unsigned char inputFutureKeySet[1024];
	unsigned char buf[512];
	int		read_cnt = 0;


    fp = fopen(keySetFilePath, "rb");

    if(fp != NULL)
    {
		memset(buf, 0x00, sizeof(buf));
		memset(inputFutureKeySet, 0x00, sizeof(inputFutureKeySet));

		read_cnt = fread(inputFutureKeySet, 1, sizeof(inputFutureKeySet), fp);

		//memcpy(inputFutureKeySet, buf, sizeof(inputFutureKeySet));
		//printfDump(inputFutureKeySet, sizeof(inputFutureKeySet));

		DAMO_DUKPT_Import_Future_Key_Info((DukptFutureKeyInfo *)inputFutureKeySet);

      	fclose(fp);
    }
    else {
      	LOG("Can't open file : %s\n", keySetFilePath);
		return -1;
	}
	return DAMO_DUKPT_SUCCESS;
}

//------------------------------------------------------------------------------
// Futurekey ���Ͽ� write�Ѵ�.
//
//------------------------------------------------------------------------------
int FutureKey_File_Write(unsigned char *keySetFilePath,unsigned char *OutPut)
{
	FILE	*fp;


    fp = fopen(keySetFilePath, "wb");
    if(fp != NULL)
    {
		DAMO_DUKPT_Export_Future_Key_Info((DukptFutureKeyInfo *)OutPut);
		fwrite(OutPut, 1, DAMO_DUKPT_FUTURE_KEY_INFO_SIZE, fp);

      	fclose(fp);
    }
    else{
      	LOG("Can't open file : %s\n", keySetFilePath);
		return -1;
	}


	return DAMO_DUKPT_SUCCESS;
}

//------------------------------------------------------------------------------
// �Ϻ�ȣ�˰����� ���� �б��� ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
int encrypt(AuthCrypt *pCrypt, unsigned char *key, unsigned char *plain, int plain_len, unsigned char *encrypt)
{
	int	encrypt_len;

	if(strcmp(pCrypt->algorithm, "AES") == 0)
	{
		if(pCrypt->keySize == 128) {
			if(strcmp(pCrypt->mode, "CTR") == 0) {
				encrypt_len = plain_len;
				aesEncryptCTR_128(key, plain,  plain_len, encrypt);
			}
			else {
				encrypt_len = aesEncryptCBC_128(key, plain, plain_len, encrypt, pCrypt->initVector);
			}
		} else if(pCrypt->keySize == 256) {
			if(strcmp(pCrypt->mode, "CTR") == 0) {
			}
			else {
				encrypt_len = aesEncryptCBC_256(key, plain, plain_len, encrypt, pCrypt->initVector);
			}
		}
	}
	else
	{
		//aesEncryptCbc(key, plainData, plain_len, 128);
	}


	return encrypt_len;
}

//------------------------------------------------------------------------------
// aes-128 CBC �˰��������� ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
int aesEncryptCBC_128(unsigned char *key, unsigned char *plain, int plain_len, unsigned char *encrypt, unsigned char *sInitVector)
{
    struct aes_cbc_context aes_cbc_encrypt_ctx;
    struct aes_cbc_context aes_cbc_decrypt_ctx;
	unsigned char 	iv[16];
	unsigned char	encryptKey[16];
	int 			encrypt_len=0;
	
	memset(iv,0,sizeof(iv));
	memcpy(encryptKey,key,16);
	aes_set_key_cbc(&aes_cbc_encrypt_ctx, (unsigned char*)encryptKey, (unsigned char*)iv);
    encrypt_len = aes_encrypt_cbc_pkcs5 (&aes_cbc_encrypt_ctx, (unsigned char*)plain, plain_len, (unsigned char*)encrypt, plain_len+16);
	return encrypt_len;
}

//------------------------------------------------------------------------------
// aes-256 CBC �˰��������� ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
int aesEncryptCBC_256(unsigned char *key, unsigned char *plain, int plain_len, unsigned char *encrypt, unsigned char *sInitVector)
{
    struct aes_cbc_context aes_cbc_encrypt_ctx;
    struct aes_cbc_context aes_cbc_decrypt_ctx;
	unsigned char 	iv[32];
	unsigned char	encryptKey[32];
	int 			encrypt_len=0;
	
	memset(iv,0,sizeof(iv));
	memcpy(encryptKey,key,32);
	aes_set_key_cbc(&aes_cbc_encrypt_ctx, (unsigned char*)encryptKey, (unsigned char*)iv);
    encrypt_len = aes_encrypt_cbc_pkcs5 (&aes_cbc_encrypt_ctx, (unsigned char*)plain, plain_len, (unsigned char*)encrypt, plain_len+32);
	return encrypt_len;
}

//------------------------------------------------------------------------------
// aes-128 CTR �˰��������� ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
void aesEncryptCTR_128(unsigned char *key, unsigned char *plain, int plain_len, unsigned char *encrypt)
{
	encrypt_ctr(key, plain,encrypt ,plain_len);
}

//------------------------------------------------------------------------------
// �Ϻ�ȣ�˰����� ���� �б��� ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
int decrypt(AuthCrypt *pCrypt, unsigned char *key, unsigned char *encrypt, int encrypt_len, unsigned char *plain)
{
	int	plain_len = encrypt_len;

	if(strcmp(pCrypt->algorithm, "AES") == 0)
	{	
		if(pCrypt->keySize == 128) {
			if(strcmp(pCrypt->mode, "CTR") == 0) {
				plain_len = encrypt_len;
				aesDecryptCTR_128(key, encrypt, encrypt_len, plain);
			}
			else {
				plain_len = aesDecryptCBC_128(key, encrypt, encrypt_len, plain, pCrypt->initVector);
			}
		} else if(pCrypt->keySize == 256) {
			if(strcmp(pCrypt->mode, "CTR") == 0) {

			}
			else {
				plain_len = aesDecryptCBC_256(key, encrypt, encrypt_len, plain, pCrypt->initVector);
			}
		}
	}
	else
	{
        ;
		//aesEncryptCbc(key, plainData, plain_len, 128);
	}


	return plain_len;
}

//------------------------------------------------------------------------------
// aes-128 CBC �˰��������� ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
int aesDecryptCBC_128(unsigned char *key, unsigned char *encrypt, int encrypt_len, unsigned char *plain, unsigned char *sInitVector)
{
	int i=0;
    struct aes_cbc_context aes_cbc_encrypt_ctx;
    struct aes_cbc_context aes_cbc_decrypt_ctx;
	unsigned char 	iv[16];
	unsigned char	decryptKey[16];
	int 			plain_len;
	
	memset(iv,0,sizeof(iv));
	memcpy(decryptKey,key,16);
	aes_set_key_cbc(&aes_cbc_decrypt_ctx, (unsigned char*)decryptKey, (unsigned char*)iv);
    plain_len = aes_decrypt_cbc_pkcs5 (&aes_cbc_decrypt_ctx, encrypt, encrypt_len, plain, plain_len);
	return plain_len;
}

//------------------------------------------------------------------------------
// aes-256 CBC �˰��������� ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
int aesDecryptCBC_256(unsigned char *key, unsigned char *encrypt, int encrypt_len, unsigned char *plain, unsigned char *sInitVector)
{
	int i=0;
    struct aes_cbc_context aes_cbc_encrypt_ctx;
    struct aes_cbc_context aes_cbc_decrypt_ctx;
	unsigned char 	iv[32];
	unsigned char	decryptKey[32];
	int 			plain_len;
	
	memset(iv,0,sizeof(iv));
	memcpy(decryptKey,key,32);
	aes_set_key_cbc(&aes_cbc_decrypt_ctx, (unsigned char*)decryptKey, (unsigned char*)iv);
    plain_len = aes_decrypt_cbc_pkcs5 (&aes_cbc_decrypt_ctx, encrypt, encrypt_len, plain, plain_len);
	return plain_len;
}

//------------------------------------------------------------------------------
// aes-128 CTR �˰��������� ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
void aesDecryptCTR_128(unsigned char *key, unsigned char *encrypt, int encrypt_len, unsigned char *plain)
{
	encrypt_ctr(key,encrypt, plain,encrypt_len);
}

//------------------------------------------------------------------------------
// �Ϻ�ȣ �˰����� ����  ��ȣȭ�Ѵ�.
//
//------------------------------------------------------------------------------
void AuthCryptSet(CipherAlgorithmSet cipherAlgorithmSet_tmp, AuthCrypt *pCrypt)
{
	CipherAlgorithmSet	cipherAlgorithm;

	cipherAlgorithm = cipherAlgorithmSet_tmp;

	pCrypt->cipherAlgorithmSet = cipherAlgorithmSet_tmp;
		
	switch(cipherAlgorithm) 
	{
		case AES_128_CBC : 
			strcpy(pCrypt->algorithm, "AES"); 
			pCrypt->keySize = 128; 
			strcpy(pCrypt->mode, "CBC"); 
			break;
		case AES_128_CTR : 
			strcpy(pCrypt->algorithm, "AES"); 
			pCrypt->keySize = 128; 
			strcpy(pCrypt->mode, "CTR"); 
			break;
		case AES_256_CBC :
			strcpy(pCrypt->algorithm, "AES"); 
			pCrypt->keySize = 256; 
			strcpy(pCrypt->mode, "CBC"); 
			break;
		case AES_256_CTR :
			strcpy(pCrypt->algorithm, "AES"); 
			pCrypt->keySize = 256; 
			strcpy(pCrypt->mode, "CTR"); 
			break;
		default : 
			strcpy(pCrypt->algorithm, "AES"); 
			pCrypt->keySize = 128; 
			strcpy(pCrypt->mode, "CBC"); 
			break;
	}
}

int getTicketFromB(unsigned char *decryptedB, unsigned char *ticket, int length)
{              
	if(length < TICKET_LEN ){
       	LOG("decryptedB length is too short" );
		memcpy(ticket, decryptedB, length);
		return length;
	}
	memcpy(ticket, decryptedB, TICKET_LEN);

	return TICKET_LEN;
}

int getS_3FromB(unsigned char *decryptedB, unsigned char *seqnum, int length)
{
	int correctLength = TICKET_LEN + SEQUENCE_LEN;
	
	if(correctLength != length){
		LOG("decryptedB length(%d) is not %d.",length,correctLength);
		memcpy(seqnum, decryptedB, length);
		return length;
	}
	
	memcpy(seqnum, &decryptedB[TICKET_LEN],length-TICKET_LEN);
	return length-TICKET_LEN;
}
