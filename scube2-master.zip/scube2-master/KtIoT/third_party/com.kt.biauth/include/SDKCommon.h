#ifndef _SDKCOMMON_H_
#define _SDKCOMMON_H_


// Auth Constant
#define AUTH_TYPE_ONE_WAY				0x00
#define AUTH_TYPE_TWO_WAY				0x01
#define AUTH_TYPE_MULTI_SVR				0x02

#define MSG_TYPE_CLI_HELLO				0x00
#define MSG_TYPE_CLI_DONE				0x01
#define MSG_TYPE_SVR_HELLO				0x11
#define MSG_TYPE_SVR_DONE				0x12

#define DEVICE_ID_LEN					16
#define SESSION_ID_LEN					8

#define KSN_LEN							10
#define SEQUENCE_LEN					4

#define CRYPT_KEY_LEN					16
#define ENC_PADD_LEN					16
#define RANDOM_NUM_LEN					16
#define TICKET_LEN						16

#define ENC_METHOD_AES_128_CBC			0x01			// default
#define ENC_METHOD_AES_256_CBC			0x02
#define ENC_METHOD_AES_128_CTR			0x03
#define ENC_METHOD_AES_256_CTR			0x04
#define ENC_METHOD_DES_64				0x11
#define ENC_METHOD_DES_192				0x12
#define ENC_METHOD_SEED_128				0x21
#define ENC_METHOD_ARIA_128				0x31
#define ENC_METHOD_ARIA_192				0x32
#define ENC_METHOD_ARIA_256				0x33

#define HMAC_ALGORITHM					"HmacSHA256"	//HmacSHA1 HmacSHA256 HmacSHA384 HmacSHA512

#define DEFAULT_SESSIONID				111


/*
#define NO_AUTHENTICATION				"NO_AUTHENTICATION"
#define	ID_PASSWORD						"ID_PASSWORD"
#define ONE_WAY							"ONE_WAY"
#define DYNAMIC_ONE_WAY					"DYNAMIC_ONE_WAY"
#define DYNAMIC_TWO_WAY					"DYNAMIC_TWO_WAY"
#define TOKEN							"TOKEN"
*/




typedef unsigned char		UCHAR;
typedef char				CHAR;

#endif
