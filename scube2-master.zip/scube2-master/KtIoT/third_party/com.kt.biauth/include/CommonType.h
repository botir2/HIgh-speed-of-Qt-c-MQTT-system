#ifndef _COMMONTYPE_H_
#define _COMMONTYPE_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <dukpt.h>

#pragma pack(1)

typedef enum
{
	RESULT_SUCCESS, PROCESSING, FAIL, UNKNOWN_FAIL
} AuthenticationResultSet;

typedef enum
{
	NO_AUTHENTICATION, ID_PASSWORD, ONE_WAY, DYNAMIC_ONE_WAY, DYNAMIC_TWO_WAY, TOKEN
} AuthenticationTypeSet;

typedef enum
{
	AES_128_CBC, AES_128_CTR, AES_256_CBC, AES_256_CTR
} CipherAlgorithmSet;

typedef enum
{
	SUCCESS, ERR_AUTHENTICATION_TYPE, ERR_MESSAGE_TYPE, ERR_KSN, ERR_BASEKEY_SET, 
	ERR_FUTUREKEY_SET, ERR_CYPHERALGORITHM, ERR_ENCRYPTION, ERR_DECRYPTION, ERR_SEQUENCE, 
	ERR_RANDOM_GEN, ERR_SESSIONID, ERR_DEVICE_ERR, ERR_DEVICE_KEYSET, ERR_KEYSETID, 
	ERR_NO_CONFIG, ERR_UNKNOWN
} ResponseCodeSet;

typedef struct {
	char *ksn;
	char *sessionID;
	char *s_value;
	char *random1;
	char *random2;
} ConfigData_Simple;

typedef struct {
	unsigned char 				ksn[10];
	AuthenticationResultSet 	authenticationResult;
	ResponseCodeSet				responseCode;
	unsigned char 				*encryptedA;
	CipherAlgorithmSet			cipherAlgorithmSet;
} Message1_OutputSet;

typedef struct {
	int							messageType;
	AuthenticationResultSet		authenticationResult;
	ResponseCodeSet				responseCode;
	char						*authenticationSessionID;
	char						*encryptedB;
} Message2_OutputSet;

typedef struct {
	char						*authenticationSessionID;
	AuthenticationResultSet		authenticationResult;
	ResponseCodeSet				responseCode;
} Message4_OutputSet;

typedef struct {
	AuthenticationTypeSet		authenticationtype;
	int 						messageType;
	unsigned char 				ksn[10];
	unsigned char 				*encryptedA;
	unsigned char				*encryptedB;
	unsigned char 				*authenticationSessionID;
	CipherAlgorithmSet 			cipherAlgorithmSet;
	AuthenticationResultSet 	authenticationResult;
	ResponseCodeSet 			responseCode;
	char 						sendMessage[512];
} TwoWayAuthenticationResults;

typedef struct {
	DukptPinEntry				cDukpt_Pin_Entry_c;
	DukptPinEntry				cDukpt_Pin_Entry_s;
	DukptFutureKeyInfo			dukptFutureKey;
	unsigned char				ipek[16]; 
	unsigned char 				cur_key[16];
	unsigned char 				shift_register_bit_num;
	int 						shift_register;
	unsigned char 				crypto_register1[8];
	unsigned char 				future_key_output[368];
	unsigned char 				key_register[16];
	unsigned char 				*current_key_pointer;
	char						keySetFilePath[128];
	char						configFilePath[128];
} Dukpt;


typedef struct {
	unsigned char				encryptMethod;
	CipherAlgorithmSet 			cipherAlgorithmSet;
	char						algorithm[8];
	int							keySize;
	char						mode[8];
	unsigned char				initVector[8];
} AuthCrypt;

typedef struct {
	unsigned char 				ksn[10];
	unsigned char				keyA_D[16]; 
	unsigned char				keyA_S[16]; 
} dupkptKeys;

typedef struct {
	//long 						serialVersionUID = 6577238317307289933L;
	unsigned char				*key;
	unsigned char				*algorithm;
} SecretKeySpec;
#pragma pack()


#endif
