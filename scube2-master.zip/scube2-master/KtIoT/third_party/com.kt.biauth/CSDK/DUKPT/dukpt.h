#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

typedef struct {
	unsigned char ksn[10]; // key serial number(encryption counter 포함)
	unsigned char enc_pin_block[8]; // encrypted pin block
	unsigned char pin_enc_key[16]; // pin enc key
	unsigned char req_mac_key[16]; // request mac key
	unsigned char res_mac_key[16]; // response mac key
	unsigned char req_enc_key[16]; // request enc key
	unsigned char res_enc_key[16]; // response enc key
} DukptPinEntry;

#pragma pack(1)
typedef struct {
#define DAMO_DUKPT_VERSION 		  0x01	// 1바이트
	unsigned char version;
	unsigned char key_serial_number[10];
	unsigned char future_key_register[21][17];
} DukptFutureKeyInfo;
#pragma pack()

#define DAMO_DUKPT_FUTURE_KEY_INFO_SIZE	sizeof(DukptFutureKeyInfo)

// 필요한 키에 대한 플래그(DAMO_DUKPT_Request_Pin_Entry함수에서 사용)
#define DAMO_DUKPT_SUCCESS                0x0000 // Success
#define DAMO_DUKPT_ERR_NULL_POINTER   	 -0x0001 // NULL 포인터 에러
#define DAMO_DUKPT_ERR_INVALID_LEN  	 -0x0002 // 유효하지 않는 키 길이
#define DAMO_DUKPT_ERR_INVALID_VERSION	 -0x0007 // 유효하지 않는 버전

#define DAMO_DUKPT_FLAG_USE_NOT_KEY	  0x0000 // 모든 키를 사용하지 않음
#define DAMO_DUKPT_FLAG_USE_PIN_ENC_KEY	  0x0001 // PIN 암호화키 사용
#define DAMO_DUKPT_FLAG_USE_DATA_MAC_KEY  0x0002 // DATA MAC키 사용
#define DAMO_DUKPT_FLAG_USE_DATA_ENC_KEY  0x0004 // DATA 암호화키 사용
#define DAMO_DUKPT_FLAG_USE_ALL_KEY	  0x0007 // 모든 키 사용


#ifdef __cplusplus
extern "C" {
#endif

/* DAMO_DUKPT_Request_Pin_Entry
 * description : 암호화된 PIN 데이터 생성 및 MAC Key/Data Encryption Key 생성 함수
 *   
 * parameter
 * 1. pin(IN) : 입력할 PIN 데이터
 * 2. pin_len(IN) : 입력할 PIN 데이터 길이
 * 3. account_num(IN) : 카드 번호 데이터
 * 4. account_num_len(IN) : 카드 번호 데이터 길이
 * 5. flags(IN) : PIN 암호화 키 / Data MAC 키 / Data 암호화 키 사용여부 플래그
 * 6. pEntry(OUT) : 암호화된 PIN 데이터 및 MAC KEY 그리고 Data Encryption Key를 저장할 구조체 포인터
 *      
 * return value
 *  if successful, ret = 0
 *  otherwise, ret < 0
 */
int DAMO_DUKPT_Request_Pin_Entry(const unsigned char *pin, size_t pin_len,
		const unsigned char *account_num, size_t account_num_len, int flags, DukptPinEntry *pEntry);

/* DAMO_DUKPT_Import_Future_Key_Info
 * description : KSN과 Future Key Set을 설정하는 함수
 *   
 * parameter
 * 1. fki(IN) : 설정할 KSN과 Future Key Set의 구조체 
 *      
 * return value
 *  if successful, ret = 0
 *  otherwise, ret < 0
 */
int DAMO_DUKPT_Import_Future_Key_Info(DukptFutureKeyInfo *fki);

/* DAMO_DUKPT_Export_Future_Key_Info
 *  description : KSN과 Future Key Set을 가져오는 함수
 *  
 *  parameter
 *  1. fki(OUT) : KSN과 Future Key Set를 저장할 구조체 포인터
 * 
 *  return value
 *   if successful, ret = 0
 *   otherwise, ret < 0
 */
int DAMO_DUKPT_Export_Future_Key_Info(DukptFutureKeyInfo *fki);

#ifdef __cplusplus
}
#endif
