/****************************************************************/
/*		AES_UTILS.C												*/
/****************************************************************/

#include <stdio.h>
#include <string.h>

#ifdef AES
#include "aes.h"

#define	KEYs	"inisoft/digitalwave"

struct aes_context aes_ctx;

int	aes_init()
{
#if 0
	aes_set_key(&aes_ctx, KEYs, NBITS);
#else
	aes_set_key(&aes_ctx, KEYs, 128);
#endif 
	return 0;
}

int	aes_encode(char *buf, int length)
{
	aes_enc_str(&aes_ctx, buf, length);
	return 0;
}

int	aes_decode(char *buf, int length)
{
	aes_dec_str(&aes_ctx, buf, length);
	return 0;
}

int	aes_file_encode(char *path)
{
	char	new_path[1024];

	strcpy(new_path, path);
	sprintf(path, "%s.enc", new_path);
	aes_enc_file(&aes_ctx, new_path, path);
	return 0;
}

int	aes_file_decode(char *path)
{
	char	new_path[1024];

	strcpy(new_path, path);
	if (strncmp(path+strlen(path)-4, ".enc", 4) != 0)
		return -1;
	path[strlen(path)-4] = 0;

	aes_dec_file(&aes_ctx, new_path, path);

	return 0;
}
#endif


void printfDump (const char* p, int len)
{
    unsigned int    coff, roff;
    unsigned int    off;
    char    szOutput[258] ;
    char    szString[128] ;
    unsigned int    i = 0 ;
    unsigned int    j = 0 ;
    unsigned int    base = 16;
 
	printf("printfDump .....\n");
    for (roff = 0; roff < (len + base -1)/base; roff++)
    {
        i = 0 ;
        j = 0 ;
        memset(szOutput, 0x20, sizeof(szOutput)) ;
        memset(szString, 0x20, sizeof(szString)) ;
 
        sprintf(&szOutput[i],"[%04X] :", roff * base);
        i = i + 8 ;
        for (coff = 0; coff < base; coff++)
        {
            off = roff * base + coff;
            if (off < len)
            {
                if (base <= 10)
                    sprintf(&szOutput[i], "%02d  ",(unsigned char)p[off]);
                else
                    sprintf(&szOutput[i],"%02X  ", (unsigned char)p[off]);
 
                if ((unsigned char)p[off] < 0x20)
                    szString[j] = (unsigned char)'.' ;
                else
                    szString[j] = (unsigned char)p[off] ;
 
                if ((coff % 4) == 3)
                    i = i + 4 ;
                else
                    i = i + 3 ;
 
                j = j + 1 ;
            }
        }
 
        szOutput[i]     = (unsigned char)0x20 ;
        szOutput[60]    = (unsigned char)'\0' ;
        szString[j]     = (unsigned char)'\0' ;
 
        printf ("%-60s  %s \n", szOutput, szString) ;
    }
	printf("\n");
}
