#include <stdio.h>
#include <string.h>

#include "aes.h"


void printfDump (const char* p, int len);

int ecb_test()
{
	char key[20];
	char plain[100];
	char cipher[100];
	int len;

	struct aes_context aes_encrypt_ctx;
	struct aes_context aes_decrypt_ctx;

	memset (key, 0x00, sizeof(key));
	memset (plain, 0x00, sizeof(plain));
	memset (cipher, 0x00, sizeof(cipher));

	strcpy (key, "1234567890123456");
	strcpy (plain, "12345678901234567");

	len = strlen(plain);

	printf ("ORG:%s\n", plain);

	aes_set_key(&aes_encrypt_ctx, (unsigned char*)key, 128);
	len = aes_encrypt_ecb_pkcs5 (&aes_encrypt_ctx, (unsigned char*)plain, len, (unsigned char*)cipher, len+16);

	printf ("ENC:%d\n", len);
	printfDump (cipher, len);


	memset (plain, 0x00, sizeof(plain));

	aes_set_key(&aes_decrypt_ctx, (unsigned char*)key, 128);
	len = aes_decrypt_ecb_pkcs5 (&aes_decrypt_ctx, (unsigned char*)cipher, len, (unsigned char*)plain, len);
	printf ("DEC:%d:%s\n", len, plain);
	printfDump (plain, len);

	return 0;
}

int cbc_test()
{
	char key[20];
	char iv[20];
	char plain[100];
	char cipher[100];

	struct aes_cbc_context aes_cbc_encrypt_ctx;
	struct aes_cbc_context aes_cbc_decrypt_ctx;

	int len;

	memset (key, 0x00, sizeof(key));
	memset (iv, 0x00, sizeof(iv));
	memset (plain, 0x00, sizeof(plain));
	memset (cipher, 0x00, sizeof(cipher));

	strcpy (key, "1234567890123456");
	memset (iv, 0x01, 16);
	strcpy (plain, "12345678901234567");


	len = strlen(plain);
	printf ("ORG:%s\n", plain);
	memset (cipher, 0x00, sizeof(cipher));

	aes_set_key_cbc(&aes_cbc_encrypt_ctx, (unsigned char*)key, (unsigned char*)iv);
	len = aes_encrypt_cbc_pkcs5 (&aes_cbc_encrypt_ctx, (unsigned char*)plain, len, (unsigned char*)cipher, len+16);

	printf ("ENC:%d\n", len);
	printfDump (cipher, len);

	memset (plain, 0x00, sizeof(plain));

	aes_set_key_cbc(&aes_cbc_decrypt_ctx, (unsigned char*)key, (unsigned char*)iv);
	len = aes_decrypt_cbc_pkcs5 (&aes_cbc_decrypt_ctx, (unsigned char*)cipher, len, (unsigned char*)plain, len);
	printf ("DEC:%d\n", len);
	printfDump (plain, len);

	return 0;
}

int cbc_file_test()
{
	char key[20];
	char iv[20];

	struct aes_cbc_context aes_cbc_encrypt_ctx;
	struct aes_cbc_context aes_cbc_decrypt_ctx;

	memset (key, 0x00, sizeof(key));
	memset (iv, 0x00, sizeof(iv));

	strcpy (key, "1234567890123456");
	memset (iv, 0x01, 16);


	aes_set_key_cbc(&aes_cbc_encrypt_ctx, (unsigned char*)key, (unsigned char*)iv);
	aes_encrypt_cbc_pkcs5_file (&aes_cbc_encrypt_ctx, "plain.txt", "cipher.txt");

	aes_set_key_cbc(&aes_cbc_decrypt_ctx, (unsigned char*)key, (unsigned char*)iv);
	aes_decrypt_cbc_pkcs5_file (&aes_cbc_decrypt_ctx, "cipher.txt", "plain2.txt");

	return 0;
}


int main(int argc, char* argv[])
{
	ecb_test();

	cbc_test();

	cbc_file_test();

	return 0;
}

void printfDump (const char* p, int len)
{
	unsigned int    coff, roff;
	unsigned int    off;
	char    szOutput[258] ;
	char    szString[128] ;
	unsigned int    i = 0 ;
	unsigned int    j = 0 ;
	unsigned int    base = 16;

	for (roff = 0; roff < (len + base -1)/base; roff++)
	{
		i = 0 ;
		j = 0 ;
		memset(szOutput, 0x20, sizeof(szOutput)) ;
		memset(szString, 0x20, sizeof(szString)) ;

		sprintf(&szOutput[i],"[%04X] :", roff * base);
		i = i + 8 ;
		for (coff = 0; coff < base; coff++)
		{
			off = roff * base + coff;
			if (off < len)
			{
				if (base <= 10)
					sprintf(&szOutput[i], "%02d  ",(unsigned char)p[off]);
				else
					sprintf(&szOutput[i],"%02X  ", (unsigned char)p[off]);

				if ((unsigned char)p[off] < 0x20)
					szString[j] = (unsigned char)'.' ;
				else
					szString[j] = (unsigned char)p[off] ;

				if ((coff % 4) == 3)
					i = i + 4 ;
				else
					i = i + 3 ;

				j = j + 1 ;
			}
		}

		szOutput[i]     = (unsigned char)0x20 ;
		szOutput[60]    = (unsigned char)'\0' ;
		szString[j]     = (unsigned char)'\0' ;

		printf ("%-60s  %s \n", szOutput, szString) ;
	}
}

