#include <CommonType.h>

// �Լ�����
int  TwoWay_Authentication(struct info_st *serverinfo);
void TwoWayAuth_Init(CipherAlgorithmSet cipherAlgorithmSet, struct Auth_Key_st *Auth_Key);
int TwoWayAuthentication1(CipherAlgorithmSet cipherAlgorithmSet, struct Auth_Key_st *Auth_Key, unsigned char *encryptedA);
int TwoWayAuthentication2(CipherAlgorithmSet cipherAlgorithmSet, struct Auth_Key_st *Auth_Key, 
		struct Auth_SDKFromEC_response2_st *Auth_SDKFromEC_response2, unsigned char *encryptedA);
int  TwoWayAuthentication3(int sock, CipherAlgorithmSet cipherAlgorithmSet, struct Auth_Key_st *Auth_Key, 
		struct Auth_SDKFromEC_response4_st *Auth_SDKFromEC_response4);
void message1_send(int sock, unsigned char *Trm_Transaction_ID, unsigned char *encryptedA, int encrypt_len, struct Auth_Key_st *Auth_Key, 
			struct Auth_SDKToEC_request1_st *Auth_SDKToEC_request1);
void message2_send(int sock, unsigned char *Trm_Transaction_ID, unsigned char *encryptedA, int encrypt_len, struct Auth_Key_st *Auth_Key, 
			struct Auth_SDKFromEC_response2_st *Auth_SDKFromEC_response2, struct Auth_SDKToEC_request3_st *Auth_SDKToEC_request3);
int recv_message(int sock,unsigned char *recv_msg,int *header_len);
int recv_parser1(char *msg, struct Auth_SDKFromEC_response2_st *response,int len);
int recv_parser2(char *msg, struct Auth_SDKFromEC_response4_st *response,int len);

int iotmaker_domain_connect(struct info_st *serverinfo, int *socket);
int iotmaker_ip_connect(struct info_st *serverinfo, int *socket);
void createRandom(char *targetPtr, int count);
int  createKeyA(struct Auth_Key_st *Auth_Key);
int  createKeyB(struct Auth_Key_st *Auth_Key);
int  FutureKey_File_Read(unsigned char *keySetFilePath, unsigned char *configFilePath);
int  FutureKey_File_Write(unsigned char *keySetFilePath,unsigned char *OutPut);
int encrypt(AuthCrypt *pCrypt, unsigned char *key, unsigned char *plain, int plain_len, unsigned char *encrypt);
int aesEncryptCBC_128(unsigned char *key, unsigned char *plain, int plain_len, unsigned char *encrypt, unsigned char *sInitVector);
int aesEncryptCBC_256(unsigned char *key, unsigned char *plain, int plain_len, unsigned char *encrypt, unsigned char *sInitVector);
void aesEncryptCTR_128(unsigned char *key, unsigned char *plain, int plain_len, unsigned char *encrypt);
int decrypt(AuthCrypt *pCrypt, unsigned char *key, unsigned char *encrypt, int encrypt_len, unsigned char *plain);
int aesDecryptCBC_128(unsigned char *key, unsigned char *encrypt, int encrypt_len, unsigned char *plain, unsigned char *sInitVector);
int aesDecryptCBC_256(unsigned char *key, unsigned char *encrypt, int encrypt_len, unsigned char *plain, unsigned char *sInitVector);
void aesDecryptCTR_128(unsigned char *key, unsigned char *encrypt, int encrypt_len, unsigned char *plain);
void AuthCryptSet(CipherAlgorithmSet cipherAlgorithmSet_tmp, AuthCrypt *pCrypt);
void setEncryptMethod(CipherAlgorithmSet cipherAlgorithmSet_tmp, AuthCrypt *pCrypt);
int  getTicketFromB(unsigned char *decryptedB, unsigned char *ticket, int length);
int  getS_3FromB(unsigned char *decryptedB, unsigned char *seqnum, int length);
int  testserver_connect(struct info_st *serverinfo, int *iot_socket);
