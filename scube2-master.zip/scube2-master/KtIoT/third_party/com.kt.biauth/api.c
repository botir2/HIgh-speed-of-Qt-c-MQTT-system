#include <stdio.h> 
#include <stdlib.h> 
#include <stdarg.h> 
#include <string.h> 
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

#include "define.h"
#include "api.h"

//======================= keyserverinfo file manage =================================
//----------------------------------------------------
// serverinfo ������ ���� ��� ����
// �������� : EC���� url, ��� port
//----------------------------------------------------
int serverinfofilecreate(char *strfile, struct info_st *serverinfo)
{
	int ret = 0;
	FILE *fp;
	char *iotserverurl = "int01.local.gigaeyes.paran.com";
	int  iotserverport = 10020;
	char *iotserverip = "211.54.3.141";
	fp = fopen(strfile , "w+");
	if(fp==NULL) {
		printf("file create fail\n");
		ret = ERR;
	} else {
		sprintf(serverinfo->iotserverurl,"%s",iotserverurl);
		serverinfo->iotserverport = iotserverport;
		sprintf(serverinfo->iotserverip,"%s",iotserverip);
		fprintf(fp,"%s\n",iotserverurl);
		fprintf(fp,"%d\n",iotserverport);
		fprintf(fp,"%s\n",iotserverip);
		fclose(fp);
		if(DEBUG) printf("create %s,%d,%s\n",serverinfo->iotserverurl,serverinfo->iotserverport,serverinfo->iotserverip);
		ret = 1;
	}
	
	return ret;
}

//----------------------------------------------------
// serverinfo ���Ͽ��� char ���ڿ����� CR,LF,00 �ΰ�� ������ó��
// �������� : EC���� url, ��� port
//----------------------------------------------------
void linefeeddel(char *strtemp,int len)
{
	int i=0;
	for(i=0;i<len;i++) {
		if((strtemp[i]==0x0a) || (strtemp[i]==0x0d) || (strtemp[i]==0x00)) {
			strtemp[i]='\0';
			break;
		}
	}
}

//----------------------------------------------------
// serverinfo ������ ������ ���δ����� READ
// �������� : EC���� url, ��� port
//----------------------------------------------------
int serverinfofileread(char *strfile, struct info_st *serverinfo)
{
	int i=0;
	int ret = 0;
	FILE *fp;
	char *strtemp;
	size_t len = 0;
	fp = fopen(strfile , "r");
	if(fp==NULL) {
		printf("file create fail\n");
		ret = ERR;
	} else {
		getline(&strtemp,&len,fp);
		linefeeddel(strtemp,len);
		sprintf(serverinfo->iotserverurl,"%s",strtemp);

		getline(&strtemp,&len,fp);
		linefeeddel(strtemp,len);
		serverinfo->iotserverport = atoi(strtemp);
		
		getline(&strtemp,&len,fp);
		linefeeddel(strtemp,len);
		sprintf(serverinfo->iotserverip,"%s",strtemp);

		fclose(fp);
		if(DEBUG) printf("read %s,%d,%s\n",serverinfo->iotserverurl,serverinfo->iotserverport,serverinfo->iotserverip);
		ret = 1;
	}
	
	return ret;
}
//----------------------------------------------------
// serverinfo ���������� üũ�Ͽ� ���¸� ����, ������ �д´�. 
// �������� : EC���� url, ��� port
//----------------------------------------------------
int serverinfofilecheck(struct info_st *serverinfo)
{
	char *strfile = SERVERINFOFILE;
	
	int ret = access(strfile, F_OK );
  
    if( ret == -1 )
    {
        printf( "keyserver serverinfo file no find\n" );
		ret = serverinfofilecreate(strfile, serverinfo);
    } else {
		ret = serverinfofileread(strfile, serverinfo);
	}
 
    return ret;

}

//======================= string ���� �Լ� ====================================
//----------------------------------------------------
// string �ΰ�� ���̸� �˾ƿ��� �Լ�. 
// 
//----------------------------------------------------
int stringsize(unsigned char *stringdata,int len)
{
	int i=0;
	for(i=0;i<len;i++) {
		if(stringdata[i]==0x00) break;
	}
	len = i;
	return len;
}

//----------------------------------------------------
// string�� hex������ ��ȯ�Լ�. 
// 12 => 0x12
//----------------------------------------------------
int strtohex(unsigned char *stringdata, unsigned char *hexdata, int len)
{
	int i=0;
	unsigned char data;
	for(i=0;i<len;i++) {
		if((stringdata[i]>=0x30) && (stringdata[i]<=0x39)) {
			data = stringdata[i]&0x0f;
		} else if((stringdata[i]>=0x40) && (stringdata[i]<=0x46)) {
			data = stringdata[i]-0x37;
		} else if((stringdata[i]>=0x60) && (stringdata[i]<=0x66)) {
			data = stringdata[i]-0x57;
		}
		if(i%2) {
			hexdata[i/2] |= (data<<0);
		} else {
			hexdata[i/2] = (data<<4);
		}
	}
	return len/2;
}

//----------------------------------------------------
// string�� hex������ ��ȯ�Լ�. 
// 12 => 0x12
//----------------------------------------------------
int hextostr(unsigned char *hexdata, unsigned char *stringdata, int len)
{
           int i=0;
           unsigned char data;
           for(i=0;i<len;i++) {
                      data = (hexdata[i]&0xf0)>>4;
                      if((data>=0) && (data<=9)) stringdata[i*2] = data+0x30;
                      else if((data>=0x0a) && (data<=0xf)) stringdata[i*2] = data+0x57;
                      data = (hexdata[i]&0x0f);
                      if((data>=0) && (data<=9)) stringdata[i*2+1] = data+0x30;
                      else if((data>=0x0a) && (data<=0xf)) stringdata[i*2+1] = data+0x57;
           }
           
           return len*2;
}

//======================= futurekey ���� ���� ====================================
//----------------------------------------------------
// futurekey file ����Ȯ��
// 
//----------------------------------------------------
int futurekeyfilecheck(unsigned char *keytablename)
{
	int ret = access(keytablename, F_OK );
  
    if( ret == -1 )
    {
        if(DEBUG) printf( "futurekey file no find\n" );
    } else {
		if(DEBUG) printf( "futurekey file find\n" );
	}
	return ret;
}

//----------------------------------------------------
// futurekey file read
// 
//----------------------------------------------------
int futurekeyfileread(unsigned char *keytablename, unsigned char *futurekey, int len)
{
	int ret = 0;
	int size = 0;
	FILE *fp;
	unsigned char ch;
	
	fp = fopen(keytablename , "rb");
	if(fp==NULL) {
		printf("file open fail\n");
		ret = ERR;
	} else {
		fseek(fp,0L,SEEK_END);
		size = ftell(fp);
		if(size>0 && size<=len) {
			fseek(fp,0L,SEEK_SET);
			fread(futurekey,1,size,fp);
		}
		fclose(fp);
		ret = size;
		
	}
	return ret;

}

//----------------------------------------------------
// futurekey file save
// 
//----------------------------------------------------
int futurekeyfilesave(unsigned char *keytablename, unsigned char *futurekey, int len)
{
	int i=0;
	int ret = 0;
	FILE *fp;
	unsigned char ch;
	
	fp = fopen(keytablename , "wb+");
	if(fp==NULL) {
		printf("file open fail\n");
		ret = ERR;
	} else {
		fwrite(futurekey,1,len,fp);
		fclose(fp);
		ret = 1;
		printf("\n");
	}
	return ret;

}
