/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright �� 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_BASE_H
#define IOTMAKERS_BASE_H

#include "im_common.h"
#include "packet/packet.h"

#if defined(_IM_C_MQTT_)
#include "org.eclipse.paho.mqtt.c/src/MQTTClient.h"
#endif


#if defined(CIPHER_AES128CBC) || defined(CIPHER_AES256CBC)
#include "aes.h"
#elif defined(CIPHER_ARIA128CBC)
#include "aria.h"
int im_base_set_aria_key(unsigned char *key_hexstring)
#endif

/*
 * IoTMakers Client Instance
 *
 */
typedef struct IMBase_t {
	char			ip[IOTMAKERS_STR_64_BYTE_LEN + 1];
	unsigned short	port;

	char			extrSysId[IOTMAKERS_STR_30_BYTE_LEN + 1];
	char			deviceId[IOTMAKERS_STR_64_BYTE_LEN + 1];
	char			athnRqtNo[IOTMAKERS_STR_64_BYTE_LEN + 1];
	char			log_file_name[IOTMAKERS_STR_128_BYTE_LEN + 1];

	char			commChAthnNo[IOTMAKERS_STR_64_BYTE_LEN + 1];
	int				isChAthnSuccess;

#if defined(_IM_C_MQTT_)
	MQTTClient		mqttClient;
	char			mqttTopic4Pub[IOTMAKERS_STR_64_BYTE_LEN + 1];
	char			mqttTopic4Sub[IOTMAKERS_STR_64_BYTE_LEN + 1];
#elif defined(_IM_C_SOCK_)
	int				sock;
	int				sock_timeout_sec;
	int				keepAliveExpireTime;
#endif

#if defined(CIPHER_AES128CBC) || defined(CIPHER_AES256CBC)
    struct aes_cbc_context aes_cbc_ctx;
	unsigned char	aes_key_string[40];
#elif defined(CIPHER_ARIA128CBC)
    AriaContext aria_cbc_ctx;
	unsigned char	aria_key_string[40];
#endif


	unsigned long	pktCountRecv;
	unsigned long	pktCountSent;

	int				isServiceMode;
	int				isRecvLoopStop;
	int				lastErrorCode;

	IMCbErrorHndl			cb_error_hndl;

} IMBase, *IMBasePtr;

/*
 * ********************************************************************************
 * base.h
 * ********************************************************************************
 */

#ifdef __cplusplus
extern "C"
{
#endif

int im_base_init(char *ip, int port, char *extrSysId, char *deviceId, char *athnRqtNo, char *log_file_name);
void im_base_release() ;
char* im_base_get_ip() ;
int im_base_get_port() ;
char* im_base_get_extrSysId() ;
char* im_base_get_deviceId() ;
char* im_base_get_athnRqtNo() ;
char* im_base_get_log_file_name() ;
char* im_base_get_commChAthnNo() ;
int im_base_set_commChAthnNo(char *respAthnNo) ;
int im_base_is_ChAthnSuccess();

void* im_base_get_mqttc() ;
void im_base_set_mqttc() ;
char* im_base_get_mqttTopic4Pub();
void im_base_set_mqttTopic4Pub(char *topic);
char* im_base_get_mqttTopic4Sub();
void im_base_set_mqttTopic4Sub(char *topic);

int im_base_get_sock() ;
void im_base_set_sock(int sock) ;
int im_base_get_sockTimeoutSec() ;
int im_base_set_sockTimeoutSec(int sec);
int im_base_get_keepAliveExpireTimeSec() ;
int im_base_set_keepAliveExpireTimeSec(int sec) ;

unsigned long im_base_get_pktCountRecv() ;
void im_base_inc_pktCountRecv() ;
unsigned long im_base_get_pktCountSent() ;
void im_base_inc_pktCountSent() ;

void im_base_set_ServiceModeStart();
void im_base_set_ServiceModeStop() ;
int im_base_is_ServiceMode();

void im_base_set_recvLoopStart() ;
void im_base_set_recvLoopStop() ;
int im_base_get_isRecvLoopStop() ;

int im_base_get_lastErrorCode() ;
void im_base_set_lastErrorCode(IM_ErrCode lastErrorCode) ;


#ifdef __cplusplus
}
#endif


#endif
