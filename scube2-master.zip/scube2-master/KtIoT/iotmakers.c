/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

#include "im_common.h"
#include "iotmakers.h"
#include "base/base.h"
#include "util/thread.h"
#include "util/util.h"
#include "util/log.h"


#if  defined (_IM_C_SOCK_) 
#include "netio/sock.h"
#elif defined (_IM_C_MQTT_) 
#include "netio/mqtt.h"
#endif

static	unsigned long	g_keepalive_sec;
static	unsigned long	g_sent_count;
mutex_type		g_sock_mutex;

void im_error_handler(int errcode)
{
	IMCbErrorHndl cb_error_handler = (IMCbErrorHndl)im_base_get_cb_error_hndler();
	if ( cb_error_handler != NULL )	{
		cb_error_handler(errcode);
	}
}

char* im_version_string()
{
    return IOTMAKERS_SDK_C_VERSION; 
}

/*
 * im_init
 */
int im_init(char *ip, int port, char *deviceId, char *athnRqtNo, char *extrSysId, char *log_file_name)
{
	int rc = 0;
	
	rc = im_base_init(ip, port, extrSysId, deviceId, athnRqtNo, log_file_name);
	if ( rc < 0 )	{
		return -1;
	}

	im_log_init((char*)im_base_get_log_file_name());
	im_log_set_level(LOG_LEVEL_INFO);
	
    g_keepalive_sec = im_util_gettimeofday_as_sec(); 

    INFO_LOG("version: %s", IOTMAKERS_SDK_C_VERSION);                         
    INFO_LOG("server_ip: %s", ip);                         
    INFO_LOG("server_port: %d", port);                     
    INFO_LOG("deviceId: %s", deviceId);             
    INFO_LOG("athnRqtNo: %s", athnRqtNo);        
    INFO_LOG("extrSysId: %s", extrSysId);           
    INFO_LOG("log_file_name: %s", log_file_name);   

	return 0;
}

int im_init_with_config_file(char *fname)
{
	char			ip[IOTMAKERS_STR_64_BYTE_LEN + 1];
	unsigned short	port;
	char			extrSysId[IOTMAKERS_STR_30_BYTE_LEN + 1];
	char			deviceId[IOTMAKERS_STR_64_BYTE_LEN + 1];
	char			athnRqtNo[IOTMAKERS_STR_64_BYTE_LEN + 1];
	char			log_file_name[IOTMAKERS_STR_128_BYTE_LEN + 1];

	int rc = im_util_read_config(fname,
			ip, &port,
			extrSysId,
			deviceId,
			athnRqtNo, log_file_name);

	if (rc < 0)	{
		return -1;
	}

	return im_init(ip, port, deviceId, athnRqtNo, extrSysId, log_file_name);
}

void im_release() 
{
	im_base_release();
	im_log_close();
	return;
}

int im_get_LastErrCode()
{
	return im_base_get_lastErrorCode();
}

void im_set_loglevel(int loglevel)
{
	if ( loglevel <= LOG_LEVEL_ERROR )	{
		im_log_set_level(LOG_LEVEL_ERROR);
	} else if ( loglevel >= LOG_LEVEL_DEBUG )	{
		im_log_set_level(LOG_LEVEL_DEBUG);
	} else {
		im_log_set_level(loglevel);
	}
}

#if  defined (_IM_C_SOCK_) 
void im_set_socktimeout_sec(int sec)
{
	im_base_set_sockTimeoutSec(sec);
}
#endif

/*
 * im_settings callback - user data
 */

void im_set_error_handler(IMCbErrorHndl cb_proc)
{
	im_base_set_cb_error_hndler(cb_proc);
}

/*
 * im_connect
 */
void im_disconnect()
{
#if  defined (_IM_C_MQTT_) 
	im_mqtt_disconnect(im_base_get_mqttc());
#elif defined (_IM_C_SOCK_) 
	im_sock_disconnect(im_base_get_sock());
	im_base_set_sock(-1);
#endif

	if ( g_sock_mutex != NULL ){
		im_thread_destroy_mutex(g_sock_mutex);
		g_sock_mutex = NULL;
	}
}


static void __imcb_recv_data_handler(char *data, int data_len)
{
	im_action_recved_data_handler(data, data_len);
}


int im_connect()
{
	int conn_timeout_sec = (IOTMAKERS_SOCKET_TIMEOUT_SEC);

#if  defined (_IM_C_MQTT_) 
	int rc;
	rc = im_mqtt_connect_timeout(im_base_get_mqttc(), im_base_get_ip(), im_base_get_port(), 
		im_base_get_deviceId(), conn_timeout_sec);
	if ( rc < 0 )	{
		ERROR_LOG("fail im_mqtt_connect()");
		im_base_set_lastErrorCode(IM_ErrCode_SOCK_CONNECTION_FAIL);
		im_error_handler(IM_ErrCode_SOCK_CONNECTION_FAIL);
		return -1;
	}
	im_mqtt_set_cb_recv_handler(__imcb_recv_data_handler);

#elif defined (_IM_C_SOCK_) 
	int sock = -1;

	if ( im_base_get_sock() > 0 )	{
		im_disconnect();
	}

#if defined(_IM_C_SSL_)
    sock = im_ssl_connect_timeout(im_base_get_ip(), im_base_get_port(), conn_timeout_sec);
#else
    sock = im_sock_connect_timeout(im_base_get_ip(), im_base_get_port(), conn_timeout_sec);
#endif
	if ( sock <= 0 )	{
		im_base_set_lastErrorCode(IM_ErrCode_SOCK_CONNECTION_FAIL);
		im_error_handler(IM_ErrCode_SOCK_CONNECTION_FAIL);
		return -1;
	}

    im_base_set_sock(sock);
	im_sock_set_timeout(im_base_get_sockTimeoutSec());
	im_sock_set_cb_recv_handler(__imcb_recv_data_handler);
#endif

	g_sock_mutex = im_thread_create_mutex();
	return 0;
}

int im_connected()
{
#if defined (_IM_C_SOCK_) 
#if defined(_IM_C_SSL_)
	return (im_ssl_disconnect() >= 1)?1:0;
#else
	return (im_sock_connected() >= 1)?1:0;
#endif
#endif

}


int im_loop()
{
#if defined (_IM_C_SOCK_) || defined (_IM_C_SSL_)

	if ( im_util_gettimeofday_as_sec() - g_keepalive_sec >  IOTMAKERS_KEEPALIVE_EXPIRE_TIME_SEC)	{
		g_keepalive_sec = im_util_gettimeofday_as_sec(); 
        if ( g_sent_count == im_base_get_pktCountSent() )        {
            if ( im_send_keepalive() < 0 )        {
                return -1;
            };
        }
		g_sent_count = im_base_get_pktCountSent(); 
	}

	while ( im_sock_available() >= (1) )
	{
		if ( im_action_recv_packet() < 0 )		{
			return -1;
		};
	}
#endif
	DEBUG_LOG("sent=[%ld]pkts, recv=[%ld]pkts", im_base_get_pktCountSent(), im_base_get_pktCountRecv());
	return 0;
}



/*
 * thread loop 
 */
static thread_return_type WINAPI __th_recv_loop(void *arg)
{
	int rc = 0;

	im_base_set_recvLoopStart();
	im_base_set_ServiceModeStart();

	g_keepalive_sec = im_util_gettimeofday_as_sec(); 
	while ( im_base_get_isRecvLoopStop() != (1) )
	{
		if ( im_loop() < 0 )		{
#if defined (_IM_C_SOCK_)
			im_sock_disconnect();
#elif defined(_IM_C_SSL_)
			im_ssl_disconnect();
#endif
			break;
		}
		// to avoid busy_wait
		sleep(1);
	}

	im_base_set_ServiceModeStop();
	INFO_LOG("done recv_loop.");
}

static int __im_start_recv_loop_thread()
{
	int rc;
    int thr_id  = (int)im_thread_start(__th_recv_loop, (void *)NULL);

	return 0;
}

static void __im_stop_recv_loop()
{
	im_base_set_recvLoopStop();
	im_base_set_ServiceModeStop();
}

int im_start_service()
{
	int rc;

	// 1. connect
	rc = im_connect();
	if ( rc < 0  )	{
        ERROR_LOG("fail im_connect()");
		return -1;
	}

#if  defined (_IM_C_MQTT_) 
	im_base_set_mqttTopic4Sub(im_base_get_deviceId());
	im_base_set_mqttTopic4Pub(im_base_get_deviceId());
	rc = im_mqtt_subscribe_topic(im_base_get_mqttc(), im_base_get_mqttTopic4Sub());
	if ( rc < 0)	{
		ERROR_LOG("fail im_mqtt_subscribe_topic(), topic=[%d]", im_base_get_mqttTopic4Sub());
		goto exit_on_error;
	}
#endif
 
	// 2. do looper
	im_base_set_ServiceModeStart();
	rc = __im_start_recv_loop_thread();
	if ( rc < 0 )	{
        ERROR_LOG("fail __im_start_recv_loop_thread()");
		goto exit_on_error;
	}

	// 3. do im_auth_device
	rc = im_auth_device();
	if ( rc < 0 )	{
        ERROR_LOG("fail im_auth_device()");
		goto exit_on_error;
	}

#if  defined (_IM_C_MQTT_) 
	im_mqtt_unsubscribe_topic(im_base_get_mqttc(), im_base_get_mqttTopic4Sub());
	im_base_set_mqttTopic4Sub(im_base_get_commChAthnNo());
	im_base_set_mqttTopic4Pub(im_base_get_commChAthnNo());
	rc = im_mqtt_subscribe_topic(im_base_get_mqttc(), im_base_get_mqttTopic4Sub());
	if ( rc < 0)	{
		ERROR_LOG("fail im_mqtt_subscribe_topic(), topic=[%d]", im_base_get_commChAthnNo());
		goto exit_on_error;
	}
#endif	
	return 0;

exit_on_error:
	__im_stop_recv_loop();	
	im_disconnect();
	return -1;
}

void im_stop_service()
{
	__im_stop_recv_loop();
	im_disconnect();
}


/*
 * im_send_data
 */
long long im_get_new_trxid()
{
	return (long long)im_util_get_unique_number();
}

