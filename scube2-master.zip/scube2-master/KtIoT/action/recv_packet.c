/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <string.h>
#include <stdlib.h>

#include "iotmakers.h"
#include "base/base.h"
#include "util/log.h"
#include "packet/head/head.h"
#include "packet/body/body.h"
#include "packet/packet.h"
#include "action/action.h"
#include "util/thread.h"

#if  defined (_IM_C_SOCK_) 
#include "netio/sock.h"
#endif

extern mutex_type g_sock_mutex;


static char g_buff[IOTMAKERS_MAX_RECV_MSG_LEN];     // 4096 bytes


static void im_action_recv_packet_handler(IMPacketPtr pkt)
{
	IMPacketHeadPtr head = im_packet_get_head(pkt);
	MthdType methodType = (MthdType)im_pktHead_get_methodType(head);
	switch (methodType)
	{
	case MthdType_ATHN_COMMCHATHN_DEV_TCP:		// 224
DEBUG_LOG("MthdType_ATHN_COMMCHATHN_DEV_TCP methodType[%d]", methodType);
		im_224_res_pkt_handler(pkt);
		break;
#if  defined (_IM_C_SOCK_) 
	case MthdType_KEEP_ALIVE_COMMCHATHN_TCP:	// 231
		im_231_res_pkt_handler(pkt);
		break;
#endif
	case MthdType_COLEC_ITGDATA_RECV:			// 411
		im_411_res_pkt_handler(pkt);
		break;
	case MthdType_CONTL_ITGCNVY_DATA:			// 525
		im_525_req_pkt_handler(pkt);
		break;
/*
    case MthdType_INITA_DEV_UDATERPRT:			// 332
		im_if332_resp_handler(pkt);
		break;
	case MthdType_LAST_VAL_QUERY:			// 711
		im_action_query_last_req_handler(pkt);
		break;
	case MthdType_INITA_DEV_INFO:			// 333
		im_action_if333_req_handler(pkt);
		break;
*/	
	default:
		ERROR_LOG("Unknown methodType[%d]", methodType);
		im_base_set_lastErrorCode(IM_ErrCode_PACKET_UNKNOWN);
		im_error_handler(IM_ErrCode_PACKET_UNKNOWN);
	}
}

static unsigned long __read_packet_length()
{
	unsigned long pktLen = -1;
#if defined(_IM_C_SOCK_)
#if defined(_IM_C_SSL_)
	if ( im_ssl_recv((char*)&pktLen, 4) < 0 )	{
		return 0;
	};
#else
    if ( im_sock_recv((char*)&pktLen, 4) < 0 )	{
		return 0;
	};
#endif
#endif

    pktLen = ntohl(pktLen);
	return pktLen;
}



static int __recv_data_to_buff(char* buff)
{
	int readLen = 0;
	int packetLength = 0;

#if defined(_IM_C_SOCK_)
	packetLength = __read_packet_length();
	DEBUG_LOG("packetLength=[%d].", packetLength);
	if ( packetLength < 35 || packetLength > 2048)	{
		ERROR_LOG("pkt_size:[%d]", packetLength);
		im_base_set_lastErrorCode(IM_ErrCode_SOCK_RECV_FAIL);
		im_sock_flush();
		return -1;
	}
#if defined(_IM_C_SSL_)
	readLen = im_ssl_recv(buff, packetLength);
#else
	readLen = im_sock_recv(buff, packetLength);
#endif
	if ( readLen != packetLength )	{
		ERROR_LOG("pkt_size:[%ld]", packetLength);
		im_base_set_lastErrorCode(IM_ErrCode_SOCK_RECV_FAIL);
		im_sock_flush();
		return -1;
	}
#endif
	return packetLength;
}

int im_action_recved_data_handler(char *data, int datalen) 
{
	IMPacket pkt;
	IMPacketHead head;
	IMPacketBody body; 
    int rc = 0;

	if ( datalen <= 0 )	{
		ERROR_LOG("no data to process");
		return -1;
	}

DEBUG_LOG("{{{");
	DEBUG_LOG("[%d]bytes received", datalen);
	im_log_write_hex((unsigned char*)data, datalen);	

    im_pktHead_init(&head);
    im_pktBody_init(&body);
	im_packet_init_with(&pkt, &head, &body);

#if defined(_IM_C_MQTT_)
    // don't need the first 4 bytes
    rc = im_packet_get_deserialized_from_buff(&pkt, data+4, datalen-4);
#else
    rc = im_packet_get_deserialized_from_buff(&pkt, data, datalen);
#endif
	if ( rc >= 0 )	{
		im_action_recv_packet_handler(&pkt);
	}else{
	    ERROR_LOG("fail im_packet_get_deserialized_from_buff()");
    }

	im_base_inc_pktCountRecv();

	im_pktHead_release(&head);
	im_pktBody_release(&body);
	im_packet_release(&pkt);
DEBUG_LOG("}}}");
    return rc;
}


int im_action_recv_packet_with_handler( unsigned long long txIdOfHead, IMCBResPktHndl res_pkt_handler)
{
	IMPacket pkt;
	IMPacketHead head;
	IMPacketBody body; 
    int rc;

#if defined(_IM_C_MQTT_)
    return 0;
#endif

	im_thread_lock_mutex(g_sock_mutex);


    int packetLength = __recv_data_to_buff(g_buff);
    if ( packetLength < 0 ) {
		im_thread_unlock_mutex(g_sock_mutex);
        return -1;
    } else if ( packetLength == 0 ) {
        // noti caller that their is no packet to process.
        res_pkt_handler(NULL);
		im_thread_unlock_mutex(g_sock_mutex);
        return -1;
    }

		im_thread_unlock_mutex(g_sock_mutex);

DEBUG_LOG("[[[");
	DEBUG_LOG("[%d]bytes received", packetLength);
	im_log_write_hex((unsigned char*)g_buff, packetLength);	

    im_pktHead_init(&head);
    im_pktBody_init(&body);
	im_packet_init_with(&pkt, &head, &body);

    rc = im_packet_get_deserialized_from_buff(&pkt, g_buff, packetLength);
    if ( rc < 0 )	{
        im_pktHead_release(&head);
        im_pktBody_release(&body);
        im_packet_release(&pkt);

        // noti caller that their is no packet to process.
        res_pkt_handler(NULL);
        return -1;        
    }

	im_base_inc_pktCountRecv();

    rc = 0;
    unsigned long long txIdOfHeadReq = (unsigned long long)im_pktHead_get_trmTransacId((IMPacketHeadPtr)pkt.head);

    if ( txIdOfHeadReq == txIdOfHead && res_pkt_handler != NULL ) {
		res_pkt_handler(&pkt);
    } else {
		im_action_recv_packet_handler(&pkt);
    }

	im_pktHead_release(&head);
	im_pktBody_release(&body);
	im_packet_release(&pkt);

DEBUG_LOG("]]]");
    return rc;
}

int im_action_recv_packet()
{
    return im_action_recv_packet_with_handler(0, NULL);
}

