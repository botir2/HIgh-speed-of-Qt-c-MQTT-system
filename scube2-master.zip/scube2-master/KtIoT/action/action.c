/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include "util/log.h"
#include "packet/head/head.h"
#include "packet/body/body.h"
#include "packet/packet.h"

int im_action_do_send_pkt(IMPacketPtr pReqPkt)
{
    int rc = 0;
    IMPacketPtr pResPkt;

    rc =  im_action_send_packet(pReqPkt);

    return rc;
}

int im_action_do_req_pkt(IMPacketPtr pReqPkt, IMCBResPktHndl res_pkt_handler)
{
    int rc = 0;
    IMPacketPtr pResPkt;

    rc =  im_action_send_packet(pReqPkt);

    rc += im_action_recv_packet_with_handler( im_pktHead_get_trmTransacId(pReqPkt->head), res_pkt_handler);

    return rc;
}
