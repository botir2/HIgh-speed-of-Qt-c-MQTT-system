#include <stdio.h>

#include "base/base.h"
#include "util/log.h"

#include "third_party/com.kt.biauth/api.h"
#include "third_party/com.kt.biauth/define.h"
#include "third_party/com.kt.biauth/twoway_authentication.h"

int __ifxxx_auth_device_ktbi(char* keyFile)
{
	int i=0;
	int iot_socket=0;
	int result=0;

    TwoWayAuthenticationResults		twoWayAuthenticationResults;
	CipherAlgorithmSet cipherAlgorithmSet = AES_128_CBC;
	int messageType = 1;
	unsigned char recv_msg[BUF_SIZE];
	int recv_msg_len=0;
	int recv_msg_header_len = 0;
	unsigned char encryptedA[1024];
	int encryptedA_len=0;
	unsigned char Trm_Transaction_ID[8];

	struct Auth_Key_st					Auth_Key;
	struct Auth_SDKToEC_request1_st 	Auth_SDKToEC_request1;
	struct Auth_SDKFromEC_response2_st	Auth_SDKFromEC_response2;
	struct Auth_SDKToEC_request3_st 	Auth_SDKToEC_request3;
	struct Auth_SDKFromEC_response4_st 	Auth_SDKFromEC_response4;
	
	memset(encryptedA,0,sizeof(encryptedA));
	memset(Trm_Transaction_ID,0,sizeof(Trm_Transaction_ID));
	memset(&Auth_Key,0,sizeof(Auth_Key));
	memset(&Auth_SDKToEC_request1,0,sizeof(Auth_SDKToEC_request1));
	memset(&Auth_SDKFromEC_response2,0,sizeof(Auth_SDKFromEC_response2));
	memset(&Auth_SDKToEC_request3,0,sizeof(Auth_SDKToEC_request3));
	memset(&Auth_SDKFromEC_response4,0,sizeof(Auth_SDKFromEC_response4));

    /* kcshin 2016-10-24 */
    sprintf(Auth_Key.keyFile,"%s", keyFile);
    iot_socket = im_base_get_sock();

	createRandom(Trm_Transaction_ID, sizeof(Trm_Transaction_ID));
	TwoWayAuth_Init(cipherAlgorithmSet,&Auth_Key);

	encryptedA_len = TwoWayAuthentication1(cipherAlgorithmSet, &Auth_Key, encryptedA);
	if(encryptedA_len < 0) {
		ERROR_LOG("TwoWayAuthentication1");
		return AUTH_ERR_ENCRYPT;
	}

	message1_send(iot_socket, Trm_Transaction_ID, encryptedA, encryptedA_len, &Auth_Key, &Auth_SDKToEC_request1);
	memset(recv_msg,0,sizeof(recv_msg));

	if(DEBUG) {
		ERROR_LOG("recv message wait\n");
	}

	recv_msg_len = recv_message(iot_socket,recv_msg,&recv_msg_header_len);
	if(recv_msg_len<=0) {
		ERROR_LOG("recv_message");
		return AUTH_ERR_SOCKET_RECV;
	}

	result = recv_parser1(&recv_msg[recv_msg_header_len+4],&Auth_SDKFromEC_response2, recv_msg_len);
	if(result<0) {
		ERROR_LOG("recv_parser1");
		return result;
	}

	memset(encryptedA,0,sizeof(encryptedA));
	encryptedA_len = TwoWayAuthentication2(cipherAlgorithmSet, &Auth_Key, &Auth_SDKFromEC_response2, encryptedA);
	if(encryptedA_len<0) {
		ERROR_LOG("TwoWayAuthentication2");
		return result;
	}

	message2_send(iot_socket, Trm_Transaction_ID, encryptedA, encryptedA_len, &Auth_Key, &Auth_SDKFromEC_response2,&Auth_SDKToEC_request3);

	memset(recv_msg,0,sizeof(recv_msg));
	if(DEBUG) {
		printf("recv message wait2\n");
	}

	recv_msg_len = recv_message(iot_socket,recv_msg,&recv_msg_header_len);
	if(recv_msg_len<=0) {
		ERROR_LOG("recv_message 2");
		return AUTH_ERR_SOCKET_RECV;
	}

	result = recv_parser2(&recv_msg[recv_msg_header_len+4],&Auth_SDKFromEC_response4, recv_msg_len);
	if(result<0) {
		ERROR_LOG("recv_parser2");
		return result;
	}

	result = TwoWayAuthentication3(iot_socket, cipherAlgorithmSet, &Auth_Key, &Auth_SDKFromEC_response4);
	if(result<0) {
		ERROR_LOG("TwoWayAuthentication3");
		return result;
	}

    /* kcshin 2016-10-24 */
	result = im_base_set_commChAthnNo(Auth_SDKFromEC_response4.athnNo);
	if ( result < 0 )	{
		ERROR_LOG("im_base_set_commChAthnNo");
		return -1;
	}

	LOG("The device channel has been authenticated. [%s]", (char*)im_base_get_commChAthnNo());

	return result;
}


int im_auth_device_ktbi(char* key_file)
{
    if ( key_file == NULL ) {
    	return __ifxxx_auth_device_ktbi(FUTUREKEYFILE);
    }

  	return __ifxxx_auth_device_ktbi(key_file);
}

