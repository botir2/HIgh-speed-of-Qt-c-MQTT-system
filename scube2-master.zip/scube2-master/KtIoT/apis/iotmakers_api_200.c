/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <stdio.h>

#include "base/base.h"
#include "util/log.h"
#include "packet/packet.h"


/* ==============================
 * im_auth_device
 * ============================== */
#include "packet/body/body224.h"
#include "packet/head/head224.h"

int im_224_res_pkt_handler(IMPacketPtr respPkt)
{
	int rc = 0;
	IMPacketBodyPtr body = NULL;
	char *athnNo = NULL;

    if ( respPkt == NULL ) {
		ERROR_LOG("no packet to process");
		return -1;
    }

	body = im_packet_get_body(respPkt);
    if ( body == NULL ) {
		ERROR_LOG("no body to process");
		return -1;
    }

	athnNo = im_body224_req_get_athnNo(body);
	if ( athnNo == NULL ){
		ERROR_LOG("no name[%s] in the body", "athnRqtNo");
		return -1;
	}

	rc = im_base_set_commChAthnNo(athnNo);
	if ( rc < 0 )	{
		ERROR_LOG("invalid athnNo=[%s] received", athnNo);
		return -1;
	}
	INFO_LOG("The device channel has been authenticated. [%s]", (char*)im_base_get_commChAthnNo());

	return 0;
}

static int __if224_auth_device_Sync()
{
	int rc = 0;

	IMPacket pkt;
	IMBody224Req  body224;
	IMHead224Req  head224;

	im_head224_req_init(&head224);
    im_body224_req_init(&body224);

	im_body224_req_set_extrSysId(&body224, im_base_get_extrSysId());
	im_body224_req_set_devId(&body224, im_base_get_deviceId());
	im_body224_req_set_athnRqtNo(&body224, im_base_get_athnRqtNo());

	im_packet_init_with(&pkt, &head224.head, &body224.body);
    // sync
    rc = im_action_do_req_pkt(&pkt, im_224_res_pkt_handler);

    im_body224_req_release(&body224);
    im_head224_req_release(&head224);
	im_packet_release(&pkt);


#if defined (_IM_C_MQTT_) 
	int authWaitSec = 3;
	while ( im_base_is_ChAthnSuccess() != (1) )	{
		if ( authWaitSec-- <= 0 )	{
			ERROR_LOG("fail im_base_is_ChAthnSuccess()");
			return -1;
		}
		INFO_LOG("wating the device authenticated.");
		sleep(1);
	}

	im_mqtt_unsubscribe_topic(im_base_get_mqttc(), im_base_get_mqttTopic4Sub());
	im_base_set_mqttTopic4Sub(im_base_get_commChAthnNo());
	im_base_set_mqttTopic4Pub(im_base_get_commChAthnNo());
	rc = im_mqtt_subscribe_topic(im_base_get_mqttc(), im_base_get_mqttTopic4Sub());
	if ( rc < 0)	{
		ERROR_LOG("fail im_mqtt_subscribe_topic(), topic=[%d]", im_base_get_commChAthnNo());
	}
#endif

    return rc;
}

int im_auth_device()
{
#if  defined (_IM_C_MQTT_) 
    int rc = 0;
	im_base_set_mqttTopic4Sub(im_base_get_deviceId());
	im_base_set_mqttTopic4Pub(im_base_get_deviceId());
	rc = im_mqtt_subscribe_topic(im_base_get_mqttc(), im_base_get_mqttTopic4Sub());
	if ( rc < 0)	{
		ERROR_LOG("fail im_mqtt_subscribe_topic(), topic=[%d]", im_base_get_mqttTopic4Sub());
		return -1;
	}
#endif

	return __if224_auth_device_Sync();
}


/* ==============================
 * im_send_keepalive
 * ============================== */
#include "packet/body/body231.h"
#include "packet/head/head231.h"

int im_231_res_pkt_handler(IMPacketPtr respPkt)
{
	int rc = 0;
	IMPacketBodyPtr body = NULL;
	char *athnNo = NULL;

    if ( respPkt == NULL ) {
		ERROR_LOG("no packet to process");
		return -1;
    }

    DEBUG_LOG("keepalived");

    return 0;
}

static int __if231_keepalive_Sync()
{
	int rc = 0;

	IMPacket pkt;
	IMBody231Req  body231;
	IMHead231Req  head231;

	im_head231_req_init(&head231);
    im_body231_req_init(&body231);

	im_packet_init_with(&pkt, &head231.head, &body231.body);
    // sync
    rc = im_action_do_req_pkt(&pkt, im_231_res_pkt_handler);

    im_body231_req_release(&body231);
    im_head231_req_release(&head231);
	im_packet_release(&pkt);

    return rc;
}

static int __if231_keepalive_Aync()
{
	int rc = 0;

	IMPacket pkt;
	IMBody231Req  body231;
	IMHead231Req  head231;
    unsigned long long txIdOfHead = 0;

	im_head231_req_init(&head231);
    im_body231_req_init(&body231);
	im_packet_init_with(&pkt, &head231.head, &body231.body);
    
    txIdOfHead = im_pktHead_get_trmTransacId((IMPacketHeadPtr)&pkt.head);
    // SEND
    rc = im_action_send_packet(&pkt);

    im_body231_req_release(&body231);
    im_head231_req_release(&head231);
	im_packet_release(&pkt);

    // RECV
	rc = im_action_recv_packet_with_handler(txIdOfHead, im_231_res_pkt_handler);
    return rc;
}



#if defined (_IM_C_SOCK_) 
int im_send_keepalive()
{
	return __if231_keepalive_Sync();
#if 0
    return __if231_keepalive_Aync();
#endif 
}

#endif
