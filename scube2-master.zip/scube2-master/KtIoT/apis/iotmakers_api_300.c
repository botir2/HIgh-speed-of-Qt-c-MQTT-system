/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <stdio.h>

#include "base/base.h"
#include "util/log.h"

#include "packet/head/head332.h"
#include "packet/body/body332.h"

/* ==============
g_if332_body
=============== */
static	IMBody332Req	g_if332_body;

static IMCBResBodyHndl  g_res_body_handler = NULL;

int im_332_res_pkt_handler(IMPacketPtr respPkt)
{
	int rc = 0;
	IMPacketBodyPtr body = NULL;

    if ( respPkt == NULL ) {
		ERROR_LOG("no packet to process");
		return -1;
    }

    body = im_packet_get_body(respPkt);
    if ( body == NULL ) {
		ERROR_LOG("no body to process");
		return -1;
    }
    
    if ( g_res_body_handler != NULL ) {
        g_res_body_handler(body);
    }
	return 0;
}

static int __im_332_send_body_Sync(IMBody332ReqPtr body332)
{
	int rc = 0;

	IMPacket pkt;
	IMHead332Req  head332;

	im_head332_req_init(&head332);
	im_packet_init_with(&pkt, &head332.head, &body332->body);
    // sync
    rc = im_action_do_req_pkt(&pkt, im_332_res_pkt_handler);

    im_head332_req_release(&head332);
	im_packet_release(&pkt);
    return rc;
}


/* ==============
im_if332_req FULL API
=============== */
IMBody332ReqPtr im_332_get_body()
{
    return &g_if332_body;
}

int im_332_print_body()
{
    im_pktBody_print_serialized_string(&g_if332_body.body);
    return 0;
}

int im_332_set_res_body_handler(IMCBResBodyHndl  res_body_handler)
{
    g_res_body_handler = res_body_handler;
}
int im_332_unset_res_body_handler()
{
    g_res_body_handler = NULL;
}

int im_332_init()
{
	im_body332_req_init(&g_if332_body);
	return 0;
}
int im_332_release()
{
	im_body332_req_release(&g_if332_body);
}

int im_332_send()
{
	return __im_332_send_body_Sync(&g_if332_body);
}


int im_332_set_insert()
{
    im_body332_req_set_infoUpdTypeCd_insert(&g_if332_body);
    im_body332_req_append_devBas(&g_if332_body, im_base_get_extrSysId(), im_base_get_deviceId());
    return 0;
}

int im_332_set_delete()
{
    im_body332_req_set_infoUpdTypeCd_delete(&g_if332_body);
    im_body332_req_append_devBas(&g_if332_body, im_base_get_extrSysId(), im_base_get_deviceId());
    return 0;
}

int im_332_set_update()
{
    im_body332_req_set_infoUpdTypeCd_update(&g_if332_body);
    im_body332_req_append_devBas(&g_if332_body, im_base_get_extrSysId(), im_base_get_deviceId());
    return 0;
}

int im_332_set_update_all()
{
    im_body332_req_set_infoUpdTypeCd_update_all(&g_if332_body);
    im_body332_req_append_devBas(&g_if332_body, im_base_get_extrSysId(), im_base_get_deviceId());
    return 0;
}

int im_332_put_default(char* devId, char* devName, char* makerCd, char* modelCd, char* ipAddr, char* statCd, char* frmwrVer)
{
    im_body332_req_set_devId(&g_if332_body, devId);
    im_body332_req_set_devNm(&g_if332_body, devName);
    im_body332_req_set_makrCd(&g_if332_body, makerCd);
    im_body332_req_set_modelCd(&g_if332_body, modelCd);
    im_body332_req_set_ipAdr(&g_if332_body, ipAddr);
    im_body332_req_set_sttusCd(&g_if332_body, statCd);
    im_body332_req_set_frmwrVerNo(&g_if332_body, frmwrVer);
    return 0;
}


int im_332_add_avp(char* attr, char* val)
{
    im_if332_set_device_info_extavp(&g_if332_body, attr, val);
    return 0;
}

