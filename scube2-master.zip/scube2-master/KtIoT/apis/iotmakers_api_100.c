/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <stdio.h>

#include "base/base.h"
#include "util/log.h"
#include "packet/packet.h"


/* ==============================
 * im_send_keepalive
 * ============================== */
#include "packet/body/body121.h"
#include "packet/head/head121.h"

static IMCBResBodyHndl  g_res_body_handler = NULL;

int im_121_res_pkt_handler(IMPacketPtr respPkt)
{
	int rc = 0;
	IMPacketBodyPtr body = NULL;

    if ( respPkt == NULL ) {
		ERROR_LOG("no packet to process");
		return -1;
    }

    body = im_packet_get_body(respPkt);
    if ( body == NULL ) {
		ERROR_LOG("no body to process");
		return -1;
    }

    if ( g_res_body_handler != NULL ) {
        g_res_body_handler(body);
    }
	return 0;
}


static int __if121_req_svrtime_Sync()
{
	int rc = 0;

	IMPacket pkt;
	IMBody121Req  body121;
	IMHead121Req  head121;

	im_head121_req_init(&head121);
    im_body121_req_init(&body121);

	im_packet_init_with(&pkt, &head121.head, &body121.body);
    // sync
    rc = im_action_do_req_pkt(&pkt, im_121_res_pkt_handler);

    im_body121_req_release(&body121);
    im_head121_req_release(&head121);
	im_packet_release(&pkt);

    return rc;
}

int im_121_set_res_body_handler(IMCBResBodyHndl  res_body_handler)
{
    g_res_body_handler = res_body_handler;
}
int im_121_unset_res_body_handler()
{
    g_res_body_handler = NULL;
}


int im_121_req_svrdate()
{
	return __if121_req_svrtime_Sync();
}
