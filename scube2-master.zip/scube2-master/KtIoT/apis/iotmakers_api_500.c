/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <stdio.h>

#include "base/base.h"
#include "util/log.h"

#include "packet/head/head525.h"
#include "packet/body/body525.h"

/* ==============
g_if525_body
=============== */

static IMCBResBodyHndl          g_control_body_handler = NULL;
static IMCbTagidNumDataHndl     g_control_numdata_handler = NULL;
static IMCbTagidStrDataHndl     g_control_strdata_handler = NULL;

int im_525_set_req_body_handler(IMCBResBodyHndl  control_body_handler)
{
    g_control_body_handler = control_body_handler;
}
int im_525_unset_req_body_handler(IMCBResBodyHndl control_body_handler)
{
    g_control_body_handler = control_body_handler;
}


int im_525_set_numdata_handler(IMCbTagidNumDataHndl  numdata_handler)
{
    g_control_numdata_handler = numdata_handler;
}
int im_525_set_strdata_handler(IMCbTagidStrDataHndl strdata_handler)
{
    g_control_strdata_handler = strdata_handler;
}

int im_525_unset_numdata_handler(IMCbTagidNumDataHndl  numdata_handler)
{
    g_control_numdata_handler = NULL;
}
int im_525_unset_strdata_handler(IMCbTagidStrDataHndl strdata_handler)
{
    g_control_strdata_handler = NULL;
}



static int __if525_send_response(IMPacketPtr reqPkt)
{
    int rc = 0;
	IMPacket pkt;
	IMBody525Res  body525;
	IMHead525Res  head525;

	im_head525_res_init(&head525);
    im_body525_res_init(&body525);
	im_packet_init_with(&pkt, &head525.head, &body525.body);

   	im_pktHead_copy_trmTransacId(&(head525.head), reqPkt->head);
	im_body525_res_set_respCd(&body525, "100");
	im_body525_res_set_respMsg(&body525, "SUCCESS");

    rc = im_action_send_packet(&pkt);

    im_body525_res_release(&body525);
    im_head525_res_release(&head525);
	im_packet_release(&pkt);

    return rc;
}

static int __if525_process_simple_req(IMPacketPtr reqPkt)
{
    int rc = 0;
    char *devid;
	char *tagid;
	char *strval;
	double numval;
	int idx = 0;

	IMBody525Req  body525;
    IMPacketBodyPtr pbody = im_packet_get_body(reqPkt);

    if ( g_control_body_handler != NULL )    {
        g_control_body_handler(pbody);
        return 0;
    } 


    im_body525_req_init_with(&body525, pbody);

	if ( g_control_numdata_handler != NULL )	{
		for (idx=0; idx<IOTMAKERS_MAX_CONTROL_DATA; idx++)	{
			rc = im_body525_req_get_numdata_with_index(&body525, idx, &devid, &tagid, &numval);
			if ( rc < 0 )	{
				break;
			}
			g_control_numdata_handler(devid, tagid, numval);	
		}
	} else {
		INFO_LOG("No control_numdata_handler set");
	}

	if (g_control_strdata_handler != NULL) {
		for (idx=0; idx<IOTMAKERS_MAX_CONTROL_DATA; idx++)		{
			rc = im_body525_req_get_strdata_with_index(&body525, idx, &devid, &tagid, &strval);
			if ( rc < 0 )	{
				break;
			}
			g_control_strdata_handler(devid, tagid, strval);	
		}
	} else {
		INFO_LOG("No control_strdata_handler set");
	}

    return rc;
}

static int __if525_process_req_cnvyRow(IMBody525ReqPtr pb525)
{
    int rc = 0;
    char *devid;
	char *tagid;
	char *strval;
	double numval;
	int idx = 0;
	int happens = 0;

	if ( g_control_numdata_handler != NULL )	{
		for (idx=0; idx<IOTMAKERS_MAX_CONTROL_DATA; idx++)	{
			rc = im_body525_req_get_numdata_with_index(pb525, idx, &devid, &tagid, &numval);
			if ( rc < 0 )	{
				break;
			}
			g_control_numdata_handler(devid, tagid, numval);
            happens++;
		}
	} else {
		INFO_LOG("No control_numdata_handler set");
	}

	if (g_control_strdata_handler != NULL) {
		for (idx=0; idx<IOTMAKERS_MAX_CONTROL_DATA; idx++)		{
			rc = im_body525_req_get_strdata_with_index(pb525, idx, &devid, &tagid, &strval);
			if ( rc < 0 )	{
				break;
			}
			g_control_strdata_handler(devid, tagid, strval);	
            happens++;
		}
	} else {
		INFO_LOG("No control_strdata_handler set");
	}

    return happens;
}
static int __if525_process_req_devCnvyData(IMBody525ReqPtr pb525)
{
	int happens = 0;
    while ( __if525_process_req_cnvyRow(pb525) > 0 )    {
        im_body525_req_next_colecRowIdx(pb525);
        happens++;
    }
    return happens;
}
static int __if525_process_req_full(IMPacketPtr reqPkt)
{
	IMBody525Req  body525;
    IMPacketBodyPtr pbody = im_packet_get_body(reqPkt);

    if ( g_control_body_handler != NULL )    {
        g_control_body_handler(pbody);
        return 0;
    } 

    im_body525_req_init_with(&body525, pbody);
    while ( __if525_process_req_devCnvyData(&body525) > 0 )    {
        im_body525_req_next_devColecDataIdx(&body525);
    }

    return 0;
}


int im_525_req_pkt_handler(IMPacketPtr reqPkt)
{
    int rc = 0;

    if ( reqPkt == NULL ) {
		ERROR_LOG("no packet to process");
		return -1;
    }

    __if525_send_response(reqPkt);

#if 0
    __if525_process_req(reqPkt);
#else
    __if525_process_req_full(reqPkt);
#endif
    return 0;
}



/* ==============
im_if525_send_report
=============== */
static	IMBody525Report	g_if525report_body;

int im_525_report_init_with_devid(char *devId)
{
	im_body525_report_init(&g_if525report_body);

    im_body525_report_set_extrSysId(&g_if525report_body, im_base_get_extrSysId());
    im_body525_report_append_devCnvyData(&g_if525report_body, devId);
    im_body525_report_append_cnvyRow(&g_if525report_body);
    
	return 0;
}

int im_525_report_init()
{
    im_525_report_init_with_devid(im_base_get_deviceId());
	return 0;
}


int im_525_report_release()
{
	im_body525_report_release(&g_if525report_body);
}


static int __im_525_report_send_body(IMBody525ReportPtr body525report)
{
	int rc = 0;

	IMPacket pkt;
	IMHead525Report  head525report;

	im_head525_report_init(&head525report);

    im_packet_init_with(&pkt, &head525report.head, &body525report->body);

    // send only, no wait response
    rc = im_action_do_send_pkt(&pkt);

    im_head525_report_release(&head525report);
	im_packet_release(&pkt);
    return rc;
}


int im_send_report_numdata_with_devid(char *devId, char *tagid, double val)
{
	im_base_set_lastErrorCode(IM_ErrCode_SUCCESS);
    im_525_report_init_with_devid(devId);
    im_body525_report_append_snsnDataInfo(&g_if525report_body, tagid, val); 
    int rc = __im_525_report_send_body(&g_if525report_body);
	
    im_525_report_release();
	return rc;
}

int im_send_report_strdata_with_devid(char *devId, char *tagid, char *val)
{
	im_base_set_lastErrorCode(IM_ErrCode_SUCCESS);
    im_525_report_init_with_devid(devId);
    im_body525_report_append_strDataInfo(&g_if525report_body, tagid, val); 
    int rc = __im_525_report_send_body(&g_if525report_body);
    im_525_report_release();
	return rc;
}


int im_send_report_numdata(char *tagid, double val)
{
    return im_send_report_numdata_with_devid(im_base_get_deviceId(), tagid, val);
}

int im_send_report_strdata(char *tagid, char *val)
{
    return im_send_report_strdata_with_devid(im_base_get_deviceId(), tagid, val);
}
