/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <stdio.h>

#include "base/base.h"
#include "util/log.h"

#include "packet/head/head411.h"
#include "packet/body/body411.h"

/* ==============
g_if411_body
=============== */
static	IMBody411Req	g_if411_body;

static IMCBResBodyHndl  g_res_body_handler = NULL;

int im_411_res_pkt_handler(IMPacketPtr respPkt)
{
	int rc = 0;
	IMPacketBodyPtr body = NULL;

    if ( respPkt == NULL ) {
		ERROR_LOG("no packet to process");
		return -1;
    }
	body = im_packet_get_body(respPkt);
    
    if ( body == NULL ) {
		ERROR_LOG("no body to process");
		return -1;
    }

    if ( g_res_body_handler != NULL ) {
        g_res_body_handler(body);
    }
	return 0;
}


/*
2018-04-06
*/
static int __im_411_send_body(IMBody411ReqPtr body411, int is_async)
{
	int rc = 0;

	IMPacket pkt;
	IMHead411Req  head411;

	im_head411_req_init(&head411);
	im_packet_init_with(&pkt, &head411.head, &body411->body);

    if ( is_async == (1) )    {
        // async
        rc = im_action_do_send_pkt(&pkt);
    } else {
        // sync
        rc = im_action_do_req_pkt(&pkt, im_411_res_pkt_handler);
    }

    im_head411_req_release(&head411);
	im_packet_release(&pkt);
    return rc;
}


static int __im_411_send_body_Sync(IMBody411ReqPtr body411)
{
    return __im_411_send_body(body411, 0);
}

static int __im_411_send_body_ASync(IMBody411ReqPtr body411)
{
    return __im_411_send_body(body411, 1);
}



/* ==============
im_if411_req FULL API
=============== */
IMBody411ReqPtr im_411_get_body()
{
    return &g_if411_body;
}

int im_411_print_body()
{
    im_pktBody_print_serialized_string(&g_if411_body.body);
    return 0;
}

int im_411_set_res_body_handler(IMCBResBodyHndl  res_body_handler)
{
    g_res_body_handler = res_body_handler;
}
int im_411_unset_res_body_handler()
{
    g_res_body_handler = NULL;
}


int im_411_init_with_devid_on_group(char *devId, char *groupTagCd)
{
	im_body411_req_init(&g_if411_body);
	im_body411_req_set_extrSysId(&g_if411_body, im_base_get_extrSysId());
    im_body411_req_append_devColecData(&g_if411_body, devId);
    im_body411_req_append_colecRow(&g_if411_body, groupTagCd);
	return 0;
}
int im_411_init_with_devid(char *devId)
{
	return im_411_init_with_devid_on_group(devId, NULL);
}

int im_411_init_on_group(char *groupTagCd)
{
    im_411_init_with_devid_on_group(im_base_get_deviceId(), groupTagCd);
	return 0;
}
int im_411_init()
{
    im_411_init_with_devid_on_group(im_base_get_deviceId(), NULL);
	return 0;
}
int im_411_release()
{
	im_body411_req_release(&g_if411_body);
}

int im_411_put_numdata(char *tagid, double val)
{
    im_body411_req_append_snsnDataInfo(&g_if411_body, tagid, val);
	return 0;
}
int im_411_put_strdata(char *tagid, char *val)
{
    im_body411_req_append_strDataInfo(&g_if411_body, tagid, val);
	return 0;
}

int im_411_append_new_devColecData(char *devId)
{
    im_body411_req_append_devColecData(&g_if411_body, devId);
}



int im_411_append_new_colecRow_on_group(char *groupTagCd)
{
    im_body411_req_append_colecRow(&g_if411_body, groupTagCd);
    return 0;
}

int im_411_append_new_colecRow()
{
    return im_411_append_new_colecRow_on_group(NULL);
}

// 2017-10-18
int im_411_append_new_colecRow_with_occDt_on_group(char *occDateStr, char *groupTagCd)
{
    im_body411_req_append_colecRow_with_occDt(&g_if411_body, occDateStr, groupTagCd);
    return 0;
}

int im_411_append_new_colecRow_with_occDt(char *occDateStr)
{
    im_411_append_new_colecRow_with_occDt_on_group(occDateStr, NULL);
    return 0;
}


int im_411_send()
{
	return __im_411_send_body_Sync(&g_if411_body);
}
int im_411_send_async()
{
	return __im_411_send_body_ASync(&g_if411_body);
}

/* ==============
im_if411_req SIMPLE API
=============== */
int im_send_numdata_on_group(char *tagid, double val, char *groupTagCd)
{
	im_base_set_lastErrorCode(IM_ErrCode_SUCCESS);
	im_411_init_on_group(groupTagCd);
    im_body411_req_append_snsnDataInfo(&g_if411_body, tagid, val); 
    int rc = __im_411_send_body_Sync(&g_if411_body);
	im_411_release();
	return rc;
}
int im_send_strdata_on_group(char* tagid, char* val, char *groupTagCd)
{
	im_base_set_lastErrorCode(IM_ErrCode_SUCCESS);
	im_411_init_on_group(groupTagCd);
    im_body411_req_append_strDataInfo(&g_if411_body, tagid, val); 
    int rc = __im_411_send_body_Sync(&g_if411_body);
	im_411_release();
	return rc;
}


int im_send_numdata(char *tagid, double val)
{
    int rc = im_send_numdata_on_group(tagid, val, NULL);
	return rc;
}
int im_send_strdata(char* tagid, char* val)
{
    int rc = im_send_strdata_on_group(tagid, val, NULL);
	return rc;
}


/* ==============
im_if411_req SIMPLE API 
    with a custom devId
=============== */
int im_send_numdata_with_devid(char *devId, char *tagid, double val)
{
    im_411_init_with_devid(devId);
    im_body411_req_append_snsnDataInfo(&g_if411_body, tagid, val);
    int rc = __im_411_send_body_Sync(&g_if411_body);
	im_411_release();
}
int im_send_strdata_with_devid(char *devId, char *tagid, char *val)
{
    im_411_init_with_devid(devId);
    im_body411_req_append_strDataInfo(&g_if411_body, tagid, val);
    int rc = __im_411_send_body_Sync(&g_if411_body);
	im_411_release();
}

