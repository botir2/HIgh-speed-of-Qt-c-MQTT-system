/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <stdio.h>

#include "base/base.h"
#include "util/log.h"
#include "packet/packet.h"


/* ==============================
 * im_send_keepalive
 * ============================== */
#include "packet/body/body731.h"
#include "packet/head/head731.h"

static	IMBody731Req	g_if731_body;

static IMCBResBodyHndl  g_res_body_handler = NULL;

int im_731_res_pkt_handler(IMPacketPtr respPkt)
{
	int rc = 0;
	IMPacketBodyPtr body = NULL;

    if ( respPkt == NULL ) {
		ERROR_LOG("no packet to process");
		return -1;
    }

    body = im_packet_get_body(respPkt);
    if ( body == NULL ) {
		ERROR_LOG("no body to process");
		return -1;
    }

    if ( g_res_body_handler != NULL ) {
        g_res_body_handler(body);
    }
	return 0;
}


static int __im_731_send_body_Sync()
{
	int rc = 0;

	IMPacket pkt;
	IMHead731Req  head731;

	im_head731_req_init(&head731);

	im_packet_init_with(&pkt, &head731.head, &g_if731_body.body);
    
    // sync
    rc = im_action_do_req_pkt(&pkt, im_731_res_pkt_handler);

    im_head731_req_release(&head731);
	im_packet_release(&pkt);

    return rc;
}

int im_731_set_res_body_handler(IMCBResBodyHndl  res_body_handler)
{
    g_res_body_handler = res_body_handler;
}
int im_731_unset_res_body_handler()
{
    g_res_body_handler = NULL;
}


int im_731_init()
{
	im_body731_req_init(&g_if731_body);
	im_body731_req_set_extrSysId(&g_if731_body, im_base_get_extrSysId());
    im_body731_req_set_devId(&g_if731_body, im_base_get_deviceId());
	return 0;
}
int im_731_release()
{
	im_body731_req_release(&g_if731_body);
}




int im_731_req_otp_check(char* seed, char* otp)
{
	im_base_set_lastErrorCode(IM_ErrCode_SUCCESS);

    im_731_init();
    
    im_body731_req_set_seed(&g_if731_body, seed); 
    im_body731_req_set_otp(&g_if731_body, otp); 

#if 0
im_pktBody_print_serialized_string(&g_if731_body.body);
#endif

    int rc = __im_731_send_body_Sync(&g_if731_body);
	
    im_731_release();
	return rc;
}
