#if 0

/*
 * IF-333
 */
int im_if333_set_attr(void* body, char *attr, char *val)
{
	return im_if333_devBasVO_set_attr(body, attr, val);
}
int im_if333_add_devDtlVO(void* body, char *attr, char *val)
{
	return im_if333_devBasVO_add_devDtlVO(body, attr, val);
}

int im_if333_add_binSetup(void* body, char *tagid, char *val, int valLen)
{
	return im_if333_devBasVO_add_binSetupDataInfoVO(body, tagid, val, valLen);
}


/*
 * IF-711
 */
int im_add_numdata_for_if711(void* body, char *tagid, double val)
{
	return im_if711_devColecDataVO_add_numdata(body, tagid, (double)val);
}
int im_add_strdata_for_if711(void* body, char *tagid, char *val)
{
	return im_if711_devColecDataVO_add_strdata(body, tagid, val);
}
int im_add_bindata_for_if711(void* body, char *tagid, char *val, int valLen)
{
	return im_if711_devColecDataVO_add_bindata(body, tagid, val, valLen);
}


#endif
