#if defined (_IM_C_SSL_)

/*
 * GiGA IoTMakers version 2
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <openssl/bio.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/pem.h>
#include <openssl/x509.h>
#include <openssl/x509_vfy.h>

#include "util/log.h"
#include "netio/sock.h"

static int g_connected;
static int g_sockfd;

static SSL_CTX* g_ctx;
static SSL*     g_ssl;

static BIO* g_certbio = NULL;
static BIO* g_outbio = NULL;
static const SSL_METHOD*    g_method = NULL;

static const char* g_ca_bundlestr = NULL;

static  void __freeSSLCTX(SSL_CTX* pctx)
{
    if ( g_certbio != NULL ) {
        free(g_certbio);
    }
    if ( g_outbio != NULL ) {
        free(g_outbio);
    }
    if ( pctx != NULL ) {
      SSL_CTX_free(pctx);
    }
    INFO_LOG("Finished SSL/TLS connection");
}

static  SSL_CTX* __initSSLCTX(void)
{
  int ret, i;

  /* ---------------------------------------------------------- *
   * These function calls initialize openssl for correct work.  *
   * ---------------------------------------------------------- */
  OpenSSL_add_all_algorithms();
  ERR_load_BIO_strings();
  ERR_load_crypto_strings();
  SSL_load_error_strings();

  /* ---------------------------------------------------------- *
   * Create the Input/Output BIO's.                             *
   * ---------------------------------------------------------- */
  g_certbio = BIO_new(BIO_s_file());
  g_outbio  = BIO_new_fp(stdout, BIO_NOCLOSE);

  /* ---------------------------------------------------------- *
   * initialize SSL library and register algorithms             *
   * ---------------------------------------------------------- */
  if(SSL_library_init() < 0){
    INFO_LOG("Could not initialize the OpenSSL library !");
  }

  /* ---------------------------------------------------------- *
   * Set SSLv2 client hello, also announce SSLv3 and TLSv1      *
   * ---------------------------------------------------------- */
  g_method = SSLv23_client_method();

  /* ---------------------------------------------------------- *
   * Try to create a new SSL context                            *
   * ---------------------------------------------------------- */
  if ( (g_ctx = SSL_CTX_new(g_method)) == NULL){
    INFO_LOG("Unable to create a new SSL context structure.");
  }

  /* ---------------------------------------------------------- *
   * Disabling SSLv2 will leave v3 and TSLv1 for negotiation    *
   * ---------------------------------------------------------- */
   SSL_CTX_set_options(g_ctx, SSL_OP_NO_SSLv2);
  
  return g_ctx;
}


static void __freeSSL(SSL* pssl, int sock)
{
  close(sock);          /* close socket */
  SSL_free(pssl);
  INFO_LOG("Finished SSL");
}

static  SSL* __initSSL(SSL_CTX* pctx, int sock)
{
  int ret, i;

  /* ---------------------------------------------------------- *
   * Create new SSL connection state object                     *
   * ---------------------------------------------------------- */
  g_ssl = SSL_new(pctx);

  /* ---------------------------------------------------------- *
   * Attach the SSL session to the socket descriptor            *
   * ---------------------------------------------------------- */
  SSL_set_fd(g_ssl, sock);

  /* ---------------------------------------------------------- *
   * Try to SSL-connect here, returns 1 for success             *
   * ---------------------------------------------------------- */
  if ( SSL_connect(g_ssl) != 1 ){
    ERROR_LOG("Could not build a SSL session to");
    return NULL;
  }
  else {
    ERROR_LOG("Successfully enabled SSL/TLS session to");
  }
    return g_ssl;
}


/*---------------------------------------------------------------------*/
/*--- __showCerts - print out the certificates.                       ---*/
/*---------------------------------------------------------------------*/
static void __showCerts(SSL* pssl)
{   X509 *cert;
    char *line;

    cert = SSL_get_peer_certificate(pssl);	/* get the server's certificate */
    if ( cert != NULL )
    {
        INFO_LOG("Server certificates:");
        line = X509_NAME_oneline(X509_get_subject_name(cert), 0, 0);
        INFO_LOG("Subject: %s", line);
        free(line);							/* free the malloc'ed string */
        line = X509_NAME_oneline(X509_get_issuer_name(cert), 0, 0);
        INFO_LOG("Issuer: %s", line);
        free(line);							/* free the malloc'ed string */
        X509_free(cert);					/* free the malloc'ed certificate copy */
    }
    else
        INFO_LOG("No certificates.");
}

static int __verifyCerts(SSL* pssl, char ca_bundlestr[])
{   
    X509 *cert = NULL;
    X509 *error_cert = NULL;
    X509_STORE *store = NULL;
    X509_STORE_CTX  *vrfy_ctx = NULL;

    X509_NAME    *certsubject = NULL;

    char *line;
    int ret;

  /* ---------------------------------------------------------- *
   * Initialize the global certificate validation store object. *
   * ---------------------------------------------------------- */
  if (!(store=X509_STORE_new()))
     ERROR_LOG("Error creating X509_STORE_CTX object");

  /* ---------------------------------------------------------- *
   * Create the context structure for the validation operation. *
   * ---------------------------------------------------------- */
  vrfy_ctx = X509_STORE_CTX_new();

  ret = X509_STORE_load_locations(store, ca_bundlestr, NULL);
  if (ret != 1)
    ERROR_LOG("Error loading CA cert or chain file");

    cert = SSL_get_peer_certificate(pssl);	/* get the server's certificate */
    if ( cert == NULL )    {
    ERROR_LOG("Error get_peer_certificate");
    exit(-1);
    }

  /* ---------------------------------------------------------- *
   * Initialize the ctx structure for a verification operation: *
   * Set the trusted cert store, the unvalidated cert, and any  *
   * potential certs that could be needed (here we set it NULL) *
   * ---------------------------------------------------------- */
  X509_STORE_CTX_init(vrfy_ctx, store, cert, NULL);

  /* ---------------------------------------------------------- *
   * Check the complete cert chain can be build and validated.  *
   * Returns 1 on success, 0 on verification failures, and -1   *
   * for trouble with the ctx object (i.e. missing certificate) *
   * ---------------------------------------------------------- */
  ret = X509_verify_cert(vrfy_ctx);
  INFO_LOG("Verification return code: %d", ret);

  if(ret == 0 || ret == 1)
  INFO_LOG("Verification result text: %s",
             X509_verify_cert_error_string(vrfy_ctx->error));

  /* ---------------------------------------------------------- *
   * The error handling below shows how to get failure details  *
   * from the offending certificate.                            *
   * ---------------------------------------------------------- */
  if(ret == 0) {
        error_cert  = X509_STORE_CTX_get_current_cert(vrfy_ctx);
        
        line = X509_NAME_oneline(X509_get_subject_name(error_cert), 0, 0);
        INFO_LOG("Verification failed cert: %s", line);
        printf("Verification failed cert: %s\n", line);
        free(line);							/* free the malloc'ed string */

        X509_free(error_cert);
  }

  /* ---------------------------------------------------------- *
   * Free up all structures                                     *
   * ---------------------------------------------------------- */
  X509_STORE_CTX_free(vrfy_ctx);
  X509_STORE_free(store);
  X509_free(cert);

    if ( ret != 1 ) return -1;

    return 0;
}

int im_ssl_set_trusred_ca_path(char *ca_bundlestr) 
{
    g_ca_bundlestr = ca_bundlestr;
}


int im_ssl_connect_timeout(char *remoteip, unsigned short port, int timeout_sec) 
{
    g_ctx = __initSSLCTX();
    if ( g_ctx == NULL ) {
        ERROR_LOG("fail __initSSLCTX()");
        return -1;
    }

    g_sockfd = im_sock_connect_timeout(remoteip, port, timeout_sec);
    if ( g_sockfd < 0 ) {
        __freeSSLCTX(g_ctx);    /* release context */
        return -1;
    }
    
    g_ssl = __initSSL(g_ctx, g_sockfd);   /* create new SSL connection state */
    if ( g_ssl == NULL )	{		/* perform the connection */
        ERROR_LOG("fail __initSSL()");
        ERR_print_errors_fp(stderr);
        return -1;
    }

    INFO_LOG("Connected with %s encryption", SSL_get_cipher(g_ssl));
    __showCerts(g_ssl);								/* get any certs */

#if 1       // ADDED on 2017-06-09
    if (  g_ca_bundlestr != NULL && __verifyCerts(g_ssl, g_ca_bundlestr) < 0)    {
        g_connected = (0);
        return -1;
    }
#endif


    g_connected = (1);
	return g_sockfd;
}

int im_ssl_disconnect()
{
    if ( g_ssl != NULL ) {
        __freeSSL(g_ssl, g_sockfd);     /* close socket */
    }
    if ( g_ctx != NULL ) {
        __freeSSLCTX(g_ctx);            /* release context */
    }
    
    return 0;
}

int im_ssl_send(char *data, int data_len)
{
	int nsend = 0;
    nsend = SSL_write(g_ssl, data, data_len);       /* encrypt & send message */
	return nsend;
}

int im_ssl_recv(char *o_buff, int len)
{
	int lenRead = 0;
    lenRead = SSL_read(g_ssl, o_buff, len);         /* get reply & decrypt */
    DEBUG_LOG("lenRead", lenRead);
    // o_buff[lenRead] = 0;
    return lenRead;
}

#endif  //#defined (_IM_C_SSL_)