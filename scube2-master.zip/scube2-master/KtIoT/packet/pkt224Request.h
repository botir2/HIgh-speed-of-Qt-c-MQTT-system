/*
 * GiGA IoTMakers version 2.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKT224_REQUEST_H
#define IOTMAKERS_PKT224_REQUEST_H

#include "packet/packet.h"


typedef struct {
	JSON_Status		json_status;
    char			*serialized_string;
    JSON_Value		*root;
} IMPacket224, *IMPacket224Ptr;



#ifdef __cplusplus
extern "C" {
#endif

int im_pkt224_request_init(IMPacketPtr pkt) ;


#ifdef __cplusplus
}
#endif


#endif