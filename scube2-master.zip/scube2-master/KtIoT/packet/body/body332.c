#include "packet/body/body332.h"

#if 0

"devBasVOs[0].extrSysId" = ""

{
	"InfoUpdTypeCd": "13"
	"devBasVOs": [{
		"extrSysId": "",
		"devId": "",
		"upExtrSysId": "",
		"upDevId": "",

		"devNm": "",
		"ipAdr": "",
		"sttusCd": "",
		"makrCd": "",
		"modelCd": "",
		"frmwrVerNo": "",

		"useYn": "",
		"delYn": "",
		"lastMtnDt": ""
	}]
}

#endif


/* =======================================
Request
======================================== */
int im_body332_req_init(IMBody332ReqPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();

    pb->devBasIdx = (-1);;
    return 0;
}
int im_body332_req_release(IMBody332ReqPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}

int im_body332_req_set_infoUpdTypeCd_insert(IMBody332ReqPtr pb) {
	jbody_value_set_string(pb->body.root, "infoUpdTypeCd", "01");
}
int im_body332_req_set_infoUpdTypeCd_delete(IMBody332ReqPtr pb) {
	jbody_value_set_string(pb->body.root, "infoUpdTypeCd", "21");
}
int im_body332_req_set_infoUpdTypeCd_update_all(IMBody332ReqPtr pb) {
	jbody_value_set_string(pb->body.root, "infoUpdTypeCd", "11");
}
int im_body332_req_set_infoUpdTypeCd_update(IMBody332ReqPtr pb) {
	jbody_value_set_string(pb->body.root, "infoUpdTypeCd", "13");
}



int im_body332_req_append_devBas(IMBody332ReqPtr pb, char* extrSysId, char* devId) {
    JSON_Value *devBasVO = jbody_devBasVO_init(extrSysId, devId);
	jbody_value_append_arr_value(pb->body.root, "devBasVOs", devBasVO);
    pb->devBasIdx++;
	return 0;
}

int im_body332_req_set_devId(IMBody332ReqPtr pb, char* devId) {
	JSON_Value *devBasVO = jbody_value_get_arrItem_with_index(pb->body.root, "devBasVOs", pb->devBasIdx);
    if ( devId != NULL ) jbody_value_set_string(devBasVO, "devId", devId);
    return 0;
}
int im_body332_req_set_devNm(IMBody332ReqPtr pb, char* devNm) {
	JSON_Value *devBasVO = jbody_value_get_arrItem_with_index(pb->body.root, "devBasVOs", pb->devBasIdx);
    if ( devNm != NULL ) jbody_value_set_string(devBasVO, "devNm", devNm);
    return 0;
}

int im_body332_req_set_makrCd(IMBody332ReqPtr pb, char* makrCd) {
	JSON_Value *devBasVO = jbody_value_get_arrItem_with_index(pb->body.root, "devBasVOs", pb->devBasIdx);
    if ( makrCd != NULL ) jbody_value_set_string(devBasVO, "makrCd", makrCd);
    return 0;
}
int im_body332_req_set_modelCd(IMBody332ReqPtr pb, char* modelCd) {
	JSON_Value *devBasVO = jbody_value_get_arrItem_with_index(pb->body.root, "devBasVOs", pb->devBasIdx);
    if ( modelCd != NULL ) jbody_value_set_string(devBasVO, "modelCd", modelCd);
    return 0;
}
int im_body332_req_set_ipAdr(IMBody332ReqPtr pb, char* ipAdr) {
	JSON_Value *devBasVO = jbody_value_get_arrItem_with_index(pb->body.root, "devBasVOs", pb->devBasIdx);
    if ( ipAdr != NULL ) jbody_value_set_string(devBasVO, "ipAdr", ipAdr);
    return 0;
}
int im_body332_req_set_sttusCd(IMBody332ReqPtr pb, char* sttusCd) {
	JSON_Value *devBasVO = jbody_value_get_arrItem_with_index(pb->body.root, "devBasVOs", pb->devBasIdx);
    if ( sttusCd != NULL ) jbody_value_set_string(devBasVO, "sttusCd", sttusCd);
    return 0;
}
int im_body332_req_set_frmwrVerNo(IMBody332ReqPtr pb, char* frmwrVerNo) {
	JSON_Value *devBasVO = jbody_value_get_arrItem_with_index(pb->body.root, "devBasVOs", pb->devBasIdx);
    if ( frmwrVerNo != NULL ) jbody_value_set_string(devBasVO, "frmwrVerNo", frmwrVerNo);
    return 0;
}


int im_if332_set_device_info_extavp (IMBody332ReqPtr pb, char* attr, char* val)
{
	JSON_Value *devBasVO = jbody_value_get_arrItem_with_index(pb->body.root, "devBasVOs", pb->devBasIdx);
	if ( devBasVO == NULL )	{
		return -1;
	}

	if ( attr != NULL && val != NULL) jbody_value_set_string(devBasVO, attr, val);
	return 0;
}



/* =======================================
Response
======================================== */
char* im_body332_req_get_respCd(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "respCd");
}
