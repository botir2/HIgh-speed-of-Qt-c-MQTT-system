/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKTBODY_IF333_H
#define IOTMAKERS_PKTBODY_IF333_H

#include "packet/body/body.h"

typedef struct {
    IMPacketBody	body;
} IMBody333Req, *IMBody333ReqPtr;


#ifdef __cplusplus
extern "C"
{
#endif

/* =======================================
Request
======================================== */
int im_body333_req_init(IMBody333ReqPtr pb) ;
int im_body333_req_release(IMBody333ReqPtr pb) ;

/* =======================================
Response
======================================== */

#ifdef __cplusplus
}
#endif


#endif
