#include "packet/body/body333.h"

/* =======================================
Request
======================================== */
int im_body333_req_init(IMBody333ReqPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();
	return 0;
}
int im_body333_req_release(IMBody333ReqPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}



/* =======================================
Response
======================================== */
