/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "util/log.h"
#include "packet/body/body.h"


/* =====================================
body init
====================================== */
int im_pktBody_init(IMPacketBodyPtr body) 
{
	body->json_status = JSONSuccess;
	body->serialized_string = NULL;
	body->root = NULL;
	return 0;
}
int im_pktBody_init_with_string(IMPacketBodyPtr body, char *json_str) 
{
	body->json_status = JSONSuccess;
	body->serialized_string = NULL;

	body->root = json_parse_string(json_str);
	if ( body->root == NULL )	{
		return -1;
	}
	return 0;
}
void im_pktBody_release(IMPacketBodyPtr body) 
{
	if ( body->serialized_string != NULL ){
		json_free_serialized_string(body->serialized_string);
		body->serialized_string = NULL;
	}

	if ( body->root != NULL ){
		json_value_free(body->root);
		body->root = NULL;
	}
}

/* =====================================
simple key-value-pair
====================================== */
char* im_pktBody_get_strval(IMPacketBodyPtr body, char *key) 
{
	return (char*)json_object_dotget_string(json_value_get_object(body->root), key);
}

char* im_pktBody_get_respCd(IMPacketBodyPtr body) 
{
	return im_pktBody_get_strval(body, EXTR_IF_BODY_COMMON_respCd);
}
int im_pktBody_get_respCd_as_int(IMPacketBodyPtr body) 
{
	char *respCd = im_pktBody_get_strval(body, EXTR_IF_BODY_COMMON_respCd);
	if ( respCd == NULL )	{
		return -1;
	}
	return atoi(respCd);
}
char* im_pktBody_get_respMsg(IMPacketBodyPtr body) 
{
	return im_pktBody_get_strval(body, EXTR_IF_BODY_COMMON_respMsg);
}


/* =====================================
serialize
====================================== */
int im_pktBody_get_serialized_strlen(IMPacketBodyPtr body) 
{
	//
	//!!! json_serialization_size() counts '\0' for string length.
	//
	return json_serialization_size(body->root) - 1;
}
char* im_pktBody_get_serialized_string(IMPacketBodyPtr body) 
{
	if ( body->serialized_string != NULL ){
		json_free_serialized_string(body->serialized_string);
	}
	body->serialized_string = json_serialize_to_string(body->root);
	return (char*)body->serialized_string;
}

int im_pktBody_get_serialized_to_buff(IMPacketBodyPtr body, char *o_buff, int o_buff_len)
{
	int len = im_pktBody_get_serialized_strlen(body);
	if ( len <= 0 || o_buff_len < len )	{
		return -1;
	}

	strcpy(o_buff, im_pktBody_get_serialized_string(body));

#if defined(CIPHER_AES128CBC) || defined(CIPHER_AES256CBC)
{
    DEBUG_LOG("body plain: %s", o_buff);

    int cipher_len = 0;
    int cipher_buff_len = o_buff_len+32;
    char *cipher_buff = malloc(cipher_buff_len);
    if ( cipher_buff == NULL )    {
    	printf("fail s\n", "malloc(cipher_buff)");
        return -1;
    }
	memset (cipher_buff, 0x00, sizeof(cipher_buff_len));

    cipher_len = aes_encrypt_cbc_pkcs5 (im_base_get_aes_cbc_ctx(), (unsigned char*)o_buff, len, 
        (unsigned char*)cipher_buff, cipher_buff_len);

    memcpy(o_buff, cipher_buff, cipher_len);
    free(cipher_buff);
	return cipher_len;
}
#elif defined(CIPHER_ARIA128CBC)
{
    DEBUG_LOG("body plain: %s", o_buff);
    //im_log_write_hex((unsigned char*)o_buff, strlen(o_buff));	
    
    int cipher_len = 0;
    int cipher_buff_len = o_buff_len+32;
    char *cipher_buff = malloc(cipher_buff_len);
    if ( cipher_buff == NULL )    {
    	printf("fail s\n", "malloc(cipher_buff)");
        return -1;
    }
	memset (cipher_buff, 0x00, sizeof(cipher_buff_len));

#if 0
    cipher_len = aria_encrypt_cbc_pkcs5 (im_base_get_aria_cbc_ctx(), (unsigned char*)o_buff, len, 
        (unsigned char*)cipher_buff, cipher_buff_len);
#else
    cipher_len = aria_encrypt_pkcs5 (im_base_get_aria_cbc_ctx(), (unsigned char*)o_buff, len, 
        (unsigned char*)cipher_buff, cipher_buff_len);
#endif

    memcpy(o_buff, cipher_buff, cipher_len);
    free(cipher_buff);
	return cipher_len;
}
#else
	return len;
#endif
}

int im_pktBody_get_deserialized_from_buff(IMPacketBodyPtr body, char *i_buff)
{
	// Just in case...
	im_pktBody_release(body);
	return im_pktBody_init_with_string(body, i_buff);
}

int im_pktBody_get_deserialized_from_buff_len(IMPacketBodyPtr body, char *data, int data_len)
{
	// Just in case...
	im_pktBody_release(body);

#if defined(CIPHER_AES128CBC) || defined(CIPHER_AES256CBC)
    int plain_len = 0;
    int plain_buff_len = strlen(data);
    char *plain_buff = malloc(data_len);
    if ( plain_buff == NULL )    {
    	printf("fail s\n", "malloc(plain_buff)");
        return -1;
    }
	memset (plain_buff, 0x00, sizeof(plain_buff_len));

    plain_len = aes_decrypt_cbc_pkcs5 (im_base_get_aes_cbc_ctx(), (unsigned char*)data, data_len, 
        (unsigned char*)plain_buff, plain_buff_len);

    DEBUG_LOG("body plain: %s", plain_buff);

   	int rc = im_pktBody_init_with_string(body, plain_buff);
    free(plain_buff);

   
    return rc;

#elif defined(CIPHER_ARIA128CBC)
    int plain_len = 0;
    int plain_buff_len = strlen(data);
    char *plain_buff = malloc(data_len);
    if ( plain_buff == NULL )    {
    	printf("fail s\n", "malloc(plain_buff)");
        return -1;
    }
	memset (plain_buff, 0x00, sizeof(plain_buff_len));

#if 0
    plain_len = aria_decrypt_cbc_pkcs5 (im_base_get_aria_cbc_ctx(), (unsigned char*)data, data_len, 
        (unsigned char*)plain_buff, plain_buff_len);
#else
    plain_len = aria_decrypt_pkcs5 (im_base_get_aria_cbc_ctx(), (unsigned char*)data, data_len, 
        (unsigned char*)plain_buff, plain_buff_len);
#endif

    DEBUG_LOG("body plain: %s", plain_buff);

   	int rc = im_pktBody_init_with_string(body, plain_buff);
    free(plain_buff);

    return rc;

#else
	return im_pktBody_init_with_string(body, data);
#endif
}



/* =====================================
debug
====================================== */
void im_pktBody_print_serialized_string(IMPacketBodyPtr body)
{
    char *serialized_string = NULL;
	serialized_string = json_serialize_to_string_pretty(body->root);
	printf("serialized_string:\n%s\n", serialized_string);
    json_free_serialized_string(serialized_string);
}
