#include "packet/body/body731.h"

/* =======================================
Request
======================================== */
int im_body731_req_init(IMBody731ReqPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();
	return 0;
}
int im_body731_req_release(IMBody731ReqPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}


int im_body731_req_set_extrSysId(IMBody731ReqPtr pb, char* extrSysId) {
	jbody_value_set_string(pb->body.root, "extrSysId", extrSysId);

	return 0;
}
int im_body731_req_set_devId(IMBody731ReqPtr pb, char* devId) {
	jbody_value_set_string(pb->body.root, "devId", devId);

	return 0;
}
int im_body731_req_set_seed(IMBody731ReqPtr pb, char* seed) {
	jbody_value_set_string(pb->body.root, "seed", seed);

	return 0;
}
int im_body731_req_set_otp(IMBody731ReqPtr pb, char* otp) {
	jbody_value_set_string(pb->body.root, "otp", otp);

	return 0;
}

/* =======================================
Response
======================================== */
char* im_body731_req_get_respMsg(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "respMsg");
}
char* im_body731_req_get_otpRespCode(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "otpRespCode");
}
char* im_body731_req_get_otpRespMessage(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "otpRespMessage");
}
char* im_body731_req_get_phoneNumber(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "phoneNumber");
}
