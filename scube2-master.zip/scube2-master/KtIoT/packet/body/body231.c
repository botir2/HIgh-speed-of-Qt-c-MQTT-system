#include "packet/body/body231.h"

/* =======================================
Request
======================================== */
int im_body231_req_init(IMBody231ReqPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();
	return 0;
}
int im_body231_req_release(IMBody231ReqPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}



/* =======================================
Response
======================================== */
