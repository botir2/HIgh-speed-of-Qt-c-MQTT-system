/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKTBODY_IF411_H
#define IOTMAKERS_PKTBODY_IF411_H

#include "packet/body/body.h"

typedef struct {
    IMPacketBody	body;

    int devColecDataIdx;
    int colecRowIdx;
} IMBody411Req, *IMBody411ReqPtr;


#ifdef __cplusplus
extern "C"
{
#endif

/* =======================================
Request
======================================== */
int im_body411_req_init(IMBody411ReqPtr pb) ;
int im_body411_req_release(IMBody411ReqPtr pb) ;

/* =======================================
Response
======================================== */

#ifdef __cplusplus
}
#endif


#endif
