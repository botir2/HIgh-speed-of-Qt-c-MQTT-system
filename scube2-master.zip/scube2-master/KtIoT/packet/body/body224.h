/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKTBODY_IF224_H
#define IOTMAKERS_PKTBODY_IF224_H

#include "packet/body/body.h"

typedef struct {
    IMPacketBody	body;
} IMBody224Req, *IMBody224ReqPtr;


#ifdef __cplusplus
extern "C"
{
#endif

/* =======================================
Request
======================================== */
int im_body224_req_init(IMBody224ReqPtr pb) ;
int im_body224_req_release(IMBody224ReqPtr pb) ;

int im_body224_req_set_extrSysId(IMBody224ReqPtr pb, char* extrSysId) ;
int im_body224_req_set_devId(IMBody224ReqPtr pb, char* devId) ;
int im_body224_req_set_athnRqtNo(IMBody224ReqPtr pb, char* athnRqtNo) ;

char* im_body224_req_get_extrSysId(IMBody224ReqPtr pb);
char* im_body224_req_get_devId(IMBody224ReqPtr pb);
char* im_body224_req_get_athnRqtNo(IMBody224ReqPtr pb);


/* =======================================
Response
======================================== */
char* im_body224_req_get_athnNo(IMPacketBodyPtr pb);

#ifdef __cplusplus
}
#endif



#endif



