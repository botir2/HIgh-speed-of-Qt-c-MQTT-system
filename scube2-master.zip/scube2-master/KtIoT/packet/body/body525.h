/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKTBODY_IF525_H
#define IOTMAKERS_PKTBODY_IF525_H

#include "packet/body/body.h"

typedef struct {
    IMPacketBodyPtr	pbody;

    int devColecDataIdx;
    int colecRowIdx;
} IMBody525Req, *IMBody525ReqPtr;

typedef struct {
    IMPacketBody	body;
} IMBody525Res, *IMBody525ResPtr;

typedef struct {
    IMPacketBody	body;

    int devCnvyDataIdx;
    int cnvyRowIdx;

} IMBody525Report, *IMBody525ReportPtr;


#ifdef __cplusplus
extern "C"
{
#endif

/* =======================================
Request
======================================== */
int im_body525_res_init(IMBody525ResPtr pb) ;
int im_body525_res_release(IMBody525ResPtr pb) ;

int im_body525_report_init(IMBody525ReportPtr pb) ;
int im_body525_report_release(IMBody525ReportPtr pb) ;


/* =======================================
Response
======================================== */

#ifdef __cplusplus
}
#endif


#endif
