#include "packet/body/body224.h"

/* =======================================
Request
======================================== */
int im_body224_req_init(IMBody224ReqPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();
	return 0;
}
int im_body224_req_release(IMBody224ReqPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}

int im_body224_req_set_extrSysId(IMBody224ReqPtr pb, char* extrSysId) {
	jbody_value_set_string(pb->body.root, "extrSysId", extrSysId);
	return 0;
}
int im_body224_req_set_devId(IMBody224ReqPtr pb, char* devId) {
	jbody_value_set_string(pb->body.root, "devId", devId);	
	return 0;
}
int im_body224_req_set_athnRqtNo(IMBody224ReqPtr pb, char* athnRqtNo) {
	jbody_value_set_string(pb->body.root, "athnRqtNo", athnRqtNo);
	return 0;
}

char* im_body224_req_get_extrSysId(IMBody224ReqPtr pb) {
	jbody_value_get_string(pb->body.root, "extrSysId");
}
char* im_body224_req_get_devId(IMBody224ReqPtr pb) {
	jbody_value_get_string(pb->body.root, "devId");
}
char* im_body224_req_get_athnRqtNo(IMBody224ReqPtr pb) {
	jbody_value_get_string(pb->body.root, "athnRqtNo");
}

/* =======================================
Response
======================================== */
char* im_body224_req_get_athnNo(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "athnNo");
}
