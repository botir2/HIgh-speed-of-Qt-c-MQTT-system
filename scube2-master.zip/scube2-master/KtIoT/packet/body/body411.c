#include "packet/body/body411.h"

#if 0

"extrSysId" = "extrSysId"

"devColecDataVOs[0].colecRowVOs[0].snsnDataInfoVOs[0].dataTypeCd" = "aaa"
"devColecDataVOs[0].colecRowVOs[0].snsnDataInfoVOs[0].snsnVal" = 100

"devColecDataVOs[0].colecRowVOs[0].snsnDataInfoVOs[1].dataTypeCd" = "bbb"
"devColecDataVOs[0].colecRowVOs[0].snsnDataInfoVOs[1].snsnVal" = 100

"devColecDataVOs[0].colecRowVOs[0].strDataInfoVOs[0].snsnTagCd" = "aaa"
"devColecDataVOs[0].colecRowVOs[0].strDataInfoVOs[0].strVal" = "xxx"


{
    "extrSysId": "OPEN_TCP_001PTL001_1000001433",
    "devColecDataVOs": [
        {
            "devId": "bbbbb",
            "colecRowVOs": [
                {
                    "occDt": "2018-02-20 17:24:38.512",
                    "groupTagCd": "GROUP01",
                    "snsnDataInfoVOs": [
                        {
                            "dataTypeCd": "number",
                            "snsnVal": 100
                        }
                    ],
                    "strDataInfoVOs": [
                        {
                            "snsnTagCd": "string",
                            "strVal": "hello"
                        }
                    ]
                },
                {
                    "occDt": "2018-02-20 17:24:39.512",
                    "groupTagCd": "GROUP02",
                    "snsnDataInfoVOs": [
                        {
                            "dataTypeCd": "number",
                            "snsnVal": 110
                        }
                    ],
                    "strDataInfoVOs": [
                        {
                            "snsnTagCd": "string",
                            "strVal": "hello2"
                        }
                    ]
                }
            ]
        }
    ]
}
#endif

/* =======================================
Request
======================================== */
int im_body411_req_init(IMBody411ReqPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();

    pb->devColecDataIdx = (-1);
    pb->colecRowIdx = (-1);;

	return 0;
}
int im_body411_req_release(IMBody411ReqPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}



int im_body411_req_set_extrSysId(IMBody411ReqPtr pb, char* extrSysId) {
	jbody_value_set_string(pb->body.root, "extrSysId", extrSysId);
	return 0;
}

int im_body411_req_append_devColecData(IMBody411ReqPtr pb, char* devId) {
	JSON_Value* devColecDataVO = jbody_devColecDataVO_init(devId); 
	jbody_value_append_arr_value(pb->body.root, "devColecDataVOs", devColecDataVO);
    pb->devColecDataIdx++;
    pb->colecRowIdx = (-1);
	return 0;
}

int im_body411_req_append_colecRow(IMBody411ReqPtr pb, char *groupTagCd) {
    JSON_Value* devColecDataVO = jbody_value_get_arrItem_with_index(pb->body.root, "devColecDataVOs", pb->devColecDataIdx); 
    JSON_Value* colecRowVO = jbody_colecRowVO_init(); 

    if ( groupTagCd != NULL )    {
        jbody_value_set_string(colecRowVO, "groupTagCd", groupTagCd);
    }
	
    jbody_value_append_arr_value(devColecDataVO, "colecRowVOs", colecRowVO);
    pb->colecRowIdx++;
	return 0;
}

int im_body411_req_append_colecRow_with_occDt(IMBody411ReqPtr pb, char *occDateStr, char *groupTagCd) {
    JSON_Value* devColecDataVO = jbody_value_get_arrItem_with_index(pb->body.root, "devColecDataVOs", pb->devColecDataIdx); 
    JSON_Value* colecRowVO = jbody_colecRowVO_init(); 

    jbody_value_set_string(colecRowVO, "occDt", occDateStr);
    if ( groupTagCd != NULL )    {
        jbody_value_set_string(colecRowVO, "groupTagCd", groupTagCd);
    }

    jbody_value_append_arr_value(devColecDataVO, "colecRowVOs", colecRowVO);
    pb->colecRowIdx++;

	return 0;
}




int im_body411_req_append_snsnDataInfo(IMBody411ReqPtr pb, char* dataTypeCd, double snsnVal) {
    JSON_Value* devColecDataVO = jbody_value_get_arrItem_with_index(pb->body.root, "devColecDataVOs", pb->devColecDataIdx); 
    JSON_Value* colecRowVO = jbody_value_get_arrItem_with_index(devColecDataVO, "colecRowVOs", pb->colecRowIdx); 

   	JSON_Value* snsnDataInfoVO = jbody_snsnDataInfoVO_init(dataTypeCd, snsnVal); 
    jbody_colecRowVO_append_snsnDataInfoVO(colecRowVO, snsnDataInfoVO);
	return 0;
}

int im_body411_req_append_strDataInfo(IMBody411ReqPtr pb, char* dataTypeCd, char* strVal) {
    JSON_Value* devColecDataVO = jbody_value_get_arrItem_with_index(pb->body.root, "devColecDataVOs", pb->devColecDataIdx); 
    JSON_Value* colecRowVO = jbody_value_get_arrItem_with_index(devColecDataVO, "colecRowVOs", pb->colecRowIdx); 

	JSON_Value* strDataInfoVO = jbody_strDataInfoVO_init(dataTypeCd, strVal); 
    jbody_colecRowVO_append_strDataInfoVO(colecRowVO, strDataInfoVO);
	return 0;
}

/* =======================================
Response
======================================== */
char* im_body411_req_get_respCd(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "respCd");
}
