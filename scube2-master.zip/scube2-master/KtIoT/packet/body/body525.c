#include "packet/body/body525.h"

/* =======================================
Response Send
======================================== */
int im_body525_res_init(IMBody525ResPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();
	return 0;
}
int im_body525_res_release(IMBody525ResPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}
int im_body525_res_set_respCd(IMBody525ResPtr pb, char* respCd)
{
	jbody_value_set_string(pb->body.root, "respCd", respCd);
    return 0;
}
int im_body525_res_set_respMsg(IMBody525ResPtr pb, char* respMsg)
{
	jbody_value_set_string(pb->body.root, "respMsg", respMsg);
    return 0;
}

/* =======================================
Report Send
======================================== */
#if 0
report data - serialized_string:
{
	"extrSysId": "EXAMPLE_LOWSYSTEM",
	"devCnvyDataVOs": [{
		"m2mSvcNo": 0,
		"devId": "D901CCTV01",
		"cnvyRowVOs": [{
			"occDt": "2014-02-2817:59:17.517",
			"snsnDataInfoVOs": [{
				"dataTypeCd": "10001003",
				"snsnVal": 0.7
			}],
			"strDataInfoVOs": [{
				"snsnTagCd": "60001003",
				"strVal": "EXAMPLE_STRING"
			}]
		}]
	}]
}

#endif

int im_body525_report_init(IMBody525ReportPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();

    pb->devCnvyDataIdx = (-1);
    pb->cnvyRowIdx = (-1);;


	return 0;
}
int im_body525_report_release(IMBody525ReportPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}

int im_body525_report_set_extrSysId(IMBody525ReportPtr pb, char* extrSysId) {
	jbody_value_set_string(pb->body.root, "extrSysId", extrSysId);
jbody_JSON_Value_print(pb->body.root);

	return 0;
}

int im_body525_report_append_devCnvyData(IMBody525ReportPtr pb, char* devId) {
	JSON_Value* devCnvyDataVO = jbody_devColecDataVO_init(devId); 
	jbody_value_append_arr_value(pb->body.root, "devCnvyDataVOs", devCnvyDataVO);
    pb->devCnvyDataIdx++;
    pb->cnvyRowIdx = (-1);
	return 0;
}

int im_body525_report_append_cnvyRow(IMBody525ReportPtr pb) {
    JSON_Value* devCnvyDataVO = jbody_value_get_arrItem_with_index(pb->body.root, "devCnvyDataVOs", pb->devCnvyDataIdx); 
    JSON_Value* cnvyRowVO = jbody_cnvyRowVO_init(); 
	jbody_value_append_arr_value(devCnvyDataVO, "cnvyRowVOs", cnvyRowVO);
    pb->cnvyRowIdx++;
	return 0;
}


int im_body525_report_append_snsnDataInfo(IMBody525ReportPtr pb, char* dataTypeCd, double snsnVal) {
    JSON_Value* devCnvyDataVO = jbody_value_get_arrItem_with_index(pb->body.root, "devCnvyDataVOs", pb->devCnvyDataIdx); 
    JSON_Value* cnvyRowVO = jbody_value_get_arrItem_with_index(devCnvyDataVO, "cnvyRowVOs", pb->cnvyRowIdx); 

   	JSON_Value* snsnDataInfoVO = jbody_snsnDataInfoVO_init(dataTypeCd, snsnVal); 
    jbody_cnvyRowVO_append_snsnDataInfoVO(cnvyRowVO, snsnDataInfoVO);
	return 0;
}

int im_body525_report_append_strDataInfo(IMBody525ReportPtr pb, char* dataTypeCd, char* strVal) {
    JSON_Value* devCnvyDataVO = jbody_value_get_arrItem_with_index(pb->body.root, "devCnvyDataVOs", pb->devCnvyDataIdx); 
    JSON_Value* cnvyRowVO = jbody_value_get_arrItem_with_index(devCnvyDataVO, "cnvyRowVOs", pb->cnvyRowIdx); 

	JSON_Value* strDataInfoVO = jbody_strDataInfoVO_init(dataTypeCd, strVal); 
    jbody_colecRowVO_append_strDataInfoVO(cnvyRowVO, strDataInfoVO);
	return 0;
}

/* =======================================
Request Recv
======================================== */
#if 0

"devCnvyDataVOs[0].cnvyRowVOs[0].snsnDataInfoVOs[0].dataTypeCd" = "controll01"
"devCnvyDataVOs[0].cnvyRowVOs[0].snsnDataInfoVOs[0].snsnVal" = 6

control data - serialized_string:
{
    "mapHeaderExtension": {},
    "devCnvyDataVOs": [
        {
            "devId": "river4D1450836201263",
            "cnvyRowVOs": [
                {
                    "snsnDataInfoVOs": [
                        {
                            "dataTypeCd": "controll01",
                            "snsnVal": 6
                        }
                    ],
                    "sttusDataInfoVOs": [],
                    "contlDataInfoVOs": [],
                    "cmdDataInfoVOs": [],
                    "binDataInfoVOs": [],
                    "strDataInfoVOs": [],
                    "dtDataInfoVOs": [],
                    "genlSetupDataInfoVOs": [],
                    "sclgSetupDataInfoVOs": [],
                    "binSetupDataInfoVOs": [],
                    "mapRowExtension": {}
                }
            ]
        }
    ],
    "msgHeadVO": {
        "mapHeaderExtension": {}
    }
}
#endif

int im_body525_req_init_with(IMBody525ReqPtr pb, IMPacketBodyPtr reqBody) {
	pb->pbody = reqBody;
    pb->devColecDataIdx = 0;
    pb->colecRowIdx = 0;;
	return 0;
}
int im_body525_req_release(IMBody525ReqPtr pb) {
	return 0;
}

int im_body525_req_next_devColecDataIdx(IMBody525ReqPtr pb) {
    pb->devColecDataIdx++;
    pb->colecRowIdx = 0;
}
int im_body525_req_next_colecRowIdx(IMBody525ReqPtr pb) {
    pb->colecRowIdx++;
}


int im_body525_req_get_numdata_with_index (IMBody525ReqPtr pb, int idx, char **o_devid, char **o_tagid, double *o_val)
{
    IMPacketBodyPtr body = pb->pbody;

	if ( body->root == NULL ){
		return -1;
	}

	JSON_Value* devCnvyDataVO = jbody_value_get_arrItem_with_index(body->root, "devCnvyDataVOs", pb->devColecDataIdx);
	if ( devCnvyDataVO == NULL )	{
		return -1;
	}

	JSON_Value* cnvyRowVO = jbody_value_get_arrItem_with_index(devCnvyDataVO, "cnvyRowVOs", pb->colecRowIdx);
	if ( cnvyRowVO == NULL )	{
		return -1;
	}

	JSON_Value* strDataInfoVO = jbody_value_get_arrItem_with_index(cnvyRowVO, "snsnDataInfoVOs", idx);
	if ( strDataInfoVO == NULL )	{
		return -1;
	}

	*o_devid = jbody_value_to_string(jbody_value_get_value(devCnvyDataVO, "devId"));
	*o_tagid = jbody_value_to_string(jbody_value_get_value(strDataInfoVO, "dataTypeCd"));
	*o_val = json_number(jbody_value_get_value(strDataInfoVO, "snsnVal"));

	return 0;
}
int im_body525_req_get_strdata_with_index (IMBody525ReqPtr pb, int idx, char **o_devid, char **o_tagid, char **o_val)
{
    IMPacketBodyPtr body = pb->pbody;

    if ( body->root == NULL ){
		return -1;
	}

	JSON_Value* devCnvyDataVO = jbody_value_get_arrItem_with_index(body->root, "devCnvyDataVOs", pb->devColecDataIdx);
	if ( devCnvyDataVO == NULL )	{
		return -1;
	}

	JSON_Value* cnvyRowVO = jbody_value_get_arrItem_with_index(devCnvyDataVO, "cnvyRowVOs", pb->colecRowIdx);
	if ( cnvyRowVO == NULL )	{
		return -1;
	}

	JSON_Value* strDataInfoVO = jbody_value_get_arrItem_with_index(cnvyRowVO, "strDataInfoVOs", idx);
	if ( strDataInfoVO == NULL )	{
		return -1;
	}

	*o_devid = jbody_value_to_string(jbody_value_get_value(devCnvyDataVO, "devId"));
	*o_tagid = jbody_value_to_string(jbody_value_get_value(strDataInfoVO, "snsnTagCd"));
	*o_val = jbody_value_to_string(jbody_value_get_value(strDataInfoVO, "strVal"));

	return 0;
}




/*
int im_body525_get_numdata_with_index (IMPacketBodyPtr body, int idx, char **o_devid, char **o_tagid, double *o_val)
{
	if ( body->root == NULL ){
		return -1;
	}

	JSON_Value* devCnvyDataVO = jbody_value_get_arrItem_with_index(body->root, "devCnvyDataVOs", 0);
	if ( devCnvyDataVO == NULL )	{
		return -1;
	}

	JSON_Value* cnvyRowVO = jbody_value_get_arrItem_with_index(devCnvyDataVO, "cnvyRowVOs", 0);
	if ( cnvyRowVO == NULL )	{
		return -1;
	}

	JSON_Value* strDataInfoVO = jbody_value_get_arrItem_with_index(cnvyRowVO, "snsnDataInfoVOs", idx);
	if ( strDataInfoVO == NULL )	{
		return -1;
	}

	*o_devid = jbody_value_to_string(jbody_value_get_value(devCnvyDataVO, "devId"));
	*o_tagid = jbody_value_to_string(jbody_value_get_value(strDataInfoVO, "dataTypeCd"));
	*o_val = json_number(jbody_value_get_value(strDataInfoVO, "snsnVal"));

	return 0;
}
int im_body525_get_strdata_with_index (IMPacketBodyPtr body, int idx, char **o_devid, char **o_tagid, char **o_val)
{
	if ( body->root == NULL ){
		return -1;
	}

	JSON_Value* devCnvyDataVO = jbody_value_get_arrItem_with_index(body->root, "devCnvyDataVOs", 0);
	if ( devCnvyDataVO == NULL )	{
		return -1;
	}

	JSON_Value* cnvyRowVO = jbody_value_get_arrItem_with_index(devCnvyDataVO, "cnvyRowVOs", 0);
	if ( cnvyRowVO == NULL )	{
		return -1;
	}

	JSON_Value* strDataInfoVO = jbody_value_get_arrItem_with_index(cnvyRowVO, "strDataInfoVOs", idx);
	if ( strDataInfoVO == NULL )	{
		return -1;
	}

	*o_devid = jbody_value_to_string(jbody_value_get_value(devCnvyDataVO, "devId"));
	*o_tagid = jbody_value_to_string(jbody_value_get_value(strDataInfoVO, "snsnTagCd"));
	*o_val = jbody_value_to_string(jbody_value_get_value(strDataInfoVO, "strVal"));

	return 0;
}
*/
