/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKTBODY_IF121_H
#define IOTMAKERS_PKTBODY_IF121_H

#include "packet/body/body.h"

typedef struct {
    IMPacketBody	body;
} IMBody121Req, *IMBody121ReqPtr;


#ifdef __cplusplus
extern "C"
{
#endif

/* =======================================
Request
======================================== */
int im_body121_req_init(IMBody121ReqPtr pb) ;
int im_body121_req_release(IMBody121ReqPtr pb) ;

/* =======================================
Response
======================================== */

#ifdef __cplusplus
}
#endif


#endif
