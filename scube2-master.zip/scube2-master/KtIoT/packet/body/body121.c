#include "packet/body/body121.h"

/* =======================================
Request
======================================== */
int im_body121_req_init(IMBody121ReqPtr pb) {
	im_pktBody_init(&pb->body);

	pb->body.root = json_value_init_object();
	return 0;
}
int im_body121_req_release(IMBody121ReqPtr pb) {
	im_pktBody_release(&pb->body);
	return 0;
}



/* =======================================
Response
======================================== */
char* im_body121_req_get_respCd(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "respCd");
}

char* im_body121_req_get_srvrDt(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "srvrDt");
}

char* im_body121_req_get_srvrTimeZone(IMPacketBodyPtr pbody) {
	jbody_value_get_string(pbody->root, "srvrTimeZone");
}
