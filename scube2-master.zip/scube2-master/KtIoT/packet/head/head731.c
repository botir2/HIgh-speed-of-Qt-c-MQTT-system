#include "packet/head/head731.h"

int im_head731_req_init(IMHead731ReqPtr ph){
	im_pktHead_init_oneway_req(&ph->head);

    im_pktHead_set_methodType(&ph->head, MthdType_OPT_CHECK_QUERY);
	return 0;
}
int im_head731_req_release(IMHead731ReqPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}
