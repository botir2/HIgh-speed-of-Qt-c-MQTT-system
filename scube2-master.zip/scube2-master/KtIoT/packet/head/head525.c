#include "packet/head/head525.h"

int im_head525_req_init(IMHead525ReqPtr ph){
	im_pktHead_init_oneway_req(&ph->head);
    im_pktHead_set_methodType(&ph->head, MthdType_CONTL_ITGCNVY_DATA);
	return 0;
}
int im_head525_req_release(IMHead525ReqPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}


int im_head525_res_init(IMHead525ResPtr ph){
	im_pktHead_init_response(&ph->head);
    im_pktHead_set_methodType(&ph->head, MthdType_CONTL_ITGCNVY_DATA);
	return 0;
}
int im_head525_res_release(IMHead525ResPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}

int im_head525_report_init(IMHead525ReportPtr ph){
	im_pktHead_init_report(&ph->head);
    im_pktHead_set_methodType(&ph->head, MthdType_CONTL_ITGCNVY_DATA);
	return 0;
}
int im_head525_report_release(IMHead525ReportPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}

