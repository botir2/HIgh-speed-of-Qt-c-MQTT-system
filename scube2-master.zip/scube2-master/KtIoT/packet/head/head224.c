#include "packet/head/head224.h"

int im_head224_req_init(IMHead224ReqPtr ph){
	im_pktHead_init_oneway_req(&ph->head);

    im_pktHead_set_methodType(&ph->head, MthdType_ATHN_COMMCHATHN_DEV_TCP);
	return 0;
}
int im_head224_req_release(IMHead224ReqPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}
