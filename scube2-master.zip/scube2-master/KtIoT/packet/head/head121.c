#include "packet/head/head121.h"

int im_head121_req_init(IMHead121ReqPtr ph){
	im_pktHead_init_oneway_req(&ph->head);

    im_pktHead_set_methodType(&ph->head, MthdType_SVR_DT_REQ);
	return 0;
}
int im_head121_req_release(IMHead121ReqPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}
