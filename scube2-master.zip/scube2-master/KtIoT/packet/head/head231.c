#include "packet/head/head231.h"

int im_head231_req_init(IMHead231ReqPtr ph){
	im_pktHead_init_oneway_req(&ph->head);

    im_pktHead_set_methodType(&ph->head, MthdType_KEEP_ALIVE_COMMCHATHN_TCP);
	return 0;
}
int im_head231_req_release(IMHead231ReqPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}
