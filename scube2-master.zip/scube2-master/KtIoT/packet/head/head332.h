/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKTHEAD_IF332_H
#define IOTMAKERS_PKTHEAD_IF332_H

#include "packet/head/head.h"

typedef struct {
    IMPacketHead	head;
} IMHead332Req, *IMHead332ReqPtr;


#ifdef __cplusplus
extern "C"
{
#endif

int im_head332_req_init(IMHead332ReqPtr ph) ;
int im_head332_req_release(IMHead332ReqPtr ph) ;

#ifdef __cplusplus
}
#endif



#endif



