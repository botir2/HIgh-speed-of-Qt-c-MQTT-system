#include "packet/head/head332.h"

int im_head332_req_init(IMHead332ReqPtr ph){
	im_pktHead_init_oneway_req(&ph->head);

    im_pktHead_set_methodType(&ph->head, MthdType_INITA_DEV_UDATERPRT);
	return 0;
}
int im_head332_req_release(IMHead332ReqPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}
