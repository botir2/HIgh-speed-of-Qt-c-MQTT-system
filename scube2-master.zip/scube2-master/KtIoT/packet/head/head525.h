/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKTHEAD_IF525_H
#define IOTMAKERS_PKTHEAD_IF525_H

#include "packet/head/head.h"

typedef struct {
    IMPacketHead	head;
} IMHead525Req, *IMHead525ReqPtr;

typedef struct {
    IMPacketHead	head;
} IMHead525Res, *IMHead525ResPtr;

typedef struct {
    IMPacketHead	head;
} IMHead525Report, *IMHead525ReportPtr;

#ifdef __cplusplus
extern "C"
{
#endif

int im_head525_req_init(IMHead525ReqPtr ph) ;
int im_head525_req_release(IMHead525ReqPtr ph) ;

int im_head525_res_init(IMHead525ResPtr ph) ;
int im_head525_res_release(IMHead525ResPtr ph) ;

int im_head525_report_init(IMHead525ReportPtr ph) ;
int im_head525_report_release(IMHead525ReportPtr ph) ;


#ifdef __cplusplus
}
#endif



#endif



