/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#ifndef IOTMAKERS_PKTHEAD_IF231_H
#define IOTMAKERS_PKTHEAD_IF231_H

#include "packet/head/head.h"

typedef struct {
    IMPacketHead	head;
} IMHead231Req, *IMHead231ReqPtr;


#ifdef __cplusplus
extern "C"
{
#endif

int im_head231_req_init(IMHead231ReqPtr ph) ;
int im_head231_req_release(IMHead231ReqPtr ph) ;

#ifdef __cplusplus
}
#endif



#endif



