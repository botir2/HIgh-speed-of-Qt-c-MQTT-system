#include "packet/head/head411.h"

int im_head411_req_init(IMHead411ReqPtr ph){
	im_pktHead_init_oneway_req(&ph->head);

    im_pktHead_set_methodType(&ph->head, MthdType_COLEC_ITGDATA_RECV);
	return 0;
}
int im_head411_req_release(IMHead411ReqPtr ph){
	im_pktHead_release(&ph->head);
	return 0;
}
