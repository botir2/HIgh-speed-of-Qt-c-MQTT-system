/*
 * GiGA IoTMakers version 1.0
 *
 *  Copyright (c) 2016 kt corp. All rights reserved.
 *
 *  This is a proprietary software of kt corp, and you may not use this file except in
 *  compliance with license agreement with kt corp. Any redistribution or use of this
 *  software, with or without modification shall be strictly prohibited without prior written
 *  approval of kt corp, and the copyright notice above does not evidence any actual or
 *  intended publication of such software.
 */

#include <string.h>

#if !defined(WIN32)
#include <arpa/inet.h>
#endif

#include "util/util.h"
#include "packet/packet.h"

/* =====================================
packet - init
====================================== */
int im_packet_init(IMPacketPtr pkt) 
{
	pkt->head = NULL;
	pkt->body = NULL;
	pkt->len = 0;
	return 0;
}

int im_packet_init_with(IMPacketPtr pkt, IMPacketHeadPtr phead, IMPacketBodyPtr pbody)
{
	pkt->head = phead;
	pkt->body = pbody;
	pkt->len = 0;
	return 0;
}
int im_packet_release(IMPacketPtr pkt) 
{
	pkt->head = NULL;
	pkt->body = NULL;
	pkt->len = 0;
	return 0;
}

IMPacketHeadPtr im_packet_get_head(IMPacketPtr pkt) 
{
	return pkt->head;
}
IMPacketBodyPtr im_packet_get_body(IMPacketPtr pkt) 
{
	return pkt->body;
}
void im_packet_set_head(IMPacketPtr pkt, IMPacketHeadPtr head)
{
	pkt->head = head;
}
void im_packet_set_body(IMPacketPtr pkt, IMPacketBodyPtr body)
{
	pkt->body = body;
}


int im_packet_get_len(IMPacketPtr pkt) 
{
	return pkt->len;
}

int im_packet_copy_body(IMPacketPtr pkt, IMPacketBodyPtr i_body) 
{
	IMPacketBodyPtr body = pkt->body;
	im_pktBody_release(body);
	return im_pktBody_init_with_string(body, im_pktBody_get_serialized_string(i_body));
}


/* =====================================
packet - (de)serialize
====================================== */
int im_packet_get_serialized_to_buff(IMPacketPtr pkt, char *o_buff, unsigned int o_buff_len)
{
	IMPacketHeadPtr head = pkt->head;
	IMPacketBodyPtr body = pkt->body;

	int head_len = 0;
	int body_len = 0;

	head_len = im_pktHead_get_serialized_to_buff(head, 
		&o_buff[IOTMAKERS_TCP_HEAD_4_BYTE_LEN], o_buff_len-IOTMAKERS_TCP_HEAD_4_BYTE_LEN);
	if ( head_len < 0 )	{
		//ERROR_LOG("fail im_pktHead_get_serialized_to_buff()");
		return -1;
	}

	if ( body->root != NULL )	{
		body_len = im_pktBody_get_serialized_to_buff(body, 
			&o_buff[IOTMAKERS_TCP_HEAD_4_BYTE_LEN+head_len], o_buff_len-IOTMAKERS_TCP_HEAD_4_BYTE_LEN-head_len);
	}

	pkt->len = head_len + body_len;

	unsigned int packetLen = htonl(pkt->len) & IOTMAKERS_32_BIT_MASKING;
	memcpy(&o_buff[0], &packetLen, IOTMAKERS_TCP_HEAD_4_BYTE_LEN);

	return pkt->len + IOTMAKERS_TCP_HEAD_4_BYTE_LEN;
}

int im_packet_get_deserialized_from_buff(IMPacketPtr pkt, char *i_buff, unsigned int i_buff_len)
{
	IMPacketHeadPtr head = pkt->head;
	IMPacketBodyPtr body = pkt->body;

	int head_len = 0;
	int body_len = 0;

	unsigned long pktLen = 0;

	pkt->len = i_buff_len;

	i_buff[pkt->len] = '\0';

	head_len = im_pktHead_get_deserialized_from_buff(head, &i_buff[0]);
	if ( head_len < 0 )	{
		return -1;
	}

#if 0
	body_len = im_pktBody_get_deserialized_from_buff(body, &i_buff[head_len]);
#else
    body_len = im_pktBody_get_deserialized_from_buff_len(body, &i_buff[head_len], i_buff_len-head_len);
#endif
	if ( body_len < 0 )	{
		return -1;
	}

	return (head_len + body_len);
}



